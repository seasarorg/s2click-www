Directory for SchemaFile
