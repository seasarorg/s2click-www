var GB_IMG_DIR = "/s2click/click/greybox/"
;GreyBox.preloadGreyBoxImages();
var S2C_FLD = "";
var S2C_ID_FLD = "";
function S2C_SET(data){
	AJS.$(S2C_FLD).value=data;
}
function S2C_ID_SET(data, id){
	AJS.$(S2C_FLD).value=data;
	AJS.$(S2C_ID_FLD).value=id;
}
function S2C_SHOW_URL(fld,title,URL){
    S2C_FLD = fld;
	GB_showFullScreen(title,URL);
}
function S2C_ID_SHOW_URL(fld,id,title,URL){
    S2C_FLD = fld;
    S2C_ID_FLD = id;
	GB_showFullScreen(title,URL);
}

