/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletContext;
import net.sf.click.Context;
import net.sf.click.Page;
import net.sf.click.util.ClickUtils;

/**
 * S2Click Utility 
 * @author shimura
 *
 */
public class Utility {
	private static boolean greyboxCopied = false;
	/**
	 * FullPath を返す Utility
	 * @param page
	 * @param pageClass
	 * @return FullPathのStringを返す
	 */
	public static String getFullPagePath(Page page, Class pageClass){
		return 
		page.getContext().getRequest().getContextPath()
		+ page.getContext().getPagePath(pageClass);
	}
	/**
	 * UniqueなSequenceを返す
	 * @return Unique String
	 */
	public static String CreateSeq(){
		return String.valueOf(new Date().getTime());
	}
	/**
	 * parameterで渡された Objectを引き継ぎながら Redirectする
	 * 
	 * @param page 現在の Page Class
	 * @param parameter 引き継ぐ Parameter
	 * @param pageClass Redirect先のPage Class
	 */
	public static void setRedirectWithParameter(
			Page page, Object parameter, Class pageClass){
		String seq = CreateSeq();
		page.getContext().getSession().
			setAttribute(seq, parameter);
		page.setRedirect(page.getContext().getPagePath(pageClass) 
				+ "?seq=" + seq);		
	}
	/**
	 * setRedirectWithParameterでRedirect された Pageで、渡された Parameterを取得する
	 * @param page
	 * @return Parameterを返す
	 */
	public static Object getParameterFromSession(Page page){
		String seq = page.getContext().getRequest().getParameter("seq");
		Object parameter = null;
		if (seq != null){
			parameter = page.getContext().getSession().
			getAttribute(seq);
			page.getContext().getSession().removeAttribute(seq);
		}		
		return parameter;
	}
	/**
	 * GrayboxのJavascriptをCopyする
	 * @param context
	 */
	public static void copyGrayboxJs(Context context)
	{
		if (greyboxCopied){
			return;
		}
		greyboxCopied = true;	
        String destination = getDestination(context.getServletContext());	
        try {
            File destinationFile = new File(destination);
            if (!destinationFile.exists()) {
                InputStream inputStream =
                    ClickUtils.class.getResourceAsStream(
                    		"/org/seasar/s2click/control/greybox/setfields-org.js"); 
	//			FileOutputStream fos = new FileOutputStream(destinationFile);
				FileWriter writer = new FileWriter(destination);
				writer.write("var GB_IMG_DIR = \"" +context.getRequest().getContextPath()
						+"/click/greybox/"+"\"\n;");
				InputStreamReader inputReader = new InputStreamReader(inputStream );
				BufferedReader bufferedReader = new BufferedReader(inputReader);
				String line;
				while ((line = bufferedReader.readLine()) != null){
					writer.write(line+"\n"); 
				}
				writer.close();
				inputStream.close();
            }

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		
	}
	/**
	 * GrayboxのJavascriptを除去する
	 * @param context
	 */
	public static void removeGrayboxJs(ServletContext context){
        String destination = getDestination(context);	
        File destinationFile = new File(destination); 
        if (destinationFile.exists()) {
        	destinationFile.delete();
        }
	}
	/**
	 * @param context
	 * @return
	 */
	private static String getDestination(ServletContext context) {
		String destination = context.getRealPath("/")+"click" +
        File.separator +"greybox" +File.separator +"setfields.js";
		return destination;
	}
	/**
	 * @param date
	 * @return
	 */
	public static String getDataYYMMDD(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy/MM/dd");
		return dateFormat.format(date);
	}
	/**
	 * @param date
	 * @return
	 */
	public static String getDataYYYYMMDD(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		return dateFormat.format(date);
	}
	/**
	 * @param value
	 * @return
	 */
	public static Date convDataYYMMDD(String value){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy/MM/dd");
		try {
			return dateFormat.parse(value);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * @param value
	 * @return
	 */
	public static Date convDataYYYYMMDD(String value){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		try {
			return dateFormat.parse(value);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}	
	
}
