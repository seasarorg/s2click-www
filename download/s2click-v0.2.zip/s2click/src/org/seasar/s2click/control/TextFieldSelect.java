/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.control;

import java.text.MessageFormat;

import javax.servlet.ServletContext;

import net.sf.click.control.TextField;
import net.sf.click.util.ClickUtils;

import org.seasar.s2click.util.Utility;
/**
 * Text Fieldで、付属のボタンを押すと、grayboxが開きDataを取得出来る
 * @author shimura
 *
 */
public class TextFieldSelect  extends TextField {
	private static final long serialVersionUID = 1L;
	protected static final String HTML_IMPORTS =
        "<link type=\"text/css\" rel=\"stylesheet\" href=\"{0}/click/greybox/greybox.css\"/>\n"
        + "<script type=\"text/javascript\" src=\"{0}/click/greybox/AJS_compressed.js\"></script>\n"
        + "<script type=\"text/javascript\" src=\"{0}/click/greybox/greybox_compressed.js\"></script>\n"
        + "<script type=\"text/javascript\" src=\"{0}/click/greybox/setfields.js\"></script>\n";
    protected static final String[] GREYBOX_RESOURCES =
    { "AJS_compressed.js", "blank.gif", "blank.html", "close.gif",
      "greybox_compressed.js", "greybox_nav_compressed.js", "greybox.css",
      "header_bg.gif", "indicator.gif", "loader_frame.html", 
      "next.gif", "overlay_dark.png", "overlay_light.png", "prev.gif",
      "edit-button.gif"};
	protected Image image = new Image();
	public TextFieldSelect(){
		
	}
	TextFieldSelect(String name, boolean required){
		super(name, required);
	}
    public TextFieldSelect(String name, String label) {
        super(name, label);
    }
    public TextFieldSelect(String name, String label, boolean required) {
        super(name, label,required);
    }
    public TextFieldSelect(String name, String label, int size) {
        super(name, label, size);
    }

	public void setImageSrc(String src) {
		 image.setSrc(src);
	}
	public void setSelectPage(String windowTitle, String path)
	{
		image.setAttribute("onclick","S2C_SHOW_URL('"+getId()+"','"+"windowTitle"+"','"+ path + "')");
	}
	@Override
	public String toString() {
		Utility.copyGrayboxJs(getForm().getContext());
		return super.toString() + imageToString();
	}
	private String imageToString(){
		if (image.getName()==null){
			image.setName(getName()+"_s2img");
		}
		if (image.getSrc() == null){
			image.setSrc(getContext().getRequest().getContextPath()+
					"/click/greybox/edit-button.gif");
		}
		return image.toString();
	}
    public void onDeploy(ServletContext servletContext) {
        for (int i = 0; i < GREYBOX_RESOURCES.length; i++) {
            String greyboxFilename = GREYBOX_RESOURCES[i];
            String greyboxResource =
                "/org/seasar/s2click/control/greybox/" + greyboxFilename;

            ClickUtils.deployFile(servletContext,
                                  greyboxResource,
                                  "click/greybox");
        }
        Utility.removeGrayboxJs(servletContext);    
    }
    public String getHtmlImports() {
        String[] args = {
            getContext().getRequest().getContextPath()
        };
        return MessageFormat.format(HTML_IMPORTS, args);
    }
}
