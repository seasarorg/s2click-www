/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.control;

import net.sf.click.control.Field;
import net.sf.click.util.HtmlStringBuffer;

/**
 * Textを表示するField
 * @author shimura
 *
 */
public class Text extends Field {
	private static final long serialVersionUID = 1L;
	private String paraValue;
	public Text(){
		
	}
	public Text(String name, String paragraph){
		setName(name);
		setString(paragraph);
		setLabel("");
	}
	public Text(String name, String paragraph, String label){
		setName(name);
		setString(paragraph);
		setLabel(label);
	}
	public String getType(){
		return "paragraph";
	}
	public String toString(){
		HtmlStringBuffer buffer = new HtmlStringBuffer(48);
        buffer.elementStart("span");
        if (hasAttributes()) {
            buffer.appendAttributes(getAttributes());
        }
        buffer.closeTag();
		buffer.append(getString());
		buffer.elementEnd("span");

		return buffer.toString();
	}
	public void setString(String s) {
		paraValue = s;
	}
	public String getString(){
		return paraValue;
	}

}
