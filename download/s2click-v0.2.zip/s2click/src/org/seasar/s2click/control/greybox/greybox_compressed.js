var GB_CURRENT=null;
var GB_ONLY_ONE=null;
GB_initOneIfNeeded=function(){
if(!GB_ONLY_ONE){
GB_ONLY_ONE=new GreyBox();
}
};
GB_show=function(_1,_2,_3,_4,_5){
GB_initOneIfNeeded();
GB_ONLY_ONE.defaultSize();
GB_ONLY_ONE.setFullScreen(false);
GB_ONLY_ONE.setType("page");
GB_ONLY_ONE.setCallback(_5);
GB_ONLY_ONE.setDimension(_4,_3);
GB_ONLY_ONE.show(_1,_2);
return false;
};
GB_showFullScreen=function(_6,_7,_8){
GB_initOneIfNeeded();
GB_ONLY_ONE.defaultSize();
GB_ONLY_ONE.setType("page");
GB_ONLY_ONE.setCallback(_8);
GB_ONLY_ONE.setFullScreen(true);
GB_ONLY_ONE.show(_6,_7);
return false;
};
GB_showImage=function(_9,_a){
GB_initOneIfNeeded();
GB_ONLY_ONE.defaultSize();
GB_ONLY_ONE.setFullScreen(false);
GB_ONLY_ONE.setType("image");
GB_ONLY_ONE.show(_9,_a);
return false;
};
GB_hide=function(){
GB_CURRENT.hide();
};
function GreyBox(){
this.type="page";
this.overlay_click_close=true;
if(GB_IMG_DIR){
this.img_dir=GB_IMG_DIR;
}else{
this.img_dir="greybox/";
}
this.overlay_color="dark";
this.center_window=false;
this.defaultSize();
this.showCloseImage(true);
this.url="";
this.caption="";
this.callback_fn=[];
this.reload_on_close=false;
}
GreyBox.prototype={setDimension:function(_b,_c){
this.height=_c;
this.width=_b;
},setFullScreen:function(_d){
this.full_screen=_d;
},setType:function(_e){
this.type=_e;
},setCenterWindow:function(_f){
this.center_window=_f;
},setImageDir:function(dir){
this.img_dir=dir;
},showCloseImage:function(_11){
this.show_close_img=_11;
},setOverlayCloseClick:function(_12){
this.overlay_click_close=_12;
},setOverlayColor:function(_13){
this.overlay_color=_13;
},setCallback:function(fn){
if(fn){
this.callback_fn.push(fn);
}
},show:function(_15,url){
GB_CURRENT=this;
this.url=url;
this.caption=_15;
AJS.map(AJS.$bytc("div","GB_dummy"),function(elm){
AJS.removeElement(elm);
});
AJS.map(AJS.$bytc("div","GB_loader"),function(elm){
AJS.removeElement(elm);
});
var _19=[AJS.$bytc("object"),AJS.$bytc("embed")];
if(AJS.isIe()){
_19.push(AJS.$bytc("select"));
}
AJS.map(AJS.flattenList(_19),function(elm){
elm.style.visibility="hidden";
AJS.log(elm);
});
this.initOverlayIfNeeded();
this.setOverlayDimension();
AJS.showElement(this.overlay);
this.setFullScreenOption();
this.initIfNeeded();
AJS.hideElement(this.g_window);
if(_15==""){
_15="&nbsp;";
}
this.div_caption.innerHTML=_15;
this.setVerticalPosition();
this.setWidthNHeight();
this.setTopNLeft();
AJS.showElement(this.g_window);
GB_CURRENT.startLoading();
return false;
},hide:function(){
AJS.hideElement(this.g_window,this.overlay);
this.destroyIframe();
if(this.type=="image"){
this.width=200;
this.height=200;
}
if(AJS.isIe()){
AJS.map(AJS.$bytc("select"),function(elm){
elm.style.visibility="visible";
});
}
AJS.map(AJS.$bytc("object"),function(elm){
elm.style.visibility="visible";
});
var _1d=GB_CURRENT.callback_fn;
if(_1d!=[]){
AJS.map(_1d,function(fn){
fn();
});
}
GB_CURRENT=null;
if(this.reload_on_close){
window.location.reload();
}
},init:function(){
this.g_window=AJS.DIV({"id":"GB_window"});
var _1f=AJS.TABLE({"class":"GB_t_frame","frameborder":0});
var _20=AJS.TBODY();
AJS.ACN(_1f,_20);
var _21=AJS.TD({"class":"GB_content"});
this.td_middle_m=_21;
AJS.ACN(_20,AJS.TR(_21));
var _22=AJS.TABLE({"class":"GB_header"});
this.header=_22;
var _23=AJS.TD({"class":"GB_caption"});
this.div_caption=_23;
_22.style.backgroundImage="url("+this.img_dir+"header_bg.gif)";
tbody_header=AJS.TBODY();
this.nav_bar=AJS.TD({"class":"GB_nav"});
if(AJS.isOpera()){
this.nav_bar.style.paddingTop="3px";
this.nav_bar.style.paddingBottom="5px";
}
if(this.show_close_img){
var btn=this.createNavButton("Close",this.img_dir+"close.gif",GB_hide);
AJS.ACN(this.nav_bar,btn);
}
AJS.ACN(tbody_header,AJS.TR(_23,this.nav_bar));
AJS.ACN(_22,tbody_header);
AJS.ACN(_21,_22);
this.g_container=AJS.DIV({"class":"GB_container"});
AJS.ACN(_21,this.g_container);
AJS.ACN(this.g_window,_1f);
AJS.getBody().insertBefore(this.g_window,this.overlay.nextSibling);
},initIfNeeded:function(){
this.init();
this.setWidthNHeight=AJS.$b(this.setWidthNHeight,this);
this.setTopNLeft=AJS.$b(this.setTopNLeft,this);
this.setFullScreenOption=AJS.$b(this.setFullScreenOption,this);
this.setOverlayDimension=AJS.$b(this.setOverlayDimension,this);
this.g_container.style.marginBottom="-3px";
var fn=function(){
this.setFullScreenOption();
this.setOverlayDimension();
this.setVerticalPosition();
this.setTopNLeft();
this.setWidthNHeight();
};
AJS.AEV(window,"scroll",AJS.$b(fn,this));
AJS.AEV(window,"resize",AJS.$b(fn,this));
this.initIframe();
},initOverlayIfNeeded:function(){
this.overlay=AJS.DIV({"id":"GB_overlay"});
if(AJS.isIe()){
this.overlay.style.backgroundColor="#000000";
this.overlay.style.backgroundColor="transparent";
this.overlay.style.backgroundImage="url("+this.img_dir+"blank.gif)";
this.overlay.runtimeStyle.filter="progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+this.img_dir+this.getOverlayImage()+"',sizingMethod='scale')";
}else{
this.overlay.style.backgroundImage="url("+this.img_dir+this.getOverlayImage()+")";
}
if(this.overlay_click_close){
AJS.AEV(this.overlay,"click",GB_hide);
}
AJS.getBody().insertBefore(this.overlay,AJS.getBody().firstChild);
},initIframe:function(){
if(!this.iframe){
var _26;
var d={"name":"GB_frame","class":"GB_frame","frameBorder":0};
_26=AJS.IFRAME(d);
this.iframe=_26;
AJS.hideElement(this.iframe);
AJS.ACN(this.g_container,this.iframe);
this.setIframeWidthNHeight();
}
},getOverlayImage:function(){
return "overlay_"+this.overlay_color+".png";
},createNavButton:function(_28,_29,_2a,_2b){
var btn=AJS.SPAN({"class":"GB_navItem"});
var _2d=AJS.IMG({"src":_29});
var _2e=AJS.SPAN(_28);
AJS.ACN(btn,_2d,_2e);
if(!_2b){
_2b=function(){
return true;
};
}
AJS.AEV(btn,"click",function(e){
AJS.preventDefault(e);
if(_2b(btn)){
_2a(e);
AJS.removeClass(_2e,"GB_navClick");
}
});
AJS.AEV(btn,"mousedown",function(e){
if(_2b(btn)){
AJS.addClass(_2e,"GB_navClick");
}
});
AJS.AEV(btn,"mouseover",function(e){
if(_2b(btn)){
AJS.addClass(_2e,"GB_navOver");
}
});
AJS.AEV(btn,"mouseout",function(e){
if(_2b(btn)){
AJS.removeClass(_2e,"GB_navOver");
}
});
return btn;
},destroyIframe:function(){
try{
AJS.removeElement(this.iframe);
}
catch(e){
}
this.iframe=null;
},startLoading:function(){
this.iframe.src=this.img_dir+"loader_frame.html";
AJS.showElement(this.iframe);
},setIframeWidthNHeight:function(){
try{
AJS.setWidth(this.iframe,this.width);
if(AJS.isMozilla()||AJS.isOpera()){
AJS.setHeight(this.iframe,this.height-3);
}else{
AJS.setHeight(this.iframe,this.height);
}
}
catch(e){
}
},setOverlayDimension:function(){
var _33=AJS.getWindowSize();
if((navigator.userAgent.toLowerCase().indexOf("firefox")!=-1)){
AJS.setWidth(this.overlay,"100%");
}else{
AJS.setWidth(this.overlay,_33.w);
}
var _34=Math.max(AJS.getScrollTop()+_33.h,AJS.getScrollTop()+this.height);
if(_34<AJS.getScrollTop()){
AJS.setHeight(this.overlay,_34);
}else{
AJS.setHeight(this.overlay,AJS.getScrollTop()+_33.h);
}
},setWidthNHeight:function(){
AJS.setWidth(this.g_window,this.width);
AJS.setHeight(this.g_window,this.height);
AJS.setWidth(this.g_container,this.width);
AJS.setHeight(this.g_container,this.height);
AJS.setWidth(this.td_middle_m,this.width+10);
this.setIframeWidthNHeight();
},setTopNLeft:function(){
var _35=AJS.getWindowSize();
AJS.setLeft(this.g_window,((_35.w-this.width)/2)-13);
if(this.center_window){
var fl=((_35.h-this.height)/2)-15+AJS.getScrollTop();
AJS.setTop(this.g_window,fl);
}else{
if(this.g_window.offsetHeight<_35.h){
AJS.setTop(this.g_window,AJS.getScrollTop());
}
}
},setVerticalPosition:function(){
var _37=AJS.getWindowSize();
var st=AJS.getScrollTop();
if(this.g_window.offsetWidth<=_37.h||st<=this.g_window.offsetTop){
AJS.setTop(this.g_window,st);
}
},setFullScreenOption:function(){
if(this.full_screen){
var _39=AJS.getWindowSize();
overlay_h=_39.h;
this.width=Math.round(this.overlay.offsetWidth-(this.overlay.offsetWidth/100)*10);
this.height=Math.round(overlay_h-(overlay_h/100)*10);
}
},defaultSize:function(){
this.width=300;
this.height=300;
}};
GreyBox.preloadGreyBoxImages=function(_3a){
var _3b=[];
if(!_3a){
_3a=GB_IMG_DIR;
}
var fn=function(_3d){
var pic=new Image();
pic.src=GB_IMG_DIR+_3d;
_3b.push(pic);
};
AJS.map(["indicator.gif","blank.gif","close.gif","header_bg.gif","overlay_light.png","overlay_dark.png"],AJS.$b(fn,this));
};
script_loaded=true;

