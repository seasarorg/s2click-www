/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.control;

import java.text.MessageFormat;

import net.sf.click.control.Button;

/**
 * 呼び出し元のPageにDataをSetするボタン
 * @author shimura
 *
 */
public class ButtonDataSetParent extends Button {
	private static final long serialVersionUID = 1L;
	protected static final String HTML_IMPORTS =
        "<script type=\"text/javascript\" src=\"{0}/click/greybox/setfield_form.js\"></script>\n";
    public ButtonDataSetParent() {
    }
    public ButtonDataSetParent(String name) {
        super(name);
    }
    public ButtonDataSetParent(String name, String label) {
    	super(name, label);
    }
	public void setData(String data){
		setAttribute("onclick", "S2C_SET('"+data+ "')");
	}
	
	public String toString(){
		String renderString = "";
		if (this.getForm()==null &&  this.context.getRequest().getAttribute("__S2_setfield_form") == null){
			renderString = getHtmlImports();
			this.context.getRequest().setAttribute("__S2_setfield_form","rendered");
		}
		return renderString + super.toString();
	}

    public String getHtmlImports() {
        String[] args = {
            getContext().getRequest().getContextPath()
        };

        return MessageFormat.format(HTML_IMPORTS, args);
    }
}
