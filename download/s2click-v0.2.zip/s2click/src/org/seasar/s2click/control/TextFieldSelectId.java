/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.control;

import net.sf.click.control.Field;

/**
 * Text Fieldで、付属のボタンを押すと、grayboxが開きIDを取得出来る 
 * @author shimura
 *
 */
public class TextFieldSelectId extends TextFieldSelect {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Field idField;
	public TextFieldSelectId(){
		
	}
	TextFieldSelectId(String name, boolean required){
		super(name, required);
		this.readonly = true;
	}
    public TextFieldSelectId(String name, String label) {
        super(name, label);
		this.readonly = true;
    }
    public TextFieldSelectId(String name, String label, boolean required) {
        super(name, label,required);
		this.readonly = true;
    }
    public TextFieldSelectId(String name, String label, int size) {
        super(name, label, size);
		this.readonly = true;
    }
	public Field getIdField() {
		return idField;
	}
	public void setIdField(Field idField) {
		this.idField = idField;
	}
	public void setSelectPage(String windowTitle, String path)
	{
		if (idField==null) {
			throw new RuntimeException("ID Field Not Set");
		}
		image.setAttribute("onclick","S2C_ID_SHOW_URL('"+getId()+"','"+idField.getId()+"','"+"windowTitle"+"','"+ path + "')");
	}
}
