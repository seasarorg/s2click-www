/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.control;

import java.text.MessageFormat;

import javax.servlet.ServletContext;

import net.sf.click.util.ClickUtils;

/**
 * クリックしたら、呼び出し元のPageにDataをSetするImage 
 * @author shimura
 *
 */
public class ImageDataSetParent extends Image {

	private static final long serialVersionUID = 1L;
	protected static final String HTML_IMPORTS =
       "<script type=\"text/javascript\" src=\"{0}/click/greybox/setfield_form.js\"></script>\n";
    protected static final String[] GREYBOX_RESOURCES =
    {"setfield_form.js"  	
    };
    public ImageDataSetParent() {
     }
    public ImageDataSetParent(String name) {
    	super(name,null);
    }
    public ImageDataSetParent(String name, String src) {
    	super(name,src);
    }
	public ImageDataSetParent(String name, String label, String src){
		super(name, label, src);
	}
	public void setData(String data){
		setAttribute("onclick", "S2C_SET('"+data+ "')");
	}
	public String toString(){
		String renderString = "";
		if (super.getSrc()==null){
			String path = getContext().getRequest().getContextPath();
			super.setSrc(path+
					"/click/greybox/edit-button.gif");
		}
		if (this.getForm()==null &&  this.context.getRequest().getAttribute("__S2_setfield_form") == null){
//	        String[] args = {
//	                getContext().getRequest().getContextPath()
//	            };
//
//	        renderString = MessageFormat.format(HTML_IMPORTS, args);
			renderString = getHtmlImports();
			this.context.getRequest().setAttribute("__S2_setfield_form","rendered");
		}
		return renderString + super.toString();
	}
    public void onDeploy(ServletContext servletContext) {
        // Deploy DateField resources files
        for (int i = 0; i < GREYBOX_RESOURCES.length; i++) {
            String greyboxFilename = GREYBOX_RESOURCES[i];
            String greyboxResource =
                "/org/seasar/s2click/control/greybox/" + greyboxFilename;

            ClickUtils.deployFile(servletContext,
                                  greyboxResource,
                                  "click/greybox");
        }
    }
    public String getHtmlImports() {
        String[] args = {
            getContext().getRequest().getContextPath()
        };

        return MessageFormat.format(HTML_IMPORTS, args);
    }
}
