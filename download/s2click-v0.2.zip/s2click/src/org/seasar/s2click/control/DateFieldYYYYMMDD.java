/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.control;

import java.text.SimpleDateFormat;

import net.sf.click.extras.control.DateField;

/**
 * YYYY/MM/DDで表示される DatePicker付 Date Field
 * @author shimura
 *
 */
public class DateFieldYYYYMMDD extends DateField {
 /**
  * 
  */
 private static final long serialVersionUID = 1L;
	public DateFieldYYYYMMDD(){
		super();
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name){
		super(name);
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name, boolean required){
		super(name, required);
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name, String label){ 
		super(name, label);
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name, String label, boolean required){
		super(name, label, required); 
		setYYYYMMDD();
	}
	private void setYYYYMMDD(){
		dateFormat=new SimpleDateFormat("yyyy/MM/dd");				  
		super.setFormatPattern("yyyy/MM/dd");	 
	}
	public void validate() {
        super.validate();
   		String s = getValue();
    		
		int pos = s.indexOf("/");
		if (pos!=-1 && pos !=4){
			Object[] args = new Object[] {
                    getErrorLabel(), formatPattern
                };
        	setError(getMessage("date-format-error", args));
        	return;
		}		
	

	}

}


