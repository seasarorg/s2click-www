
package org.seasar.s2click.example.dao.bsbhv;

import org.seasar.s2click.example.dao.allcommon.*;
import org.seasar.s2click.example.dao.allcommon.cbean.ConditionBean;
import org.seasar.s2click.example.dao.allcommon.cbean.ListResultBean;
import org.seasar.s2click.example.dao.allcommon.cbean.PagingBean;
import org.seasar.s2click.example.dao.allcommon.cbean.PagingResultBean;
import org.seasar.s2click.example.dao.allcommon.dbmeta.DBMeta;
  
import org.seasar.s2click.example.dao.exbhv.*;
  
import org.seasar.s2click.example.dao.exdao.*;
import org.seasar.s2click.example.dao.exentity.*;
import org.seasar.s2click.example.dao.bsentity.dbmeta.*;
import org.seasar.s2click.example.dao.cbean.*;



/**
 * The behavior of employee.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class BsEmployeeBhv extends org.seasar.s2click.example.dao.allcommon.bhv.AbstractBehaviorWritable {

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    /** Dao instance. */
    protected EmployeeDao _dao;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public BsEmployeeBhv() {
    }

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return "employee";
    }

    // =====================================================================================
    //                                                                                DBMeta
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return EmployeeDbm.getInstance();
    }

    /**
     * Get my dbmeta.
     * 
     * @return DBMeta. (NotNull)
     */
    public EmployeeDbm getMyDBMeta() {
        return EmployeeDbm.getInstance();
    }

    // =====================================================================================
    //                                                                          Dao Accessor
    //                                                                          ============
    /**
     * Get my dao.
     * 
     * @return My dao.
     */
    public EmployeeDao getMyDao() {
        return _dao;
    }

    /**
     * Set my dao.
     * 
     * @param dao My dao. (NotNull)
     */
    public void setMyDao(EmployeeDao dao) {
        assertObjectNotNull("dao", dao);
        _dao = dao;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable getDaoReadable() {
        return getMyDao();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Dao-writable. (NotNull)
     */
    public DaoWritable getDaoWritable() {
        return getMyDao();
    }

    // =====================================================================================
    //                                                                          New Instance
    //                                                                          ============
    /**
     * New entity.
     * 
     * @return Entity. (NotNull)
     */
    public Entity newEntity() {
        return newMyEntity();
    }

    /**
     * New condition-bean.
     * 
     * @return Condition-bean. (NotNull)
     */
    public ConditionBean newConditionBean() {
        return newMyConditionBean();
    }

    /**
     * New my entity.
     * 
     * @return My entity. (NotNull)
     */
    public Employee newMyEntity() {
        return new Employee();
    }

    /**
     * New my condition-bean.
     * 
     * @return My condition-bean. (NotNull)
     */
    public EmployeeCB newMyConditionBean() {
        return new EmployeeCB();
    }

    // =====================================================================================
    //                                                                       Delegate Method
    //                                                                       ===============
    /**
     * Get count as all. (Delegate-Method)
     * 
     * @return All count. (NotNull)
     */
    public int delegateGetCountAll() {
        return getMyDao().getCountAll();
    }

    /**
     * Get list as all. (Delegate-Method)
     * 
     * @return All list. (NotNull)
     */
    public java.util.List<Employee> delegateGetListAll() {
        return getMyDao().getListAll();
    }

    //
    // Get entity. (Delegate-Method)
    // 
    // @param Primary-keys (NotNull)
    // @return Entity. (NotNull)
    //
    public Employee delegateGetEntity(java.math.BigDecimal id) {
        return getMyDao().getEntity(id);
    }

    /**
     * Select count by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     */
    public int delegateSelectCount(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectCount(cb);
    }

    /**
     * Select count ignore fetch scope by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     * @deprecated This method is deprecated. Please use delegateSelectCount()!
     */
    public int delegateSelectCountIgnoreFetchScope(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectCountIgnoreFetchScope(cb);
    }

    /**
     * Select entity by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. If the select result is zero, it returns null. (Nullable)
     */
    public Employee delegateSelectEntity(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectEntity(cb);
    }

    /**
     * Select list by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list. If the select result is zero, it returns empty list. (NotNull)
     */
    public java.util.List<Employee> delegateSelectList(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectList(cb);
    }



    /**
     * Insert one entity. (Delegate-Method)
     * 
     * @param entity Entity. (NotNull)
     * @return Inserted count.
     */
    public int delegateInsert(Employee entity) {
        assertEntityNotNull(entity);// If this table use identity, the entity does not have primary-key.
        filterEntityOfInsert(entity);
        assertEntityOfInsert(entity);
        return getMyDao().insert(entity);
    }

    /**
     * Update one entity. (Delegate-Method)
     * {modified only}
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int delegateUpdate(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        filterEntityOfUpdate(entity);
        assertEntityOfUpdate(entity);
        return getMyDao().updateModifiedOnly(entity);
    }

    /**
     * Delete one entity. (Delegate-Method)
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delegateDelete(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        filterEntityOfDelete(entity);
        assertEntityOfDelete(entity);
        return getMyDao().delete(entity);
    }

    /**
     * Insert several entities. (Delegate-Method)
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Inserted count.
     */
    public int delegateInsertList(java.util.List<Employee> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return getMyDao().insertList(entityList);
    }

    /**
     * Update several entities. (Delegate-Method)
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Updated count.
     */
    public int delegateUpdateList(java.util.List<Employee> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return getMyDao().updateList(entityList);
    }

    /**
     * Delete several entities. (Delegate-Method)
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Deleted count.
     */
    public int delegateDeleteList(java.util.List<Employee> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return getMyDao().deleteList(entityList);
    }

    // =====================================================================================
    //                                                                    Basic Select Count
    //                                                                    ==================
    /**
     * Select count by condition-bean.
     * <pre>
     * If the argument 'condition-bean' is effective about fetch-scope,
     * this method invoke select count ignoring the fetch-scope.
     * </pre>
     * @param cb Condition-bean. This condition-bean should not be set up about fetch-scope. (NotNull)
     * @return Selected count.
     */
    public int selectCount(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return delegateSelectCount(cb);
    }

    // =====================================================================================
    //                                                                   Basic Select Entity
    //                                                                   ===================
    /**
     * Select entity by condition-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. (Nullalble)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasOverlappedException
     */
    public Employee selectEntity(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        final java.util.List<Employee> ls = selectList(cb);
        if (ls.isEmpty()) {
            return null;
        }
        assertRecordHasBeenSelectedAsOne(ls, cb.toString());
        return (Employee)ls.get(0);
    }

    /**
     * Select entity by condition-bean with deleted check.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. (NotNull)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasOverlappedException
     */
    public Employee selectEntityWithDeletedCheck(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        final java.util.List<Employee> ls = selectList(cb);
        assertRecordHasNotBeenDeleted(ls, cb.toString());
        assertRecordHasBeenSelectedAsOne(ls, cb.toString());
        return (Employee)ls.get(0);
    }

    /*
     * Select entity with deleted check. {by primary-key}
     * 
     * @param primaryKey
     * @return Selected entity. (NotNull)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasOverlappedException
     */
    public Employee selectByPKValueWithDeletedCheck(java.math.BigDecimal id) {
        Employee entity = new Employee();
        entity.setId(id);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
        return selectEntityWithDeletedCheck(cb);
    }

    /*
     * Select entity for update with deleted check. {by primary-key}
     * 
     * @param primaryKey
     * @return Selected entity. (NotNull)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasOverlappedException
     */
    public Employee selectByPKValueWithDeletedCheckForUpdate(java.math.BigDecimal id) {
        Employee entity = new Employee();
        entity.setId(id);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
        cb.lockForUpdate();
        return selectEntityWithDeletedCheck(cb);
    }

    // =====================================================================================
    //                                                                     Basic Select List
    //                                                                     =================
    /**
     * Select list as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list-result-bean. (NotNull)
     */
    public ListResultBean<Employee> selectList(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return new ResultBeanBuilder<Employee>(this).buildListResultBean(cb, delegateSelectList(cb));
    }

    /**
     * Select page as result-bean.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected paging-result-bean. (NotNull)
     */
    public PagingResultBean<Employee> selectPage(final EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return selectPage(cb, new SelectPageSimpleInvoker<Employee>(this));
    }

    /**
     * Select page.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Selected paging-result-bean. (NotNull)
     */
    public PagingResultBean<Employee> selectPage(final EmployeeCB cb, SelectPageInvoker<Employee> invoker) {
        assertConditionBeanNotNull(cb);
        final SelectPageCallback<Employee> pageCallback = new SelectPageCallback<Employee>() {
            public PagingBean getPagingBean() { return cb; }
            public int selectCountIgnoreFetchScope() {
                return selectCount(cb);
            }
            public java.util.List<Employee> selectListWithFetchScope() {
                return selectList(cb);
            }
        };
        return invoker.invokeSelectPage(pageCallback);
    }



    // This is deprecated!!!
    /**
     * Select list after checking count(ignore fetch scope).
     * 
     * @param cb Condition-bean. (NotNull)
     * @param maxCount Max count.
     * @return List-result-bean. (NotNull)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.SelectedCountExceedMaxCountException
     * @deprecated Please don't use this.
     */
    public ListResultBean selectListAfterCheckingCountIgnoreFetchScope(EmployeeCB cb, int maxCount) {
        assertConditionBeanNotNull(cb);
        final int selectedCount = selectCount(cb);
        assertSelectedCountHasNotExceededMaxCount(selectedCount, maxCount, cb.toString());
        return selectList(cb);
    }
  
    // This is deprecated!!!
    /**
     * @deprecated Please use selectByPKValueWithDeletedCheck().
     */
    public Employee selectForReadOnlyByPKValueWithDeletedCheck(java.math.BigDecimal id) {
        Employee entity = new Employee();
        entity.setId(id);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
        return selectEntityWithDeletedCheck(cb);
    }
  
    // =====================================================================================
    //                                                                         Load Refferer
    //                                                                         =============
  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ReffererTable    = [employee]
    //   ReffererProperty = [employeeSelfList]
    // * * * * * * * * */

    /**
     * Load refferer of employeeSelfList.
     * 
     * Default refferer order-by is 'primary-key asc'.
     * <pre>
     *   ex) Refferer order-by is Manager.
     * 
     *     final BsEmployeeBhv bhv = (BsEmployeeBhv)getDaoSelector().getRBhv(BsEmployeeBhv.class);
     *     final EmployeeCB cb = bhv.newMyConditionBean();
     *     cb.query().setXxx_Equal("xxx");
     *     final List<Employee> ls = bhv.selectList(cb);
     *     bhv.loadEmployeeSelfList(ls);
     * 
     *  *About internal policy, the value of primary key(and others too) is treated as CaseInsensitive.
     * </pre>
     * 
     * @param ls Entity list of main table. (NotNull)
     */
    public void loadEmployeeSelfList(java.util.List<Employee> ls) {
        final EmployeeBhv.CBSetupper cbSetupper = new EmployeeBhv.CBSetupper() {
            public void setup(EmployeeCB cb) {
                cb.addOrderBy_PK_Asc();// Default OrderBy for Refferer.
            }
        };
        loadEmployeeSelfList(ls, cbSetupper);
    }

    /**
     * Load refferer of employeeSelfList.
     * 
     * <pre>
     *   ex) Refferer order-by is Manager.
     * 
     *     final BsEmployeeBhv bhv = (BsEmployeeBhv)getDaoSelector().getRBhv(BsEmployeeBhv.class);
     *     final EmployeeCB cb = bhv.newMyConditionBean();
     *     cb.query().setXxx_Equal("xxx");
     *     final List<Employee> ls = bhv.selectList(cb);
     *     final EmployeeBhv.CBSetupper cbSetupper = new EmployeeBhv.CBSetupper() {
     *         public void setup(EmployeeCB cb) {
     *             cb.query().addOrderBy_Manager_Asc();
     *         }
     *     };
     *     bhv.loadEmployeeSelfList(ls, cbSetupper);
     * 
     *  *About internal policy, the value of primary key(and others too) is treated as CaseInsensitive.
     * </pre>
     * 
     * @param ls Entity list of main table. (NotNull)
     * @param cbSetupper Refferer condition setupper instance for registering refferer condition. (NotNull)
     */
    public void loadEmployeeSelfList(java.util.List<Employee> ls, EmployeeBhv.CBSetupper cbSetupper) {
        assertObjectNotNull("ls", ls);
        assertObjectNotNull("cbSetupper", cbSetupper);
        if (ls.isEmpty()) {
            return;
        }

        final java.util.Map<java.math.BigDecimal, Employee> pkMyEntityMap = new java.util.LinkedHashMap<java.math.BigDecimal, Employee>();
        final java.util.List<java.math.BigDecimal> pkList = new java.util.ArrayList<java.math.BigDecimal>();
        for (final java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final Employee entity = (Employee)ite.next();
            pkList.add(entity.getId());
            pkMyEntityMap.put((java.math.BigDecimal)toLowerCaseIfString(entity.getId()), entity);
        }
        final EmployeeBhv reffererBhv = (EmployeeBhv)getDaoSelector().getRBhv(EmployeeBhv.class);
        final EmployeeCB cb = reffererBhv.newMyConditionBean();
        cb.query().setManager_InScope(pkList);
        cb.query().addOrderBy_Manager_Asc();
        cbSetupper.setup(cb);
        final java.util.List<Employee> reffererList = reffererBhv.selectList(cb);

        final java.util.Map<java.math.BigDecimal, java.util.List<Employee>> pkReffererListMap;
        pkReffererListMap = new java.util.LinkedHashMap<java.math.BigDecimal, java.util.List<Employee>>();
        for (final java.util.Iterator ite = reffererList.iterator(); ite.hasNext(); ) {
            final Employee reffererEntity = (Employee)ite.next();
            if (!pkReffererListMap.containsKey(toLowerCaseIfString(reffererEntity.getManager()))) {
                pkReffererListMap.put((java.math.BigDecimal)toLowerCaseIfString(reffererEntity.getManager()), new java.util.ArrayList<Employee>());
            }
            ((java.util.List<Employee>)pkReffererListMap.get(toLowerCaseIfString(reffererEntity.getManager()))).add(reffererEntity);

            // for Reverse Reference.
            final Employee myEntity = (Employee)pkMyEntityMap.get(toLowerCaseIfString(reffererEntity.getManager()));
            reffererEntity.setEmployeeSelf(myEntity);
        }

        for (final java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final Employee entity = (Employee)ite.next();
            if (pkReffererListMap.containsKey(toLowerCaseIfString(entity.getId()))) {
                entity.setEmployeeSelfList((java.util.List<Employee>)pkReffererListMap.get(toLowerCaseIfString(entity.getId())));
            } else {
                entity.setEmployeeSelfList(new java.util.ArrayList<Employee>());
            }
        }
    }
    
    /**
     * The interface of refferer condition for employeeSelfList.
     * 
     * @deprecated Not for public use in the future. Please use EmployeeBhv.CBSetupper.
     */
    public static interface ReffererConditionEmployeeSelfList extends EmployeeBhv.CBSetupper {
    }
      
    // =====================================================================================
    //                                                                   Basic Entity Update
    //                                                                   ===================
    /**
     * Insert.
     * 
     * @param entity Entity. (NotNull)
     */
    public void insert(Employee entity) {
        assertEntityNotNull(entity);
        delegateInsert(entity);
    }

    protected void doCreate(Entity entity) {
        insert((Employee)entity);
    }

    /**
     * Update.
     * 
     * @param entity Entity. (NotNull)
     */
    public void update(Employee entity) {
        assertEntityNotNull(entity);
        final int updatedCount = delegateUpdate(entity);
        if (updatedCount != 1) {
            throw new org.seasar.dao.NotSingleRowUpdatedRuntimeException(entity, updatedCount);
        }
    }

    protected void doModify(Entity entity) {
        update((Employee)entity);
    }

    /**
     * Update after select.
     * 
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public void updateAfterSelect(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
        final Employee currentEntity = selectEntityWithDeletedCheck(cb);
        mergeEntity(entity, currentEntity);
        update(currentEntity);
    }

    protected void doModifyAfterSelect(Entity entity) {
        updateAfterSelect((Employee)entity);
    }

    /**
     * Insert or update after select.
     * {update: modified only}
     * 
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     */
    public void insertOrUpdateAfterSelect(Employee entity) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            insert(entity);
            return;
        }
        Employee currentEntity = null;
        try {
            final EmployeeCB cb = newMyConditionBean();
            cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
            currentEntity = selectEntityWithDeletedCheck(cb);
        } catch (org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException e) {
            insert(entity);
            return;
        }
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        mergeEntity(entity, currentEntity);
        update(currentEntity);
    }

    protected void doCreateOrModifyAfterSelect(Entity entity) {
        insertOrUpdateAfterSelect((Employee)entity);
    }
  
    /**
     * Update after select-for-update.
     * 
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public void updateAfterSelectForUpdate(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
        cb.lockForUpdate();
        final Employee currentEntity = selectEntityWithDeletedCheck(cb);
        mergeEntity(entity, currentEntity);
        update(currentEntity);
    }

    protected void doModifyAfterSelectForUpdate(Entity entity) {
        updateAfterSelectForUpdate((Employee)entity);
    }

    /**
     * Insert or update after select-for-update.
     * {update: modified only}
     * 
     * @param entity Entity. This must contain primary-key value at least(Except use identity). (NotNull)
     */
    public void insertOrUpdateAfterSelectForUpdate(Employee entity) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            insert(entity);
            return;
        }
        Employee currentEntity = null;
        try {
            final EmployeeCB cb = newMyConditionBean();
            cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
            cb.lockForUpdate();
            currentEntity = selectEntityWithDeletedCheck(cb);
        } catch (org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException e) {
            insert(entity);
            return;
        }
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        mergeEntity(entity, currentEntity);
        update(entity);
    }

    protected void doCreateOrModifyAfterSelectForUpdate(Entity entity) {
        insertOrUpdateAfterSelectForUpdate((Employee)entity);
    }
  
    /**
     * This method implements the method that is declared at super.
     * 
     * @param sourceEntity Source entity. (NotNull)
     * @param destinationEntity Destination entity. (NotNull)
     */
    protected void mergeEntity(Entity sourceEntity, Entity destinationEntity) {
        assertEntityNotNull(sourceEntity);
        assertEntityNotNull(destinationEntity);
        final Employee sourceMyEntity = (Employee)sourceEntity;
        final Employee destinationMyEntity = (Employee)destinationEntity;
        destinationMyEntity.clearModifiedPropertyNames();
        final java.util.Set<String> names = sourceMyEntity.getModifiedPropertyNames();
  
        if (names.contains("id")) {
            destinationMyEntity.setId(sourceMyEntity.getId());
        }
  
        if (names.contains("empno")) {
            destinationMyEntity.setEmpno(sourceMyEntity.getEmpno());
        }
  
        if (names.contains("empname")) {
            destinationMyEntity.setEmpname(sourceMyEntity.getEmpname());
        }
  
        if (names.contains("job")) {
            destinationMyEntity.setJob(sourceMyEntity.getJob());
        }
  
        if (names.contains("manager")) {
            destinationMyEntity.setManager(sourceMyEntity.getManager());
        }
  
        if (names.contains("hiredate")) {
            destinationMyEntity.setHiredate(sourceMyEntity.getHiredate());
        }
  
        if (names.contains("salary")) {
            destinationMyEntity.setSalary(sourceMyEntity.getSalary());
        }
  
        if (names.contains("deptid")) {
            destinationMyEntity.setDeptid(sourceMyEntity.getDeptid());
        }
  
        if (names.contains("versionno")) {
            destinationMyEntity.setVersionno(sourceMyEntity.getVersionno());
        }
  
    }

    /**
     * Delete.
     * 
     * @param entity Entity. (NotNull)
     */
    public void delete(Employee entity) {
        assertEntityNotNull(entity);
        final int deletedCount = delegateDelete(entity);
        if (deletedCount != 1) {
            throw new org.seasar.dao.NotSingleRowUpdatedRuntimeException(entity, deletedCount);
        }
    }

    protected void doRemove(Entity entity) {
        delete((Employee)entity);
    }

    /**
     * Delete after select.
     * 
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public void deleteAfterSelect(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
        selectEntityWithDeletedCheck(cb);
        delete(entity);
    }

    protected void doRemoveAfterSelect(Entity entity) {
        deleteAfterSelect((Employee)entity);
    }

    // =====================================================================================
    //                                                                    Basic Batch Update
    //                                                                    ==================
    /**
     * Insert list.
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Inserted count.
     */
    public int insertList(java.util.List<Employee> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return delegateInsertList(entityList);
    }

    /**
     * Update list.
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Updated count.
     */
    public int updateList(java.util.List<Employee> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return delegateUpdateList(entityList);
    }

    /**
     * Delete list.
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Deleted count.
     */
    public int deleteList(java.util.List<Employee> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        return delegateDeleteList(entityList);
    }

    // =====================================================================================
    //                                                                        Various Insert
    //                                                                        ==============
      
    /* (non-javadoc) 
     * Copy-insert.
     * 
     * @param primaryKey Primary-keys. (NotNull)
     * @return Inserted count.
     * @exception org.seasar.s2click.example.dao.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public int copyInsertByPKValueAfterSelect(java.math.BigDecimal id) {
        Employee entity = new Employee();
        entity.setId(id);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
        final Employee currentEntity = selectEntityWithDeletedCheck(cb);
        return delegateInsert(currentEntity);
    }
    
    /**
     * Filter 'copy-insert' entity.
     * 
     * @param entity Entity. (NotNull)
     */
    protected void filterCopyInsertEntity(Employee entity) {
    }
  
    // =====================================================================================
    //                                                                            CBSetupper
    //                                                                            ==========
    /**
     * The interface of condition-bean setupper.
     */
    public static interface CBSetupper extends SimpleCBSetupper {
        /**
         * Set up condition.
         * 
         * @param cb Condition-bean. (NotNull)
         */
        public void setup(EmployeeCB cb);
    }
}
