package org.seasar.s2click.example.dao.allcommon;

/**
 * The interface of dao-readable.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface DaoReadable {
    // [Developer's comment] (2006/06/08)
    // It cannot be done for the convenience of s2dao though I want to define methods for condition-bean here.
    // DTO argument as Interface is not accepted.
}
