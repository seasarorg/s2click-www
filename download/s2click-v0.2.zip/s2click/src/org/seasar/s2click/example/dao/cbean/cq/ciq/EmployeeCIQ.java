package org.seasar.s2click.example.dao.cbean.cq.ciq;

import org.seasar.s2click.example.dao.cbean.cq.bs.*;
import org.seasar.s2click.example.dao.cbean.cq.*;

import org.seasar.s2click.example.dao.allcommon.cbean.*;
import org.seasar.s2click.example.dao.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.dao.allcommon.cbean.coption.ConditionOption;
import org.seasar.s2click.example.dao.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.dao.allcommon.cbean.sqlclause.SqlClause;

/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class EmployeeCIQ extends AbstractBsEmployeeCQ {

    protected BsEmployeeCQ _myCQ;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public EmployeeCIQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel, BsEmployeeCQ myCQ) {
        super(childQuery, sqlClause, aliasName, nestLevel);
        _myCQ = myCQ;
    }

    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName) {
        registerInlineQuery(key, value, cvalue, colName, capPropName, uncapPropName);
    }

    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName, ConditionOption option) {
        registerInlineQuery(key, value, cvalue, colName, capPropName, uncapPropName, option);
    }

    protected void registerWhereClause(String whereClause) {
        registerInlineWhereClause(whereClause);
    }

      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [employee]
    // * * * * * * * * */

  
    protected ConditionValue getCValueId() {
        return _myCQ.getId();
    }

                            
    public void keepId_InScopeSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        _myCQ.keepId_InScopeSubQuery_EmployeeSelfList(subQuery);
    }
                            
    public void keepId_ExistsSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        _myCQ.keepId_ExistsSubQuery_EmployeeSelfList(subQuery);
    }
                                            
    protected ConditionValue getCValueEmpno() {
        return _myCQ.getEmpno();
    }

                                                        
    protected ConditionValue getCValueEmpname() {
        return _myCQ.getEmpname();
    }

                                                        
    protected ConditionValue getCValueJob() {
        return _myCQ.getJob();
    }

                                                        
    protected ConditionValue getCValueManager() {
        return _myCQ.getManager();
    }

              
    public void keepManager_InScopeSubQuery_EmployeeSelf(EmployeeCQ subQuery) {
        _myCQ.keepManager_InScopeSubQuery_EmployeeSelf(subQuery);
    }
                                                    
    protected ConditionValue getCValueHiredate() {
        return _myCQ.getHiredate();
    }

                                      
    protected ConditionValue getCValueSalary() {
        return _myCQ.getSalary();
    }

                                                            
    protected ConditionValue getCValueDeptid() {
        return _myCQ.getDeptid();
    }

              
    public void keepDeptid_InScopeSubQuery_Dept(DeptCQ subQuery) {
        _myCQ.keepDeptid_InScopeSubQuery_Dept(subQuery);
    }
                                                    
    protected ConditionValue getCValueVersionno() {
        return _myCQ.getVersionno();
    }

                                                        
}
