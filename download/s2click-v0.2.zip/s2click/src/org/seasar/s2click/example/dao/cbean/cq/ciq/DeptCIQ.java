package org.seasar.s2click.example.dao.cbean.cq.ciq;

import org.seasar.s2click.example.dao.cbean.cq.bs.*;
import org.seasar.s2click.example.dao.cbean.cq.*;

import org.seasar.s2click.example.dao.allcommon.cbean.*;
import org.seasar.s2click.example.dao.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.dao.allcommon.cbean.coption.ConditionOption;
import org.seasar.s2click.example.dao.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.dao.allcommon.cbean.sqlclause.SqlClause;

/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class DeptCIQ extends AbstractBsDeptCQ {

    protected BsDeptCQ _myCQ;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public DeptCIQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel, BsDeptCQ myCQ) {
        super(childQuery, sqlClause, aliasName, nestLevel);
        _myCQ = myCQ;
    }

    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName) {
        registerInlineQuery(key, value, cvalue, colName, capPropName, uncapPropName);
    }

    protected void setupConditionValueAndRegisterWhereClause(ConditionKey key, Object value, ConditionValue cvalue
                                                             , String colName, String capPropName, String uncapPropName, ConditionOption option) {
        registerInlineQuery(key, value, cvalue, colName, capPropName, uncapPropName, option);
    }

    protected void registerWhereClause(String whereClause) {
        registerInlineWhereClause(whereClause);
    }

      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [dept]
    // * * * * * * * * */

  
    protected ConditionValue getCValueId() {
        return _myCQ.getId();
    }

                            
    public void keepId_InScopeSubQuery_EmployeeList(EmployeeCQ subQuery) {
        _myCQ.keepId_InScopeSubQuery_EmployeeList(subQuery);
    }
                            
    public void keepId_ExistsSubQuery_EmployeeList(EmployeeCQ subQuery) {
        _myCQ.keepId_ExistsSubQuery_EmployeeList(subQuery);
    }
                                            
    protected ConditionValue getCValueDeptno() {
        return _myCQ.getDeptno();
    }

                                                        
    protected ConditionValue getCValueDeptname() {
        return _myCQ.getDeptname();
    }

                                                        
    protected ConditionValue getCValueLoc() {
        return _myCQ.getLoc();
    }

                                                        
    protected ConditionValue getCValueVersionno() {
        return _myCQ.getVersionno();
    }

                                                        
}
