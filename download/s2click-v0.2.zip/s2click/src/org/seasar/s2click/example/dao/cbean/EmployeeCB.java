package org.seasar.s2click.example.dao.cbean;


/**
 * The condition-bean of employee.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class EmployeeCB extends org.seasar.s2click.example.dao.cbean.bs.BsEmployeeCB {
}
