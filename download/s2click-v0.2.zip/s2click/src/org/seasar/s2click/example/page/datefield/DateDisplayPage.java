package org.seasar.s2click.example.page.datefield;

import net.sf.click.Context;
import net.sf.click.control.TextField;

import org.apache.log4j.Logger;
import org.seasar.s2click.example.page.BorderPage;

public class DateDisplayPage extends BorderPage {
	public Logger log = Logger.getLogger(this.getClass());
	public String date1x = "";
	@Override
	public void onRender() {
		date1x =  (String)(getContext().getRequestAttribute("date1xx"));
		addModel("date2x", (String)(getContext().getRequestAttribute("date2xx")));
	}
}
