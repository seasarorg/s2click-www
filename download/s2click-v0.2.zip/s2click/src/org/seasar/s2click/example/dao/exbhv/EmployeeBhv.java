package org.seasar.s2click.example.dao.exbhv;


/**
 * The behavior of employee.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class EmployeeBhv extends org.seasar.s2click.example.dao.bsbhv.BsEmployeeBhv {
}
