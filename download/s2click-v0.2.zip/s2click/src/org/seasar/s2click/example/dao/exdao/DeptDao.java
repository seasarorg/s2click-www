package org.seasar.s2click.example.dao.exdao;


/**
 * The dao interface of dept.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface DeptDao extends org.seasar.s2click.example.dao.bsdao.BsDeptDao {
}
