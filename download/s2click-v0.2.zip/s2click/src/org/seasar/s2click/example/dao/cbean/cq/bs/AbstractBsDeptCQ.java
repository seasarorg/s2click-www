
package org.seasar.s2click.example.dao.cbean.cq.bs;



import org.seasar.s2click.example.dao.allcommon.cbean.*;
import org.seasar.s2click.example.dao.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.dao.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.dao.allcommon.cbean.sqlclause.SqlClause;
import org.seasar.s2click.example.dao.cbean.cq.*;

/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class AbstractBsDeptCQ extends AbstractConditionQuery {

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public AbstractBsDeptCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    final public String getTableDbName() {
        return "dept";
    }

    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [dept]
    // * * * * * * * * */

      
    /** Column db name of id. */
    protected static final String COL_id = "id";

    /** Column java name of id. */
    protected static final String J_Id = "Id";

    /** Column uncapitalised java name of id. */
    protected static final String UJ_id = "id";
            
    /**
     * Set the value of id using equal. { = }
     * 
     * @param id The value of id as equal.
     */
    public void setId_Equal(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_EQUAL, id);
    }
            
    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param id The value of id as notEqual.
     */
    public void setId_NotEqual(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_NOT_EQUAL, id);
    }
            
    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param id The value of id as greaterThan.
     */
    public void setId_GreaterThan(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_GREATER_THAN, id);
    }
            
    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param id The value of id as lessThan.
     */
    public void setId_LessThan(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_LESS_THAN, id);
    }
            
    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param id The value of id as greaterEqual.
     */
    public void setId_GreaterEqual(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_GREATER_EQUAL, id);
    }
            
    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param id The value of id as lessEqual.
     */
    public void setId_LessEqual(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_LESS_EQUAL, id);
    }
            
    /**
     * Set the value of id using equal. { = }
     * 
     * @param id The value of id as equal.
     */
    public void setId_Equal(long id) {
        registerId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
        
    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param id The value of id as notEqual.
     */
    public void setId_NotEqual(long id) {
        registerId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param id The value of id as greaterThan.
     */
    public void setId_GreaterThan(long id) {
        registerId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param id The value of id as lessThan.
     */
    public void setId_LessThan(long id) {
        registerId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param id The value of id as greaterEqual.
     */
    public void setId_GreaterEqual(long id) {
        registerId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param id The value of id as lessEqual.
     */
    public void setId_LessEqual(long id) {
        registerId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
                    
    /**
     * Set the value of id using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param idList The value of id as inScope.
     */
    public void setId_InScope(java.util.List<java.math.BigDecimal> idList) {
        registerId(ConditionKey.CK_IN_SCOPE, idList);
    }
            
    /**
     * Set the value of id using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param idList The value of id as notInScope.
     */
    public void setId_NotInScope(java.util.List<java.math.BigDecimal> idList) {
        registerId(ConditionKey.CK_NOT_IN_SCOPE, idList);
    }
                          
    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery.
     * { in (select xxx.deptid from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery. (NotNull)
     */
    public void setId_InScopeSubQuery_EmployeeList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        keepId_InScopeSubQuery_EmployeeList(subQuery);// for saving query-value.
        registerInScopeSubQuery(subQuery, COL_id, "deptid", "id_InScopeSubQuery_EmployeeList");
    }

    abstract public void keepId_InScopeSubQuery_EmployeeList(EmployeeCQ subQuery);
                            
    /**
     * Set the sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery.
     * { exists (select xxx.deptid from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery. (NotNull)
     */
    public void setId_ExistsSubQuery_EmployeeList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        keepId_ExistsSubQuery_EmployeeList(subQuery);// for saving query-value.
        registerExistsSubQuery(subQuery, COL_id, "deptid", "id_ExistsSubQuery_EmployeeList");
    }

    abstract public void keepId_ExistsSubQuery_EmployeeList(EmployeeCQ subQuery);
                                      
    /**
     * Register condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     */
    protected void registerId(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueId(), COL_id, J_Id, UJ_id);
    }

    /**
     * Register inline condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     */
    protected void registerInlineId(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueId(), COL_id, J_Id, UJ_id);
    }

    abstract protected ConditionValue getCValueId();
      
    /** Column db name of deptno. */
    protected static final String COL_deptno = "deptno";

    /** Column java name of deptno. */
    protected static final String J_Deptno = "Deptno";

    /** Column uncapitalised java name of deptno. */
    protected static final String UJ_deptno = "deptno";
            
    /**
     * Set the value of deptno using equal. { = }
     * 
     * @param deptno The value of deptno as equal.
     */
    public void setDeptno_Equal(java.math.BigDecimal deptno) {
        registerDeptno(ConditionKey.CK_EQUAL, deptno);
    }
            
    /**
     * Set the value of deptno using notEqual. { != }
     * 
     * @param deptno The value of deptno as notEqual.
     */
    public void setDeptno_NotEqual(java.math.BigDecimal deptno) {
        registerDeptno(ConditionKey.CK_NOT_EQUAL, deptno);
    }
            
    /**
     * Set the value of deptno using greaterThan. { &gt; }
     * 
     * @param deptno The value of deptno as greaterThan.
     */
    public void setDeptno_GreaterThan(java.math.BigDecimal deptno) {
        registerDeptno(ConditionKey.CK_GREATER_THAN, deptno);
    }
            
    /**
     * Set the value of deptno using lessThan. { &lt; }
     * 
     * @param deptno The value of deptno as lessThan.
     */
    public void setDeptno_LessThan(java.math.BigDecimal deptno) {
        registerDeptno(ConditionKey.CK_LESS_THAN, deptno);
    }
            
    /**
     * Set the value of deptno using greaterEqual. { &gt;= }
     * 
     * @param deptno The value of deptno as greaterEqual.
     */
    public void setDeptno_GreaterEqual(java.math.BigDecimal deptno) {
        registerDeptno(ConditionKey.CK_GREATER_EQUAL, deptno);
    }
            
    /**
     * Set the value of deptno using lessEqual. { &lt;= }
     * 
     * @param deptno The value of deptno as lessEqual.
     */
    public void setDeptno_LessEqual(java.math.BigDecimal deptno) {
        registerDeptno(ConditionKey.CK_LESS_EQUAL, deptno);
    }
            
    /**
     * Set the value of deptno using equal. { = }
     * 
     * @param deptno The value of deptno as equal.
     */
    public void setDeptno_Equal(long deptno) {
        registerDeptno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(deptno)));
    }
        
    /**
     * Set the value of deptno using notEqual. { != }
     * 
     * @param deptno The value of deptno as notEqual.
     */
    public void setDeptno_NotEqual(long deptno) {
        registerDeptno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(deptno)));
    }
                
    /**
     * Set the value of deptno using greaterThan. { &gt; }
     * 
     * @param deptno The value of deptno as greaterThan.
     */
    public void setDeptno_GreaterThan(long deptno) {
        registerDeptno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(deptno)));
    }
                
    /**
     * Set the value of deptno using lessThan. { &lt; }
     * 
     * @param deptno The value of deptno as lessThan.
     */
    public void setDeptno_LessThan(long deptno) {
        registerDeptno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(deptno)));
    }
                
    /**
     * Set the value of deptno using greaterEqual. { &gt;= }
     * 
     * @param deptno The value of deptno as greaterEqual.
     */
    public void setDeptno_GreaterEqual(long deptno) {
        registerDeptno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(deptno)));
    }
                
    /**
     * Set the value of deptno using lessEqual. { &lt;= }
     * 
     * @param deptno The value of deptno as lessEqual.
     */
    public void setDeptno_LessEqual(long deptno) {
        registerDeptno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(deptno)));
    }
                    
    /**
     * Set the value of deptno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param deptnoList The value of deptno as inScope.
     */
    public void setDeptno_InScope(java.util.List<java.math.BigDecimal> deptnoList) {
        registerDeptno(ConditionKey.CK_IN_SCOPE, deptnoList);
    }
            
    /**
     * Set the value of deptno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param deptnoList The value of deptno as notInScope.
     */
    public void setDeptno_NotInScope(java.util.List<java.math.BigDecimal> deptnoList) {
        registerDeptno(ConditionKey.CK_NOT_IN_SCOPE, deptnoList);
    }
                                                
    /**
     * Register condition of deptno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptno. (Nullable)
     */
    protected void registerDeptno(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueDeptno(), COL_deptno, J_Deptno, UJ_deptno);
    }

    /**
     * Register inline condition of deptno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptno. (Nullable)
     */
    protected void registerInlineDeptno(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueDeptno(), COL_deptno, J_Deptno, UJ_deptno);
    }

    abstract protected ConditionValue getCValueDeptno();
      
    /** Column db name of deptname. */
    protected static final String COL_deptname = "deptname";

    /** Column java name of deptname. */
    protected static final String J_Deptname = "Deptname";

    /** Column uncapitalised java name of deptname. */
    protected static final String UJ_deptname = "deptname";
    
    /**
     * Set the value of deptname using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param deptname The value of deptname as equal.
     */
    public void setDeptname_Equal(String deptname) {
        registerDeptname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(deptname));
    }
      
    /**
     * Set the empty-string of deptname as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public void setDeptname_Equal_EmptyString() {
        registerDeptname(ConditionKey.CK_EQUAL, "");
    }
                  
    /**
     * Set the value of deptname using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param deptname The value of deptname as notEqual.
     */
    public void setDeptname_NotEqual(String deptname) {
        registerDeptname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(deptname));
    }
            
    /**
     * Set the value of deptname using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param deptname The value of deptname as greaterThan.
     */
    public void setDeptname_GreaterThan(String deptname) {
        registerDeptname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(deptname));
    }
            
    /**
     * Set the value of deptname using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param deptname The value of deptname as lessThan.
     */
    public void setDeptname_LessThan(String deptname) {
        registerDeptname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(deptname));
    }
            
    /**
     * Set the value of deptname using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param deptname The value of deptname as greaterEqual.
     */
    public void setDeptname_GreaterEqual(String deptname) {
        registerDeptname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(deptname));
    }
            
    /**
     * Set the value of deptname using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param deptname The value of deptname as lessEqual.
     */
    public void setDeptname_LessEqual(String deptname) {
        registerDeptname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(deptname));
    }
            
    /**
     * Set the value of deptname using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param deptname The value of deptname as prefixSearch.
     */
    public void setDeptname_PrefixSearch(String deptname) {
        registerDeptname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(deptname));
    }
            
    /**
     * Set the value of deptname using likeSearch. { like '%xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * You can invoke this method several times and the conditions are set up.
     * 
     * @param deptname The value of deptname as likeSearch.
     * @param likeSearchOption Like search option. (NotNull)
     */
    public void setDeptname_LikeSearch(String deptname, org.seasar.s2click.example.dao.allcommon.cbean.coption.LikeSearchOption option) {
        registerLikeSearchQuery(ConditionKey.CK_LIKE_SEARCH, filterRemoveEmptyString(deptname), getCValueDeptname(), COL_deptname, J_Deptname, UJ_deptname, option);
    }
            
    /**
     * Set the value of deptname using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param deptnameList The value of deptname as inScope.
     */
    public void setDeptname_InScope(java.util.List<String> deptnameList) {
        registerDeptname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(deptnameList));
    }

    /**
     * Set the value of deptname using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param deptname The value of deptname as inScope.
     */
    public void setDeptname_InScope(String deptname, org.seasar.s2click.example.dao.allcommon.cbean.coption.InScopeOption option) {
        registerInScopeQuery(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyString(deptname), getCValueDeptname(), COL_deptname, J_Deptname, UJ_deptname, option);
    }
            
    /**
     * Set the value of deptname using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param deptnameList The value of deptname as notInScope.
     */
    public void setDeptname_NotInScope(java.util.List<String> deptnameList) {
        registerDeptname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(deptnameList));
    }
                                                    
    /**
     * Register condition of deptname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptname. (Nullable)
     */
    protected void registerDeptname(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueDeptname(), COL_deptname, J_Deptname, UJ_deptname);
    }

    /**
     * Register inline condition of deptname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptname. (Nullable)
     */
    protected void registerInlineDeptname(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueDeptname(), COL_deptname, J_Deptname, UJ_deptname);
    }

    abstract protected ConditionValue getCValueDeptname();
      
    /** Column db name of loc. */
    protected static final String COL_loc = "loc";

    /** Column java name of loc. */
    protected static final String J_Loc = "Loc";

    /** Column uncapitalised java name of loc. */
    protected static final String UJ_loc = "loc";
    
    /**
     * Set the value of loc using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param loc The value of loc as equal.
     */
    public void setLoc_Equal(String loc) {
        registerLoc(ConditionKey.CK_EQUAL, filterRemoveEmptyString(loc));
    }
      
    /**
     * Set the empty-string of loc as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public void setLoc_Equal_EmptyString() {
        registerLoc(ConditionKey.CK_EQUAL, "");
    }
                  
    /**
     * Set the value of loc using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param loc The value of loc as notEqual.
     */
    public void setLoc_NotEqual(String loc) {
        registerLoc(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(loc));
    }
            
    /**
     * Set the value of loc using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param loc The value of loc as greaterThan.
     */
    public void setLoc_GreaterThan(String loc) {
        registerLoc(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(loc));
    }
            
    /**
     * Set the value of loc using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param loc The value of loc as lessThan.
     */
    public void setLoc_LessThan(String loc) {
        registerLoc(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(loc));
    }
            
    /**
     * Set the value of loc using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param loc The value of loc as greaterEqual.
     */
    public void setLoc_GreaterEqual(String loc) {
        registerLoc(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(loc));
    }
            
    /**
     * Set the value of loc using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param loc The value of loc as lessEqual.
     */
    public void setLoc_LessEqual(String loc) {
        registerLoc(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(loc));
    }
            
    /**
     * Set the value of loc using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param loc The value of loc as prefixSearch.
     */
    public void setLoc_PrefixSearch(String loc) {
        registerLoc(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(loc));
    }
            
    /**
     * Set the value of loc using likeSearch. { like '%xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * You can invoke this method several times and the conditions are set up.
     * 
     * @param loc The value of loc as likeSearch.
     * @param likeSearchOption Like search option. (NotNull)
     */
    public void setLoc_LikeSearch(String loc, org.seasar.s2click.example.dao.allcommon.cbean.coption.LikeSearchOption option) {
        registerLikeSearchQuery(ConditionKey.CK_LIKE_SEARCH, filterRemoveEmptyString(loc), getCValueLoc(), COL_loc, J_Loc, UJ_loc, option);
    }
            
    /**
     * Set the value of loc using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param locList The value of loc as inScope.
     */
    public void setLoc_InScope(java.util.List<String> locList) {
        registerLoc(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(locList));
    }

    /**
     * Set the value of loc using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param loc The value of loc as inScope.
     */
    public void setLoc_InScope(String loc, org.seasar.s2click.example.dao.allcommon.cbean.coption.InScopeOption option) {
        registerInScopeQuery(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyString(loc), getCValueLoc(), COL_loc, J_Loc, UJ_loc, option);
    }
            
    /**
     * Set the value of loc using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param locList The value of loc as notInScope.
     */
    public void setLoc_NotInScope(java.util.List<String> locList) {
        registerLoc(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(locList));
    }
                                                    
    /**
     * Register condition of loc.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of loc. (Nullable)
     */
    protected void registerLoc(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueLoc(), COL_loc, J_Loc, UJ_loc);
    }

    /**
     * Register inline condition of loc.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of loc. (Nullable)
     */
    protected void registerInlineLoc(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueLoc(), COL_loc, J_Loc, UJ_loc);
    }

    abstract protected ConditionValue getCValueLoc();
      
    /** Column db name of versionno. */
    protected static final String COL_versionno = "versionno";

    /** Column java name of versionno. */
    protected static final String J_Versionno = "Versionno";

    /** Column uncapitalised java name of versionno. */
    protected static final String UJ_versionno = "versionno";
            
    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param versionno The value of versionno as equal.
     */
    public void setVersionno_Equal(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param versionno The value of versionno as notEqual.
     */
    public void setVersionno_NotEqual(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_NOT_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param versionno The value of versionno as greaterThan.
     */
    public void setVersionno_GreaterThan(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_GREATER_THAN, versionno);
    }
            
    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param versionno The value of versionno as lessThan.
     */
    public void setVersionno_LessThan(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_LESS_THAN, versionno);
    }
            
    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param versionno The value of versionno as greaterEqual.
     */
    public void setVersionno_GreaterEqual(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_GREATER_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param versionno The value of versionno as lessEqual.
     */
    public void setVersionno_LessEqual(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_LESS_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param versionno The value of versionno as equal.
     */
    public void setVersionno_Equal(long versionno) {
        registerVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
        
    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param versionno The value of versionno as notEqual.
     */
    public void setVersionno_NotEqual(long versionno) {
        registerVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param versionno The value of versionno as greaterThan.
     */
    public void setVersionno_GreaterThan(long versionno) {
        registerVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param versionno The value of versionno as lessThan.
     */
    public void setVersionno_LessThan(long versionno) {
        registerVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param versionno The value of versionno as greaterEqual.
     */
    public void setVersionno_GreaterEqual(long versionno) {
        registerVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param versionno The value of versionno as lessEqual.
     */
    public void setVersionno_LessEqual(long versionno) {
        registerVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                    
    /**
     * Set the value of versionno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param versionnoList The value of versionno as inScope.
     */
    public void setVersionno_InScope(java.util.List<java.math.BigDecimal> versionnoList) {
        registerVersionno(ConditionKey.CK_IN_SCOPE, versionnoList);
    }
            
    /**
     * Set the value of versionno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param versionnoList The value of versionno as notInScope.
     */
    public void setVersionno_NotInScope(java.util.List<java.math.BigDecimal> versionnoList) {
        registerVersionno(ConditionKey.CK_NOT_IN_SCOPE, versionnoList);
    }
                                                
    /**
     * Register condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     */
    protected void registerVersionno(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueVersionno(), COL_versionno, J_Versionno, UJ_versionno);
    }

    /**
     * Register inline condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     */
    protected void registerInlineVersionno(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueVersionno(), COL_versionno, J_Versionno, UJ_versionno);
    }

    abstract protected ConditionValue getCValueVersionno();
  
    // =====================================================================================
    //                                                                 Basic-Override Method
    //                                                                 =====================
    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Clause string. (NotNull)
     */
    public String toString() {
        return getSqlClause().getClause();
    }
}
