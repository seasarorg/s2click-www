package org.seasar.s2click.example.dao.allcommon.helper.character;

/**
 * The interface of Japanese character.
 *
 * @author DBFlute(AutoGenerator)
 */
public interface JapaneseCharacter {

    public String toDoubleByteKatakana(String target);
}
