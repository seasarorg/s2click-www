package org.seasar.s2click.example.dao.exdao;

import java.util.List;

import org.seasar.s2click.example.dto.EmployeeSearchDto;
import org.seasar.s2click.example.dto.ManagerSearchDto;


/**
 * The dao interface of employee.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface EmployeeDao extends org.seasar.s2click.example.dao.bsdao.BsEmployeeDao {
	public List searchEmployeeDtoList(EmployeeSearchDto dto);
	public List searchManagerList(ManagerSearchDto dto);
}
