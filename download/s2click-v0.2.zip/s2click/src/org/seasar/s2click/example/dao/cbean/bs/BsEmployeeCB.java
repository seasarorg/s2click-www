package org.seasar.s2click.example.dao.cbean.bs;


import org.seasar.s2click.example.dao.allcommon.cbean.AbstractConditionBean;
import org.seasar.s2click.example.dao.allcommon.cbean.ConditionBean;
import org.seasar.s2click.example.dao.allcommon.cbean.ConditionQuery;

import org.seasar.s2click.example.dao.cbean.cq.*;
import org.seasar.s2click.example.dao.cbean.nss.*;

/**
 * The condition-bean of employee.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class BsEmployeeCB extends AbstractConditionBean {

    // =====================================================================================
    //                                                                            Annotation
    //                                                                            ==========
    /** TABLE-Annotation */
    public static final String TABLE = "employee";

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    /** Condition query. */
    protected EmployeeCQ _conditionQuery;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public BsEmployeeCB() {
    }

    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [employee]
    // * * * * * * * * */

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    final public String getTableDbName() {
        return "employee";
    }

    // =====================================================================================
    //                                                                    Accept Primary-Key
    //                                                                    ==================
    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMap Primary key map. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMap(java.util.Map<String, ? extends Object> primaryKeyMap) {
        if (primaryKeyMap == null) {
            String msg = "The argument[primaryKeyMap] must not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (primaryKeyMap.isEmpty()) {
            String msg = "The argument[primaryKeyMap] must not be empty.";
            throw new IllegalArgumentException(msg);
        }
  
        if (!primaryKeyMap.containsKey("id")) {
            String msg = "The primaryKeyMap must have the value of id";
            throw new IllegalStateException(msg + ": primaryKeyMap --> " + primaryKeyMap);
        }
        {
            Object obj = primaryKeyMap.get("id");
            if (obj instanceof java.math.BigDecimal) {
                query().setId_Equal((java.math.BigDecimal)obj);
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    query().setId_Equal((java.math.BigDecimal)obj);
                } else {
                    try {
                        query().setId_Equal(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    // =====================================================================================
    //                                                                 Add-OrderBy-PK Method
    //                                                                 =====================
    /**
     * This method implements the method that is declared at super.
     * 
     * @return this. (NotNull)
     */
    public ConditionBean addOrderBy_PK_Asc() {
  
        query().addOrderBy_Id_Asc();
  
        return this;

    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return this. (NotNull)
     */
    public ConditionBean addOrderBy_PK_Desc() {
  
        query().addOrderBy_Id_Desc();
  
        return this;

    }

    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
    /**
     * Query.
     * 
     * @return Instance of query. (NotNull)
     */
    public EmployeeCQ query() {
        return getConditionQuery();
    }

    /**
     * Get condition query. {Internal method for s2dao}
     * 
     * @return Instance of condition query. (NotNull)
     */
    public EmployeeCQ getConditionQuery() {
        if (_conditionQuery == null) {
            _conditionQuery = new EmployeeCQ(null, getSqlClause(), getTableDbName(), 0);
        }
        return _conditionQuery;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Instance of query as interface. (NotNull)
     */
    public ConditionQuery getConditionQueryAsInterface() {
        return getConditionQuery();
    }

    // =====================================================================================
    //                                                                          Setup Select
    //                                                                          ============
  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [dept]
    //   ForeignProperty = [dept]
    // * * * * * * * * */

    /** Is select for dept? */
    protected boolean _isSelectDept;
    /** Nest select setupper for dept. */
    protected DeptNss _nssDept;
    /**
     * Is select for dept? {For Internal}
     * 
     * @return Determination.
     */
    public boolean isSelectDept() {
        return _isSelectDept;
    }
    /**
     * Get nest select setupper for dept. {For Internal}
     * 
     * @return Nest select setupper. (NotNull)
     */
    public DeptNss getNssDept() {
        if (_nssDept == null) {
            _nssDept = new DeptNss(null);// for Dummy
        }
        return _nssDept;
    }
    /**
     * Set up select for dept.
     * If you invoke this, this entity is target of select.
     * 
     * @return Nest select setupper for dept. (NotNull)
     */
    public DeptNss setupSelect_Dept() {
        query().queryDept();// For setting outer join.
        if (_nssDept == null || !_nssDept.hasConditionQuery()) {
            _nssDept = new DeptNss(query().queryDept());
        }
        _isSelectDept = true;
        limitSelect_Off();
        return _nssDept;
    }
  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [employee]
    //   ForeignProperty = [employeeSelf]
    // * * * * * * * * */

    /** Is select for employeeSelf? */
    protected boolean _isSelectEmployeeSelf;
    /** Nest select setupper for employeeSelf. */
    protected EmployeeNss _nssEmployeeSelf;
    /**
     * Is select for employeeSelf? {For Internal}
     * 
     * @return Determination.
     */
    public boolean isSelectEmployeeSelf() {
        return _isSelectEmployeeSelf;
    }
    /**
     * Get nest select setupper for employeeSelf. {For Internal}
     * 
     * @return Nest select setupper. (NotNull)
     */
    public EmployeeNss getNssEmployeeSelf() {
        if (_nssEmployeeSelf == null) {
            _nssEmployeeSelf = new EmployeeNss(null);// for Dummy
        }
        return _nssEmployeeSelf;
    }
    /**
     * Set up select for employeeSelf.
     * If you invoke this, this entity is target of select.
     * 
     * @return Nest select setupper for employeeSelf. (NotNull)
     */
    public EmployeeNss setupSelect_EmployeeSelf() {
        query().queryEmployeeSelf();// For setting outer join.
        if (_nssEmployeeSelf == null || !_nssEmployeeSelf.hasConditionQuery()) {
            _nssEmployeeSelf = new EmployeeNss(query().queryEmployeeSelf());
        }
        _isSelectEmployeeSelf = true;
        limitSelect_Off();
        return _nssEmployeeSelf;
    }
          
    // =====================================================================================
    //                                                                 Basic-Override Method
    //                                                                 =====================
    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Clause string. (NotNull)
     */
    public String toString() {
        return getSqlClause().getClause();
    }
}
