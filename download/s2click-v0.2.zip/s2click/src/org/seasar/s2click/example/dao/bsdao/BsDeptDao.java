
package org.seasar.s2click.example.dao.bsdao;

import org.seasar.s2click.example.dao.exentity.Dept;

/**
 * The dao interface of dept.
 * 
 * <pre>
 * [primary-key]
 *     id
 * 
 * [column-property]
 *     id, deptno, deptname, loc, versionno
 * 
 * [foreign-property]
 *     
 * 
 * [refferer-property]
 *     employeeList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     id
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     Versionno
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface BsDeptDao extends org.seasar.s2click.example.dao.allcommon.DaoWritable {

    /** BEAN-Annotation. */
    public Class BEAN = org.seasar.s2click.example.dao.exentity.Dept.class;

    /** SQL-Annotation for getCountAll(). */
    public static final String getCountAll_SQL = "select count(*) from dept";

    /**
     * Get count as all.
     * 
     * @return All count.
     */
    public int getCountAll();

    /** SQL-Annotation for getListAll(). */
    public static final String getListAll_SQL = "select * from dept";

    /**
     * Get list as all.
     * 
     * @return All list. (NotNull)
     */
    public java.util.List<Dept> getListAll();

    /** SQL-Annotation for getEntity(). */
    public static final String getEntity_SQL = "select * from dept where dept.id = /*id*/null";

    /** Args-Annotation for getEntity(). */
    public static final String getEntity_ARGS = "id";

    public Dept getEntity(java.math.BigDecimal id);

    /**
     * Select count by condition-bean.
     * <pre>
     * Ignore fetchFirst() and fetchScope() and fetchPage().
     * But the fetch status of the condition-bean remains as it is.
     * This select method generates SQL based on condition-bean.
     * 
     * Example)
     *   final DeptCB cb = new DeptCB();
     *   cb.query().setXxx_GreaterEqual(new BigDecimal(14));
     *   final int count = dao.selectCount(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     */
    public int selectCount(org.seasar.s2click.example.dao.cbean.DeptCB cb);

    /**
     * Select count by condition-bean.
     * <pre>
     * Ignore fetchFirst() and fetchScope() and fetchPage(). But the fetch status of the condition-bean remains as it is.
     * This select method generates SQL based on condition-bean.
     * 
     * Example)
     *   final DeptCB cb = new DeptCB();
     *   cb.query().setXxx_GreaterEqual(new BigDecimal(14));
     *   final int count = dao.${database.ConditionBeanSelectCountMethodName}(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     * @deprecated Please use selectCount().
     */
    public int selectCountIgnoreFetchScope(org.seasar.s2click.example.dao.cbean.DeptCB cb);

    /**
     * Select entity 'Dept' by condition-bean.
     * <pre>
     * This select method generates SQL based on condition-bean.
     * 
     * Example)
     *   final DeptCB cb = new DeptCB();
     *   cb.query().setXxxCode_Equal("abc");// It is assumed that this is the primary key...
     *   cb.lockForUpdate();
     *   final Dept entity = dao.selectEntity(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. If the select result is zero, it returns null. (Nullable)
     */
    public Dept selectEntity(org.seasar.s2click.example.dao.cbean.DeptCB cb);

    /**
     * Select list by condition-bean.
     * <pre>
     * This select method generates SQL based on condition-bean.
     * 
     * Example)
     *   final DeptCB cb = new DeptCB();
     *   cb.setupSelect_Xxx(); // Including the foreign table in select clause
     *   cb.query().setXxxName_PrefixSearch("abc");
     *   cb.query().setXxxStartDate_IsNotNull();
     *   cb.addOrderBy_PK_Asc().fetchFirst(20);
     *   final List resultList = dao.selectList(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list. If the select result is zero, it returns empty list. (NotNull)
     */
    public java.util.List<Dept> selectList(org.seasar.s2click.example.dao.cbean.DeptCB cb);


    /**
     * Insert one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Inserted count.
     */
    public int insert(Dept entity);

    /**
     * Update one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int update(Dept entity);

    /**
     * Update one entity. (modified only)
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int updateModifiedOnly(Dept entity);

    /**
     * Delete one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delete(Dept entity);

    /**
     * Insert several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return Inserted count.
     */
    public int insertList(java.util.List<Dept> entityList);

    /**
     * Update several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return Updated count.
     */
    public int updateList(java.util.List<Dept> entityList);

    /**
     * Delete several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return Deleted count.
     */
    public int deleteList(java.util.List<Dept> entityList);

}
