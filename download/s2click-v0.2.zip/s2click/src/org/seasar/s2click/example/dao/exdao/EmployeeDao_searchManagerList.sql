select employee.id, employee.manager, employee.empno, employee.empname, 
 employee.job, employee.hiredate, employee.salary, employee.deptid,
 employee.versionno , EmployeeSelf.empname as managerName,
 EmployeeSelf.id as managerId,
  Dept.deptname as deptName ,Dept.id as deptId 
  from employee 
  left outer join employee EmployeeSelf 
  on employee.manager = EmployeeSelf.id 
  left outer join dept Dept 
  on employee.deptid = Dept.id

/*BEGIN*/
where
/*IF dto.empname != null*/and employee.empname like /*dto.empname*/'%SCOTT%'/*END*/
/*IF dto.deptid != null*/and employee.deptid = /*dto.deptid*/20/*END*/
/*END*/
  order by employee.id