package org.seasar.s2click.example.dao.allcommon.cbean.coption;


/**
 * The interface of condition-option.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface ConditionOption {
    public String getRearOption();
}
