package org.seasar.s2click.example.dao.bsentity.dbmeta;


import org.seasar.s2click.example.dao.allcommon.Entity;
import org.seasar.s2click.example.dao.allcommon.dbmeta.DBMeta;
import org.seasar.s2click.example.dao.allcommon.dbmeta.AbstractDBMeta;
import org.seasar.s2click.example.dao.exentity.Dept;

/**
 * The dbmeta of dept. (Singleton)
 * 
 * <pre>
 * [primary-key]
 *     id
 * 
 * [column-property]
 *     id, deptno, deptname, loc, versionno
 * 
 * [foreign-property]
 *     
 * 
 * [refferer-property]
 *     employeeList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     id
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     Versionno
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
public class DeptDbm extends AbstractDBMeta {

    /** The type of entity. */
    protected static final Class ENTITY_TYPE = Dept.class;

    /** Singleton instance. */
    private static final DeptDbm _instance = new DeptDbm();

    /**
     * Constructor
     */
    private DeptDbm() {
    }

    /**
     * Get instance.
     * 
     * @return Singleton instance. (NotNull)
     */
    public static DeptDbm getInstance() {
        return _instance;
    }

    // =====================================================================================
    //                                                                       Name Definition
    //                                                                       ===============
    /** Table db name. */
    public static final String TABLE_DB_NAME = "dept";

    /** Table cap-prop name. */
    public static final String TABLE_CAP_PROP_NAME = "Dept";

    /** Table uncap-prop name. */
    public static final String TABLE_UNCAP_PROP_NAME = "dept";


    /** Db-name of Id. */
    public static final String COLUMN_DB_NAME_OF_Id = "id";

    /** Db-name of Deptno. */
    public static final String COLUMN_DB_NAME_OF_Deptno = "deptno";

    /** Db-name of Deptname. */
    public static final String COLUMN_DB_NAME_OF_Deptname = "deptname";

    /** Db-name of Loc. */
    public static final String COLUMN_DB_NAME_OF_Loc = "loc";

    /** Db-name of Versionno. */
    public static final String COLUMN_DB_NAME_OF_Versionno = "versionno";


    /** Cap-prop-name of Id. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Id = "Id";

    /** Cap-prop-name of Deptno. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Deptno = "Deptno";

    /** Cap-prop-name of Deptname. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Deptname = "Deptname";

    /** Cap-prop-name of Loc. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Loc = "Loc";

    /** Cap-prop-name of Versionno. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Versionno = "Versionno";

    /** Cap-prop-name of EmployeeList. */
    public static final String COLUMN_CAP_PROP_NAME_OF_EmployeeList = "EmployeeList";


    /** Uncap-prop-name of Id. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Id = "id";

    /** Uncap-prop-name of Deptno. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Deptno = "deptno";

    /** Uncap-prop-name of Deptname. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Deptname = "deptname";

    /** Uncap-prop-name of Loc. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Loc = "loc";

    /** Uncap-prop-name of Versionno. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Versionno = "versionno";

    /** Uncap-prop-name of employeeList. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_EmployeeList = "employeeList";

    /** {db-name : cap-prop-name} map. */
    protected static final java.util.Map<String, String> _dbNameCapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_DB_NAME, TABLE_CAP_PROP_NAME);

        map.put(COLUMN_DB_NAME_OF_Id, COLUMN_CAP_PROP_NAME_OF_Id);

        map.put(COLUMN_DB_NAME_OF_Deptno, COLUMN_CAP_PROP_NAME_OF_Deptno);

        map.put(COLUMN_DB_NAME_OF_Deptname, COLUMN_CAP_PROP_NAME_OF_Deptname);

        map.put(COLUMN_DB_NAME_OF_Loc, COLUMN_CAP_PROP_NAME_OF_Loc);

        map.put(COLUMN_DB_NAME_OF_Versionno, COLUMN_CAP_PROP_NAME_OF_Versionno);

        _dbNameCapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {db-name : uncap-prop-name} map. */
    protected static final java.util.Map<String, String> _dbNameUncapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_DB_NAME, TABLE_UNCAP_PROP_NAME);

        map.put(COLUMN_DB_NAME_OF_Id, COLUMN_UNCAP_PROP_NAME_OF_Id);

        map.put(COLUMN_DB_NAME_OF_Deptno, COLUMN_UNCAP_PROP_NAME_OF_Deptno);

        map.put(COLUMN_DB_NAME_OF_Deptname, COLUMN_UNCAP_PROP_NAME_OF_Deptname);

        map.put(COLUMN_DB_NAME_OF_Loc, COLUMN_UNCAP_PROP_NAME_OF_Loc);

        map.put(COLUMN_DB_NAME_OF_Versionno, COLUMN_UNCAP_PROP_NAME_OF_Versionno);

        _dbNameUncapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {cap-prop-name : db-name} map. */
    protected static final java.util.Map<String, String> _capPropNameDbNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_CAP_PROP_NAME, TABLE_DB_NAME);

        map.put(COLUMN_CAP_PROP_NAME_OF_Id, COLUMN_DB_NAME_OF_Id);

        map.put(COLUMN_CAP_PROP_NAME_OF_Deptno, COLUMN_DB_NAME_OF_Deptno);

        map.put(COLUMN_CAP_PROP_NAME_OF_Deptname, COLUMN_DB_NAME_OF_Deptname);

        map.put(COLUMN_CAP_PROP_NAME_OF_Loc, COLUMN_DB_NAME_OF_Loc);

        map.put(COLUMN_CAP_PROP_NAME_OF_Versionno, COLUMN_DB_NAME_OF_Versionno);

        _capPropNameDbNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {cap-prop-name : uncap-prop-name} map. */
    protected static final java.util.Map<String, String> _capPropNameUncapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_CAP_PROP_NAME, TABLE_UNCAP_PROP_NAME);

        map.put(COLUMN_CAP_PROP_NAME_OF_Id, COLUMN_UNCAP_PROP_NAME_OF_Id);

        map.put(COLUMN_CAP_PROP_NAME_OF_Deptno, COLUMN_UNCAP_PROP_NAME_OF_Deptno);

        map.put(COLUMN_CAP_PROP_NAME_OF_Deptname, COLUMN_UNCAP_PROP_NAME_OF_Deptname);

        map.put(COLUMN_CAP_PROP_NAME_OF_Loc, COLUMN_UNCAP_PROP_NAME_OF_Loc);

        map.put(COLUMN_CAP_PROP_NAME_OF_Versionno, COLUMN_UNCAP_PROP_NAME_OF_Versionno);

        _capPropNameUncapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {uncap-prop-name : db-name} map. */
    protected static final java.util.Map<String, String> _uncapPropNameDbNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_UNCAP_PROP_NAME, TABLE_DB_NAME);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Id, COLUMN_DB_NAME_OF_Id);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Deptno, COLUMN_DB_NAME_OF_Deptno);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Deptname, COLUMN_DB_NAME_OF_Deptname);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Loc, COLUMN_DB_NAME_OF_Loc);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Versionno, COLUMN_DB_NAME_OF_Versionno);

        _uncapPropNameDbNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {uncap-prop-name : cap-prop-name} map. */
    protected static final java.util.Map<String, String> _uncapPropNameCapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_UNCAP_PROP_NAME, TABLE_CAP_PROP_NAME);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Id, COLUMN_CAP_PROP_NAME_OF_Id);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Deptno, COLUMN_CAP_PROP_NAME_OF_Deptno);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Deptname, COLUMN_CAP_PROP_NAME_OF_Deptname);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Loc, COLUMN_CAP_PROP_NAME_OF_Loc);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Versionno, COLUMN_CAP_PROP_NAME_OF_Versionno);

        _uncapPropNameCapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    // =====================================================================================
    //                                                                            Table Name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return TABLE_DB_NAME;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table cap-prop-name. (NotNull)
     */
    public String getTableCapPropName() {
        return TABLE_CAP_PROP_NAME;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table property-name. (NotNull)
     */
    public String getTableUncapPropName() {
        return TABLE_UNCAP_PROP_NAME;
    }

    // =====================================================================================
    //                                                                    DB-Name-Map Getter
    //                                                                    ==================
    /**
     * This method implements the method that is declared at super.
     * 
     * @return {db-name : cap-prop-name} map.
     */
    public java.util.Map<String, String> getDbNameCapPropNameMap() {
        return _dbNameCapPropNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {db-name : uncap-prop-name} map.
     */
    public java.util.Map<String, String> getDbNameUncapPropNameMap() {
        return _dbNameUncapPropNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {cap-prop-name : db-name} map.
     */
    public java.util.Map<String, String> getCapPropNameDbNameMap() {
        return _capPropNameDbNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {cap-prop-name : uncap-prop-name} map.
     */
    public java.util.Map<String, String> getCapPropNameUncapPropNameMap() {
        return _capPropNameUncapPropNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {uncap-prop-name : db-name} map.
     */
    public java.util.Map<String, String> getUncapPropNameDbNameMap() {
        return _uncapPropNameDbNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {uncap-prop-name : cap-prop-name} map.
     */
    public java.util.Map<String, String> getUncapPropNameCapPropNameMap() {
        return _uncapPropNameCapPropNameMap;
    }

    // =====================================================================================
    //                                                                      Type Name Getter
    //                                                                      ================
    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type-name of entity. (NotNull)
     */ 
    public String getEntityTypeName() {
        return "org.seasar.s2click.example.dao.exentity.Dept";
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type-name of condition-bean. (NotNull)
     */ 
    public String getConditionBeanTypeName() {
        return "DeptCB.DeptCB";
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type-name of dao. (NotNull)
     */ 
    public String getDaoTypeName() {
        return "org.seasar.s2click.example.dao.exdao.DeptDao";
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type-name of behavior. (NotNull)
     */ 
    public String getBehaviorTypeName() {
        return "org.seasar.s2click.example.dao.exbhv.DeptBhv";
    }


    // =====================================================================================
    //                                                                           Type Getter
    //                                                                           ===========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type of entity. (NotNull)
     */ 
    public Class getEntityType() {
        return ENTITY_TYPE;
    }

    // =====================================================================================
    //                                                                       Instance Getter
    //                                                                       ===============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type of entity. (NotNull)
     */ 
    public Entity newEntity() {
        return newMyEntity();
    }

    /**
     * New the instance of my entity.
     * 
     * @return The instance of my entity. (NotNull)
     */ 
    public Dept newMyEntity() {
        return new Dept();
    }

    // =====================================================================================
    //                                                                         Entity Method
    //                                                                         =============

    /**
     * The getter method of id.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Id = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Id);

    /** 
     * The setter method of id.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Id = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Id, java.math.BigDecimal.class);

    /**
     * The getter method of deptno.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Deptno = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Deptno);

    /** 
     * The setter method of deptno.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Deptno = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Deptno, java.math.BigDecimal.class);

    /**
     * The getter method of deptname.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Deptname = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Deptname);

    /** 
     * The setter method of deptname.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Deptname = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Deptname, String.class);

    /**
     * The getter method of loc.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Loc = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Loc);

    /** 
     * The setter method of loc.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Loc = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Loc, String.class);

    /**
     * The getter method of versionno.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Versionno = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Versionno);

    /** 
     * The setter method of versionno.
     * 
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Versionno = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Versionno, java.math.BigDecimal.class);

    /**
     * Get getter method.
     * 
     * @param methodName The method name. (NotNull)
     * @return The getter method. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static java.lang.reflect.Method getGetterMethod(String methodName) {
        try {
            return ENTITY_TYPE.getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The method doen not exist: methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
    }

    /**
     * Get setter method.
     * 
     * @param methodName The method name. (NotNull)
     * @param type Argument type. (NotNull)
     * @return The getter method. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    protected static java.lang.reflect.Method getSetterMethod(String methodName, Class type) {
        try {
            return ENTITY_TYPE.getMethod(methodName, new Class[]{type});
        } catch (NoSuchMethodException e) {
            String msg = "The method doen not exist: methodName=" + methodName + " argsType=" + type;
            throw new RuntimeException(msg, e);
        }
    }


    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of id. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntityGetterMethod_Id() {
        return ENTITY_GETTER_METHOD_Id;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of id. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntitySetterMethod_Id() {
        return ENTITY_SETTER_METHOD_Id;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of deptno. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntityGetterMethod_Deptno() {
        return ENTITY_GETTER_METHOD_Deptno;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of deptno. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntitySetterMethod_Deptno() {
        return ENTITY_SETTER_METHOD_Deptno;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of deptname. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntityGetterMethod_Deptname() {
        return ENTITY_GETTER_METHOD_Deptname;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of deptname. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntitySetterMethod_Deptname() {
        return ENTITY_SETTER_METHOD_Deptname;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of loc. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntityGetterMethod_Loc() {
        return ENTITY_GETTER_METHOD_Loc;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of loc. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntitySetterMethod_Loc() {
        return ENTITY_SETTER_METHOD_Loc;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of versionno. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntityGetterMethod_Versionno() {
        return ENTITY_GETTER_METHOD_Versionno;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of versionno. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */
    public java.lang.reflect.Method getEntitySetterMethod_Versionno() {
        return ENTITY_SETTER_METHOD_Versionno;
    }

    /**
     * Get entity getter method by multi-name.
     * 
     * @param multiName Multi-name. (NotNull)
     * @return Entity getter method of entity. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */ 
    public java.lang.reflect.Method getEntityGetterMethodByMultiName(String multiName) {
        assertStringNotNullAndNotTrimmedEmpty("multiName", multiName);
        final String capPropName = getCapPropNameByMultiName(multiName);
        final String methodName = "getEntityGetterMethod_" + capPropName;

        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The multiName is not found: multiName=" + multiName;
            msg = msg + " tableName=" + TABLE_DB_NAME + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            return (java.lang.reflect.Method)method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    /**
     * Get entity setter method by multi-name.
     * 
     * @param multiName Multi-name. (NotNull)
     * @return Entity setter method of entity. (NotNull)
     * @deprecated There is more available object. {org.seasar.framework.beans.factory.BeanDescFactory}
     */ 
    public java.lang.reflect.Method getEntitySetterMethodByMultiName(String multiName) {
        assertStringNotNullAndNotTrimmedEmpty("multiName", multiName);
        final String capPropName = getCapPropNameByMultiName(multiName);
        final String methodName = "getEntitySetterMethod_" + capPropName;

        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The multiName is not found: multiName=" + multiName;
            msg = msg + " tableName=" + TABLE_DB_NAME + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            return (java.lang.reflect.Method)method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    // =====================================================================================
    //                                                                        Foreign DBMeta
    //                                                                        ==============
    /**
     * This method implements the method that is declared at super.
     * 
     * @param foreignPropertyName Foreign-property-name(Both OK - InitCap or not). (NotNull)
     * @return Foreign DBMeta. (NotNull)
     */ 
    public DBMeta getForeignDBMeta(String foreignPropertyName) {
        assertStringNotNullAndNotTrimmedEmpty("foreignPropertyName", foreignPropertyName);
        final String methodName = "getForeignDBMeta_" + foreignPropertyName.substring(0, 1) + foreignPropertyName.substring(1);

        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The foreignPropertyName is not found: foreignPropertyName=" + foreignPropertyName;
            msg = msg + " tableName=" + TABLE_DB_NAME + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            return (DBMeta)method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }
  
    // =====================================================================================
    //                                                                         Determination
    //                                                                         =============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Determination.
     */
    public boolean hasTwoOrMorePrimaryKeys() {
        return false;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Determination.
     */
    public boolean hasCommonColumn() {
        return false;
    }
}
