package org.seasar.s2click.example.page.add;

import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.extras.control.IntegerField;

import org.seasar.s2click.control.Text;
import org.seasar.s2click.example.logic.AddLogic;
import org.seasar.s2click.example.page.BorderPage;

public class AddPage extends BorderPage {
    public Form form = new Form();
    public Text res = new Text("result","= 0");
    private AddLogic addlogic;
    public AddPage() {
    	form.add(new IntegerField("para1","",true));
    	form.add(new Text("plus","+"));
    	form.add(new IntegerField("para2","",true));
    	res.setAttribute("style", "color:#000000");
    	form.add(res);
        form.add(new Submit("ok", "calculate", this, "onOkClicked"));
    }

	public boolean onOkClicked() {
        if (form.isValid()) {
        	res.setString("= "
        			+String.valueOf(addlogic.calculate(((IntegerField)form.getField("para1")).getInteger(),((IntegerField)form.getField("para2")).getInteger())));
        	return false;
        }
        return true;
    }
	public void setAddlogic(AddLogic addlogic) {
		this.addlogic = addlogic;
	}


}
