select deptname
from dept
where deptno = /*deptno*/10