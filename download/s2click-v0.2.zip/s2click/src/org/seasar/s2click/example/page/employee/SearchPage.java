package org.seasar.s2click.example.page.employee;

import net.sf.click.control.Button;
import net.sf.click.control.Form;
import net.sf.click.control.Select;
import net.sf.click.control.Submit;
import net.sf.click.control.TextField;
import net.sf.click.extras.control.IntegerField;

import org.seasar.s2click.control.DateFieldYYYYMMDD;
import org.seasar.s2click.control.Text;
import org.seasar.s2click.control.TextFieldSelectId;
import org.seasar.s2click.example.dao.exbhv.DeptBhv;
import org.seasar.s2click.example.dto.EmployeeSearchDto;
import org.seasar.s2click.example.page.BorderPage;
import org.seasar.s2click.example.util.CommonLogic;
import org.seasar.s2click.util.Utility;

public class SearchPage extends BorderPage {
	public Form form = new Form();
	private DeptBhv deptbhv;
	private TextFieldSelectId textSelect = 
		new TextFieldSelectId("managerName","managerName");
	private TextField manageid = new TextField("managerId","managerId");
	private Select deptid = new Select("deptid","dept");
//	private EmployeeBhv employeeBhv;
	public SearchPage(){
		form.setColumns(2);
		form.add(new IntegerField("empno","empno"));
		form.add(new Text("p1",""));
		form.add(new TextField("empname","empname"));
		form.add(new Text("p4",""));
		form.add(new TextField("job","job"));
		form.add(new Text("p2",""));
		form.add(textSelect);
		form.add(manageid);
		form.add(new DateFieldYYYYMMDD("hiredateFrom","hiredate"));
		form.add(new DateFieldYYYYMMDD("hiredateTo","～"));
		form.add(new IntegerField("salaryFrom","salary"));
		form.add(new IntegerField("salaryTo","～"));
		form.add(deptid);
		form.add(new Text("p3",""));
		form.add(new Submit("new","新規",this,"onNewClicked"));
		form.add(new Submit("search","検索",this,"onSearchClicked"));
		Button reset = new Button("reset","消去");
		reset.setAttribute("onclick", 
				"AJS.$('hiredateFrom_field').value='';"+
				"AJS.$('hiredateTo_field').value='';"+
				"AJS.$('form_salaryFrom').value='';"+
				"AJS.$('form_salaryTo').value='';"+
				"AJS.$('form_empno').value='';"+
				"AJS.$('form_empname').value='';"+
				"AJS.$('form_job').value='';"+
				"AJS.$('form_managerName').value='';"+
				"AJS.$('form_managerId').value='';"+
				"AJS.$('form_deptid').value='';");
		form.add(reset);
	}
	public void onInit(){
		textSelect.setIdField(manageid);
		textSelect.setSelectPage("ManagerSelect",
				Utility.getFullPagePath(this, ManagerSelectPage.class));
		CommonLogic.setDeptOptions(deptid, form, deptbhv);
	}
	public boolean onSearchClicked(){
        if (form.isValid()) {	
        	EmployeeSearchDto employeeSearchDto = new EmployeeSearchDto();
        	form.copyTo(employeeSearchDto);
        	getContext().getSession().setAttribute("employeeSearchDto", employeeSearchDto);
        	setRedirect(ListPage.class);
        	return false;
        }
        return true;
	}
	public boolean onNewClicked(){
		setRedirect(getContext().getPagePath(EditPage.class) + "?mode=new");
		return false;	
	}
	@Override
	public void onGet() {
		EmployeeSearchDto employeeSearchDto = 
			(EmployeeSearchDto) getContext().getSession().getAttribute("employeeSearchDto");
    	if (employeeSearchDto != null) {
    		form.copyFrom(employeeSearchDto);
    	}
	}
	
	public void setDeptbhv(DeptBhv deptbhv) {
		this.deptbhv = deptbhv;
	}
//	public void setEmployeeBhv(EmployeeBhv employeeBhv) {
//		this.employeeBhv = employeeBhv;
//	}
}
