
package org.seasar.s2click.example.dao.cbean.cq.bs;

import org.seasar.s2click.example.dao.cbean.cq.*;
  
import org.seasar.s2click.example.dao.allcommon.cbean.*;
import org.seasar.s2click.example.dao.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.dao.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.dao.allcommon.cbean.sqlclause.SqlClause;
import org.seasar.s2click.example.dao.cbean.cq.ciq.*;

/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class BsEmployeeCQ extends AbstractBsEmployeeCQ {

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    protected EmployeeCIQ _inlineQuery;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public BsEmployeeCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // =====================================================================================
    //                                                                                Inline
    //                                                                                ======
    /**
     * Get inline query.
     * 
     * @return Inline query. (NotNull)
     */
    public EmployeeCIQ inline() {
        if (_inlineQuery == null) {
            _inlineQuery = new EmployeeCIQ(getChildQuery(), getSqlClause(), getAliasName(), getNestLevel(), this);
        }
        return _inlineQuery;
    }

    // =====================================================================================
    //                                                                         IncludeAsMine
    //                                                                         =============
  
    /**
     * Include select-column of id as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Id() {
        registerIncludedSelectColumn("Id", getRealColumnName("id"));
    }

    /**
     * Include select-column of id as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Id(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("id"));
    }
  
    /**
     * Include select-column of empno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Empno() {
        registerIncludedSelectColumn("Empno", getRealColumnName("empno"));
    }

    /**
     * Include select-column of empno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Empno(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("empno"));
    }
  
    /**
     * Include select-column of empname as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Empname() {
        registerIncludedSelectColumn("Empname", getRealColumnName("empname"));
    }

    /**
     * Include select-column of empname as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Empname(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("empname"));
    }
  
    /**
     * Include select-column of job as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Job() {
        registerIncludedSelectColumn("Job", getRealColumnName("job"));
    }

    /**
     * Include select-column of job as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Job(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("job"));
    }
  
    /**
     * Include select-column of manager as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Manager() {
        registerIncludedSelectColumn("Manager", getRealColumnName("manager"));
    }

    /**
     * Include select-column of manager as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Manager(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("manager"));
    }
  
    /**
     * Include select-column of hiredate as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Hiredate() {
        registerIncludedSelectColumn("Hiredate", getRealColumnName("hiredate"));
    }

    /**
     * Include select-column of hiredate as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Hiredate(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("hiredate"));
    }
  
    /**
     * Include select-column of salary as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Salary() {
        registerIncludedSelectColumn("Salary", getRealColumnName("salary"));
    }

    /**
     * Include select-column of salary as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Salary(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("salary"));
    }
  
    /**
     * Include select-column of deptid as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Deptid() {
        registerIncludedSelectColumn("Deptid", getRealColumnName("deptid"));
    }

    /**
     * Include select-column of deptid as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Deptid(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("deptid"));
    }
  
    /**
     * Include select-column of versionno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Versionno() {
        registerIncludedSelectColumn("Versionno", getRealColumnName("versionno"));
    }

    /**
     * Include select-column of versionno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Versionno(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("versionno"));
    }
  
    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [employee]
    // * * * * * * * * */

  
    /** The attribute of id. */
    protected ConditionValue _id;

    /**
     * Get the value of id.
     * 
     * @return The value of id.
     */
    public ConditionValue getId() {
        if (_id == null) {
            _id = new ConditionValue();
        }
        return _id;
    }

    protected ConditionValue getCValueId() {
        return getId();
    }

              
    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_Equal_AsInline(long value) {
        registerInlineId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_NotEqual_AsInline(long value) {
        registerInlineId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterThan_AsInline(long value) {
        registerInlineId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessThan_AsInline(long value) {
        registerInlineId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterEqual_AsInline(long value) {
        registerInlineId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessEqual_AsInline(long value) {
        registerInlineId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
                          
    /** The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeSelfList;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery. (Nullable)
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeSelfList() {
        return _id_InScopeSubQuery_EmployeeSelfList;
    }

    public void keepId_InScopeSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        _id_InScopeSubQuery_EmployeeSelfList = subQuery;
    }
          
    /** The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeSelfList_AsInline;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline. (Nullable)
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeSelfList_AsInline() {
        return _id_InScopeSubQuery_EmployeeSelfList_AsInline;
    }

    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline.
     * { in (select xxx.manager from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline. (NotNull)
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_InScopeSubQuery_EmployeeSelfList_AsInline(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_InScopeSubQuery_EmployeeSelfList_AsInline = subQuery;// for saving query-value.
        registerInlineInScopeSubQuery(subQuery, COL_id, "manager", "id_InScopeSubQuery_EmployeeSelfList_AsInline");
    }
                                      
    /** The sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery. */
    protected EmployeeCQ _id_ExistsSubQuery_EmployeeSelfList;

    /**
     * Get the sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery.
     * 
     * @return The sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery. (Nullable)
     */
    public EmployeeCQ getId_ExistsSubQuery_EmployeeSelfList() {
        return _id_ExistsSubQuery_EmployeeSelfList;
    }

    public void keepId_ExistsSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        _id_ExistsSubQuery_EmployeeSelfList = subQuery;
    }
                                      
    /**
     * Add order-by of id as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Id_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, true);return this;
    }

    /**
     * Add order-by of id as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Id_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, false);return this;
    }
      
    /** The attribute of empno. */
    protected ConditionValue _empno;

    /**
     * Get the value of empno.
     * 
     * @return The value of empno.
     */
    public ConditionValue getEmpno() {
        if (_empno == null) {
            _empno = new ConditionValue();
        }
        return _empno;
    }

    protected ConditionValue getCValueEmpno() {
        return getEmpno();
    }

              
    /**
     * Set the value of empno using equal as inline. { = }
     * 
     * @param value The value of empno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineEmpno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of empno using equal as inline. { = }
     * 
     * @param value The value of empno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_Equal_AsInline(long value) {
        registerInlineEmpno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of empno using notEqual as inline. { != }
     * 
     * @param value The value of empno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineEmpno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of empno using notEqual as inline. { != }
     * 
     * @param value The value of empno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_NotEqual_AsInline(long value) {
        registerInlineEmpno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of empno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineEmpno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of empno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of empno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_GreaterThan_AsInline(long value) {
        registerInlineEmpno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using lessThan as inline. { &lt; }
     * 
     * @param value The value of empno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineEmpno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of empno using lessThan as inline. { &lt; }
     * 
     * @param value The value of empno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_LessThan_AsInline(long value) {
        registerInlineEmpno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of empno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineEmpno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of empno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of empno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_GreaterEqual_AsInline(long value) {
        registerInlineEmpno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of empno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineEmpno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of empno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of empno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpno_LessEqual_AsInline(long value) {
        registerInlineEmpno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
                                                
    /**
     * Add order-by of empno as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Empno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empno), null, true);return this;
    }

    /**
     * Add order-by of empno as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Empno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empno), null, false);return this;
    }
      
    /** The attribute of empname. */
    protected ConditionValue _empname;

    /**
     * Get the value of empname.
     * 
     * @return The value of empname.
     */
    public ConditionValue getEmpname() {
        if (_empname == null) {
            _empname = new ConditionValue();
        }
        return _empname;
    }

    protected ConditionValue getCValueEmpname() {
        return getEmpname();
    }

          
    /**
     * Set the value of empname using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_Equal_AsInline(String value) {
        registerInlineEmpname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }
      
    /**
     * Set the value of empname using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_NotEqual_AsInline(String value) {
        registerInlineEmpname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_GreaterThan_AsInline(String value) {
        registerInlineEmpname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_LessThan_AsInline(String value) {
        registerInlineEmpname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_GreaterEqual_AsInline(String value) {
        registerInlineEmpname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_LessEqual_AsInline(String value) {
        registerInlineEmpname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as prefixSearch.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_PrefixSearch_AsInline(String value) {
        registerInlineEmpname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empname as inScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_InScope_AsInline(java.util.List<String> valueList) {
        registerInlineEmpname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of empname using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empname as notInScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setEmpname_NotInScope_AsInline(java.util.List<String> valueList) {
        registerInlineEmpname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                                    
    /**
     * Add order-by of empname as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Empname_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empname), null, true);return this;
    }

    /**
     * Add order-by of empname as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Empname_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empname), null, false);return this;
    }
      
    /** The attribute of job. */
    protected ConditionValue _job;

    /**
     * Get the value of job.
     * 
     * @return The value of job.
     */
    public ConditionValue getJob() {
        if (_job == null) {
            _job = new ConditionValue();
        }
        return _job;
    }

    protected ConditionValue getCValueJob() {
        return getJob();
    }

          
    /**
     * Set the value of job using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_Equal_AsInline(String value) {
        registerInlineJob(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }
      
    /**
     * Set the value of job using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_NotEqual_AsInline(String value) {
        registerInlineJob(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_GreaterThan_AsInline(String value) {
        registerInlineJob(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_LessThan_AsInline(String value) {
        registerInlineJob(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_GreaterEqual_AsInline(String value) {
        registerInlineJob(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_LessEqual_AsInline(String value) {
        registerInlineJob(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as prefixSearch.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_PrefixSearch_AsInline(String value) {
        registerInlineJob(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of job as inScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_InScope_AsInline(java.util.List<String> valueList) {
        registerInlineJob(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of job using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of job as notInScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setJob_NotInScope_AsInline(java.util.List<String> valueList) {
        registerInlineJob(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                                    
    /**
     * Add order-by of job as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Job_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_job), null, true);return this;
    }

    /**
     * Add order-by of job as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Job_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_job), null, false);return this;
    }
      
    /** The attribute of manager. */
    protected ConditionValue _manager;

    /**
     * Get the value of manager.
     * 
     * @return The value of manager.
     */
    public ConditionValue getManager() {
        if (_manager == null) {
            _manager = new ConditionValue();
        }
        return _manager;
    }

    protected ConditionValue getCValueManager() {
        return getManager();
    }

              
    /**
     * Set the value of manager using equal as inline. { = }
     * 
     * @param value The value of manager as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineManager(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of manager using equal as inline. { = }
     * 
     * @param value The value of manager as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_Equal_AsInline(long value) {
        registerInlineManager(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of manager using notEqual as inline. { != }
     * 
     * @param value The value of manager as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineManager(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of manager using notEqual as inline. { != }
     * 
     * @param value The value of manager as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_NotEqual_AsInline(long value) {
        registerInlineManager(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using greaterThan as inline. { &gt; }
     * 
     * @param value The value of manager as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineManager(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of manager using greaterThan as inline. { &gt; }
     * 
     * @param value The value of manager as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_GreaterThan_AsInline(long value) {
        registerInlineManager(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using lessThan as inline. { &lt; }
     * 
     * @param value The value of manager as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineManager(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of manager using lessThan as inline. { &lt; }
     * 
     * @param value The value of manager as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_LessThan_AsInline(long value) {
        registerInlineManager(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of manager as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineManager(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of manager using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of manager as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_GreaterEqual_AsInline(long value) {
        registerInlineManager(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of manager as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineManager(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of manager using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of manager as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setManager_LessEqual_AsInline(long value) {
        registerInlineManager(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
            
    /** The sub-query of Manager_InScopeSubQuery_EmployeeSelf using inScopeSubQuery. */
    protected EmployeeCQ _manager_InScopeSubQuery_EmployeeSelf;

    /**
     * Get the sub-query of Manager_InScopeSubQuery_EmployeeSelf using inScopeSubQuery.
     * 
     * @return The sub-query of Manager_InScopeSubQuery_EmployeeSelf using inScopeSubQuery. (Nullable)
     */
    public EmployeeCQ getManager_InScopeSubQuery_EmployeeSelf() {
        return _manager_InScopeSubQuery_EmployeeSelf;
    }

    public void keepManager_InScopeSubQuery_EmployeeSelf(EmployeeCQ subQuery) {
        _manager_InScopeSubQuery_EmployeeSelf = subQuery;
    }
                                              
    /**
     * Add order-by of manager as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Manager_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_manager), null, true);return this;
    }

    /**
     * Add order-by of manager as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Manager_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_manager), null, false);return this;
    }
      
    /** The attribute of hiredate. */
    protected ConditionValue _hiredate;

    /**
     * Get the value of hiredate.
     * 
     * @return The value of hiredate.
     */
    public ConditionValue getHiredate() {
        if (_hiredate == null) {
            _hiredate = new ConditionValue();
        }
        return _hiredate;
    }

    protected ConditionValue getCValueHiredate() {
        return getHiredate();
    }

                  
    /**
     * Set the value of hiredate using equal as inline. { = }
     * 
     * @param value The value of hiredate as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setHiredate_Equal_AsInline(java.util.Date value) {
        registerInlineHiredate(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of hiredate using notEqual as inline. { != }
     * 
     * @param value The value of hiredate as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setHiredate_NotEqual_AsInline(java.util.Date value) {
        registerInlineHiredate(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of hiredate using greaterThan as inline. { &gt; }
     * 
     * @param value The value of hiredate as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setHiredate_GreaterThan_AsInline(java.util.Date value) {
        registerInlineHiredate(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of hiredate using lessThan as inline. { &lt; }
     * 
     * @param value The value of hiredate as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setHiredate_LessThan_AsInline(java.util.Date value) {
        registerInlineHiredate(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of hiredate using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of hiredate as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setHiredate_GreaterEqual_AsInline(java.util.Date value) {
        registerInlineHiredate(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of hiredate using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of hiredate as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setHiredate_LessEqual_AsInline(java.util.Date value) {
        registerInlineHiredate(ConditionKey.CK_LESS_EQUAL, value);
    }
                          
    /**
     * Add order-by of hiredate as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Hiredate_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_hiredate), null, true);return this;
    }

    /**
     * Add order-by of hiredate as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Hiredate_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_hiredate), null, false);return this;
    }
      
    /** The attribute of salary. */
    protected ConditionValue _salary;

    /**
     * Get the value of salary.
     * 
     * @return The value of salary.
     */
    public ConditionValue getSalary() {
        if (_salary == null) {
            _salary = new ConditionValue();
        }
        return _salary;
    }

    protected ConditionValue getCValueSalary() {
        return getSalary();
    }

              
    /**
     * Set the value of salary using equal as inline. { = }
     * 
     * @param value The value of salary as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineSalary(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of salary using equal as inline. { = }
     * 
     * @param value The value of salary as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_Equal_AsInline(long value) {
        registerInlineSalary(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of salary using notEqual as inline. { != }
     * 
     * @param value The value of salary as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineSalary(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of salary using notEqual as inline. { != }
     * 
     * @param value The value of salary as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_NotEqual_AsInline(long value) {
        registerInlineSalary(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using greaterThan as inline. { &gt; }
     * 
     * @param value The value of salary as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineSalary(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of salary using greaterThan as inline. { &gt; }
     * 
     * @param value The value of salary as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_GreaterThan_AsInline(long value) {
        registerInlineSalary(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using lessThan as inline. { &lt; }
     * 
     * @param value The value of salary as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineSalary(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of salary using lessThan as inline. { &lt; }
     * 
     * @param value The value of salary as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_LessThan_AsInline(long value) {
        registerInlineSalary(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of salary as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineSalary(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of salary using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of salary as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_GreaterEqual_AsInline(long value) {
        registerInlineSalary(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of salary as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineSalary(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of salary using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of salary as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setSalary_LessEqual_AsInline(long value) {
        registerInlineSalary(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
                                                    
    /**
     * Add order-by of salary as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Salary_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_salary), null, true);return this;
    }

    /**
     * Add order-by of salary as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Salary_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_salary), null, false);return this;
    }
      
    /** The attribute of deptid. */
    protected ConditionValue _deptid;

    /**
     * Get the value of deptid.
     * 
     * @return The value of deptid.
     */
    public ConditionValue getDeptid() {
        if (_deptid == null) {
            _deptid = new ConditionValue();
        }
        return _deptid;
    }

    protected ConditionValue getCValueDeptid() {
        return getDeptid();
    }

              
    /**
     * Set the value of deptid using equal as inline. { = }
     * 
     * @param value The value of deptid as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineDeptid(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of deptid using equal as inline. { = }
     * 
     * @param value The value of deptid as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_Equal_AsInline(long value) {
        registerInlineDeptid(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of deptid using notEqual as inline. { != }
     * 
     * @param value The value of deptid as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineDeptid(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of deptid using notEqual as inline. { != }
     * 
     * @param value The value of deptid as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_NotEqual_AsInline(long value) {
        registerInlineDeptid(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptid as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineDeptid(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of deptid using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptid as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_GreaterThan_AsInline(long value) {
        registerInlineDeptid(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptid as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineDeptid(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of deptid using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptid as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_LessThan_AsInline(long value) {
        registerInlineDeptid(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptid as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineDeptid(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of deptid using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptid as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_GreaterEqual_AsInline(long value) {
        registerInlineDeptid(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptid as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineDeptid(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of deptid using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptid as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptid_LessEqual_AsInline(long value) {
        registerInlineDeptid(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
            
    /** The sub-query of Deptid_InScopeSubQuery_Dept using inScopeSubQuery. */
    protected DeptCQ _deptid_InScopeSubQuery_Dept;

    /**
     * Get the sub-query of Deptid_InScopeSubQuery_Dept using inScopeSubQuery.
     * 
     * @return The sub-query of Deptid_InScopeSubQuery_Dept using inScopeSubQuery. (Nullable)
     */
    public DeptCQ getDeptid_InScopeSubQuery_Dept() {
        return _deptid_InScopeSubQuery_Dept;
    }

    public void keepDeptid_InScopeSubQuery_Dept(DeptCQ subQuery) {
        _deptid_InScopeSubQuery_Dept = subQuery;
    }
                                              
    /**
     * Add order-by of deptid as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Deptid_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptid), null, true);return this;
    }

    /**
     * Add order-by of deptid as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Deptid_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptid), null, false);return this;
    }
      
    /** The attribute of versionno. */
    protected ConditionValue _versionno;

    /**
     * Get the value of versionno.
     * 
     * @return The value of versionno.
     */
    public ConditionValue getVersionno() {
        if (_versionno == null) {
            _versionno = new ConditionValue();
        }
        return _versionno;
    }

    protected ConditionValue getCValueVersionno() {
        return getVersionno();
    }

              
    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_Equal_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_NotEqual_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterThan_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessThan_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterEqual_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessEqual_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
                                                
    /**
     * Add order-by of versionno as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Versionno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, true);return this;
    }

    /**
     * Add order-by of versionno as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsEmployeeCQ addOrderBy_Versionno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, false);return this;
    }
      
    // =====================================================================================
    //                                                               Query-SetupOuter-Method
    //                                                               =======================

      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [dept]
    //   ForeignProperty = [dept]
    // * * * * * * * * */

    /**
     * Query for dept.
     * 
     * @return Instance of DeptCQ as dept. (NotNull)
     */
    public DeptCQ queryDept() {
        return getConditionQueryDept();
    }

    /**
     * Setup outer join for ${foreignPropertyName}.
     */
    public void setupOuterJoin_Dept() {
        final java.util.Map<String, String> joinOnMap = new java.util.LinkedHashMap<String, String>();
        String key = null;
        String value = null;
    
        key = getRealColumnName("deptid");
        value = getConditionQueryDept().getRealColumnName("id");
        joinOnMap.put(key, value);
    
        final String joinTableName = "dept";
        final String aliasName = getConditionQueryDept().getRealAliasName();
        getSqlClause().registerOuterJoin(joinTableName, aliasName, joinOnMap);
    }

    /** Condition-query for dept. */
    protected DeptCQ _conditionQueryDept;

    /**
     * Get condition-query for dept.
     * 
     * @return Instance of DeptCQ as dept. (NotNull)
     */
    public DeptCQ getConditionQueryDept() {
        if (_conditionQueryDept == null) {
            _conditionQueryDept = newQueryDept();
            setupOuterJoin_Dept();
        }
        return _conditionQueryDept;
    }

    /**
     * New query for dept.
     * 
     * @return Query for dept. (NotNull)
     */
    protected DeptCQ newQueryDept() {
        return new DeptCQ(this, getSqlClause(), "Dept", getNextNestLevel());
    }
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [employee]
    //   ForeignProperty = [employeeSelf]
    // * * * * * * * * */

    /**
     * Query for employeeSelf.
     * 
     * @return Instance of EmployeeCQ as employeeSelf. (NotNull)
     */
    public EmployeeCQ queryEmployeeSelf() {
        return getConditionQueryEmployeeSelf();
    }

    /**
     * Setup outer join for ${foreignPropertyName}.
     */
    public void setupOuterJoin_EmployeeSelf() {
        final java.util.Map<String, String> joinOnMap = new java.util.LinkedHashMap<String, String>();
        String key = null;
        String value = null;
    
        key = getRealColumnName("manager");
        value = getConditionQueryEmployeeSelf().getRealColumnName("id");
        joinOnMap.put(key, value);
    
        final String joinTableName = "employee";
        final String aliasName = getConditionQueryEmployeeSelf().getRealAliasName();
        getSqlClause().registerOuterJoin(joinTableName, aliasName, joinOnMap);
    }

    /** Condition-query for employeeSelf. */
    protected EmployeeCQ _conditionQueryEmployeeSelf;

    /**
     * Get condition-query for employeeSelf.
     * 
     * @return Instance of EmployeeCQ as employeeSelf. (NotNull)
     */
    public EmployeeCQ getConditionQueryEmployeeSelf() {
        if (_conditionQueryEmployeeSelf == null) {
            _conditionQueryEmployeeSelf = newQueryEmployeeSelf();
            setupOuterJoin_EmployeeSelf();
        }
        return _conditionQueryEmployeeSelf;
    }

    /**
     * New query for employeeSelf.
     * 
     * @return Query for employeeSelf. (NotNull)
     */
    protected EmployeeCQ newQueryEmployeeSelf() {
        return new EmployeeCQ(this, getSqlClause(), "EmployeeSelf", getNextNestLevel());
    }
  
        
}
