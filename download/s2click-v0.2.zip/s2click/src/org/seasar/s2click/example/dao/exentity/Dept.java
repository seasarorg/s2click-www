package org.seasar.s2click.example.dao.exentity;


/**
 * The entity of dept.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class Dept extends org.seasar.s2click.example.dao.bsentity.BsDept {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
}
