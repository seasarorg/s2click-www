package org.seasar.s2click.example.dao.bsentity;


import org.seasar.s2click.example.dao.allcommon.Entity;
import org.seasar.s2click.example.dao.allcommon.dbmeta.DBMeta;
import org.seasar.s2click.example.dao.bsentity.dbmeta.DeptDbm;


/**
 * The entity of dept.
 * 
 * <pre>
 * [primary-key]
 *     id
 * 
 * [column-property]
 *     id, deptno, deptname, loc, versionno
 * 
 * [foreign-property]
 *     
 * 
 * [refferer-property]
 *     employeeList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     id
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     Versionno
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class BsDept implements Entity, java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /** TABLE-Annotation for S2Dao */
    public static final String TABLE = "dept";

    
    /** VERSION_NO-Annotation */
    public static final String VERSION_NO_PROPERTY = "versionno";
    
    /** ID-Annotation */
    public static final String id_ID = "identity";

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    /** Entity modified properties. (for S2Dao) */
    protected EntityModifiedProperties _modifiedProperties = newEntityModifiedProperties();

  
    /** The value of id. */
    protected java.math.BigDecimal _id;

    /** Has the setter of id been invoked? */
    protected boolean _isSetterInvokedId;
    
    /** The value of deptno. */
    protected java.math.BigDecimal _deptno;

    /** Has the setter of deptno been invoked? */
    protected boolean _isSetterInvokedDeptno;
    
    /** The value of deptname. */
    protected String _deptname;

    /** Has the setter of deptname been invoked? */
    protected boolean _isSetterInvokedDeptname;
    
    /** The value of loc. */
    protected String _loc;

    /** Has the setter of loc been invoked? */
    protected boolean _isSetterInvokedLoc;
    
    /** The value of versionno. */
    protected java.math.BigDecimal _versionno;

    /** Has the setter of versionno been invoked? */
    protected boolean _isSetterInvokedVersionno;
  
    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public BsDept() {
    }

    // =====================================================================================
    //                                                                                DBMeta
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return DeptDbm.getInstance();
    }

    // =====================================================================================
    //                                                                            Table Name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return getDBMeta().getTableDbName();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table cap-prop-name. (NotNull)
     */
    public String getTableCapPropName() {
        return getDBMeta().getTableCapPropName();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table uncap-prop-name. (NotNull)
     */
    public String getTableUncapPropName() {
        return getDBMeta().getTableUncapPropName();
    }

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========

    /** Column-Annotation for S2Dao */
    public static final String id_COLUMN = "id";

    /**
     * Get the value of id.
     * 
     * @return The value of id. (Nullable)
     */
    public java.math.BigDecimal getId() {
        return _id;
    }
  
    /**
     * Set the value of id.
     * 
     * @param id The value of id. (Nullable)
     */
    public void setId(java.math.BigDecimal id) {
        _isSetterInvokedId = true;
        _modifiedProperties.addPropertyName("id");
        _id = id;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String deptno_COLUMN = "deptno";

    /**
     * Get the value of deptno.
     * 
     * @return The value of deptno. (Nullable)
     */
    public java.math.BigDecimal getDeptno() {
        return _deptno;
    }
  
    /**
     * Set the value of deptno.
     * 
     * @param deptno The value of deptno. (Nullable)
     */
    public void setDeptno(java.math.BigDecimal deptno) {
        _isSetterInvokedDeptno = true;
        _modifiedProperties.addPropertyName("deptno");
        _deptno = deptno;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String deptname_COLUMN = "deptname";

    /**
     * Get the value of deptname.
     * 
     * @return The value of deptname. (Nullable)
     */
    public String getDeptname() {
        return _deptname;
    }
  
    /**
     * Set the value of deptname.
     * 
     * @param deptname The value of deptname. (Nullable)
     */
    public void setDeptname(String deptname) {
        _isSetterInvokedDeptname = true;
        _modifiedProperties.addPropertyName("deptname");
        _deptname = deptname;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String loc_COLUMN = "loc";

    /**
     * Get the value of loc.
     * 
     * @return The value of loc. (Nullable)
     */
    public String getLoc() {
        return _loc;
    }
  
    /**
     * Set the value of loc.
     * 
     * @param loc The value of loc. (Nullable)
     */
    public void setLoc(String loc) {
        _isSetterInvokedLoc = true;
        _modifiedProperties.addPropertyName("loc");
        _loc = loc;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String versionno_COLUMN = "versionno";

    /**
     * Get the value of versionno.
     * 
     * @return The value of versionno. (Nullable)
     */
    public java.math.BigDecimal getVersionno() {
        return _versionno;
    }
  
    /**
     * Set the value of versionno.
     * 
     * @param versionno The value of versionno. (Nullable)
     */
    public void setVersionno(java.math.BigDecimal versionno) {
        _isSetterInvokedVersionno = true;
        _modifiedProperties.addPropertyName("versionno");
        _versionno = versionno;
    }
  
    // =====================================================================================
    //                                                                Invoking Determination
    //                                                                ======================
  
    /**
     * Has the setter of id been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedId() {
        return _isSetterInvokedId;
    }
    
    /**
     * Has the setter of deptno been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedDeptno() {
        return _isSetterInvokedDeptno;
    }
    
    /**
     * Has the setter of deptname been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedDeptname() {
        return _isSetterInvokedDeptname;
    }
    
    /**
     * Has the setter of loc been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedLoc() {
        return _isSetterInvokedLoc;
    }
    
    /**
     * Has the setter of versionno been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedVersionno() {
        return _isSetterInvokedVersionno;
    }
  
    // =====================================================================================
    //                                                                       Classify Method
    //                                                                       ===============
          
    // =====================================================================================
    //                                                          Classification Determination
    //                                                          ============================
          
    // =====================================================================================
    //                                                                 Classification Getter
    //                                                                 =====================
          
    // =====================================================================================
    //                                                                         Foreign Table
    //                                                                         =============

    // =====================================================================================
    //                                                                        Refferer Table
    //                                                                        ==============

  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ReffererTable    = [employee]
    //   ReffererProperty = [employeeList]
    // * * * * * * * * */
  
    /** The list of refferer table. */
    protected java.util.List<org.seasar.s2click.example.dao.exentity.Employee> _childrenEmployeeList;

    /**
     * Get the list of refferer table without lazyload.
     * If it's not loaded yet, returns null.
     * 
     * @return The list of refferer table. (Nullable)
     */
    public java.util.List<org.seasar.s2click.example.dao.exentity.Employee> getEmployeeList() {
        return _childrenEmployeeList;
    }

    /**
     * Set the list of refferer table.
     * 
     * @param value The list of refferer table. (Nullable)
     */
    public void setEmployeeList(java.util.List<org.seasar.s2click.example.dao.exentity.Employee> value) {
        _childrenEmployeeList = value;
    }
  
    // =====================================================================================
    //                                                                                Accept
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMap Primary key map. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMap(java.util.Map<String, ? extends Object> primaryKeyMap) {
        MapAssertUtil.assertPrimaryKeyMapNotNullAndNotEmpty(primaryKeyMap);
  
        MapAssertUtil.assertColumnExistingInPrimaryKeyMap(primaryKeyMap, "id");
        {
            final Object obj = primaryKeyMap.get("id");
            if (obj == null) {
                _id = null; _modifiedProperties.remove("id");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setId((java.math.BigDecimal)obj);
                } else {
                    try {
                        setId(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMapString Primary-key map-string. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMapString(String primaryKeyMapString) {
        MapStringUtil.acceptPrimaryKeyMapString(primaryKeyMapString, this);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param columnValueMap Column-value map. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMap(java.util.Map<String, ? extends Object> columnValueMap) {
        MapAssertUtil.assertColumnValueMapNotNullAndNotEmpty(columnValueMap);
  
        {
            final Object obj = columnValueMap.get("id");
            if (obj == null) {
                _id = null; _modifiedProperties.remove("id");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setId((java.math.BigDecimal)obj);
                } else {
                    try {
                        setId(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("deptno");
            if (obj == null) {
                _deptno = null; _modifiedProperties.remove("deptno");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setDeptno((java.math.BigDecimal)obj);
                } else {
                    try {
                        setDeptno(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setDeptno(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("deptname");
            if (obj == null) {
                _deptname = null; _modifiedProperties.remove("deptname");
            } else {
    
                checkTypeString(obj, "deptname", "String");
                setDeptname((String)obj);
            }
        }
      
        {
            final Object obj = columnValueMap.get("loc");
            if (obj == null) {
                _loc = null; _modifiedProperties.remove("loc");
            } else {
    
                checkTypeString(obj, "loc", "String");
                setLoc((String)obj);
            }
        }
      
        {
            final Object obj = columnValueMap.get("versionno");
            if (obj == null) {
                _versionno = null; _modifiedProperties.remove("versionno");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setVersionno((java.math.BigDecimal)obj);
                } else {
                    try {
                        setVersionno(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setVersionno(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param columnValueMapString Column-value map-string. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMapString(String columnValueMapString) {
        MapStringUtil.acceptColumnValueMapString(columnValueMapString, this);
    }

    private void checkTypeString(Object value, String propertyName, String typeName) {
        MapStringUtil.checkTypeString(value, propertyName, typeName);
    }

    private long parseDateString(Object value, String propertyName, String typeName) {
        return MapStringUtil.parseDateString(value, propertyName, typeName);
    }

    // =====================================================================================
    //                                                                               Extract
    //                                                                               =======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString() {
        return MapStringUtil.extractPrimaryKeyMapString(this);
    }

    /**
     * Extract primary-key map-string.
     * 
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString(String startBrace, String endBrace, String delimiter, String equal) {
        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();
  
        appendColumnValueString(sb, delimiter, equal, "id", _id);
  
        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();

    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString() {
        return MapStringUtil.extractColumnValueMapString(this);
    }

    /**
     * Extract column-value map-string.
     * 
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString(String startBrace, String endBrace, String delimiter, String equal) {
        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();
        appendColumnValueString(sb, delimiter, equal, "id", _id);
        appendColumnValueString(sb, delimiter, equal, "deptno", _deptno);
        appendColumnValueString(sb, delimiter, equal, "deptname", _deptname);
        appendColumnValueString(sb, delimiter, equal, "loc", _loc);
        appendColumnValueString(sb, delimiter, equal, "versionno", _versionno);

        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();
    }

    private void appendColumnValueString(StringBuffer sb, String delimiter, String equal, String colName, Object value) {
        sb.append(delimiter).append(colName).append(equal);
        if (value instanceof java.util.Date) {
            sb.append((value != null ? formatDate((java.util.Date)value) : ""));
        } else {
            sb.append((value != null ? value.toString() : ""));
        }
    }



    protected String formatDate(java.util.Date value) {
        return MapStringUtil.formatDate(value);
    }

    // =====================================================================================
    //                                                                         Determination
    //                                                                         =============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Determination.
     */
    public boolean hasPrimaryKeyValue() {
  
        if (_id == null) {
            return false;
        }
  
        return true;
    }

    // =====================================================================================
    //                                                                   Modified Properties
    //                                                                   ===================
    public java.util.Set<String> getModifiedPropertyNames() {
        return _modifiedProperties.getPropertyNames();
    }

    protected EntityModifiedProperties newEntityModifiedProperties() {
        return new EntityModifiedProperties();
    }

    /**
     * Clear modified property names.
     */
    public void clearModifiedPropertyNames() {
        _modifiedProperties.clear();
    }

    // =====================================================================================
    //                                                                        Basic Override
    //                                                                        ==============

    /**
     * This method overrides the method that is declared at super.
     * If the primary-key of the other is same as this one, returns true.
     * 
     * @param other Other entity.
     * @return Comparing result.
     */
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (!(other instanceof BsDept)) {
            return false;
        }
        final BsDept otherEntity = (BsDept)other;
  
        if (getId() == null || !getId().equals(otherEntity.getId())) {
            return false;
        }
  
        return true;
    }

    /**
     * This method overrides the method that is declared at super.
     * Calculates hash-code from primary-key.
     * 
     * @return Hash-code from primary-keys.
     */
    public int hashCode() {
        int result = 0;
  
        if (this.getId() != null) {
            result = result + getId().hashCode();
        }
  
        return result;
    }

    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String toString() {
        final String delimiter = ",";
        final StringBuffer sb = new StringBuffer();

        sb.append(delimiter).append(getId());

        sb.append(delimiter).append(getDeptno());

        sb.append(delimiter).append(getDeptname());

        sb.append(delimiter).append(getLoc());

        sb.append(delimiter).append(getVersionno());

        sb.delete(0, delimiter.length());
        sb.insert(0, "{").append("}");
        return sb.toString();
    }
}
