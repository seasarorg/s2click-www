package org.seasar.s2click.example.page.employee;

import java.math.BigDecimal;
import java.util.Hashtable;

import net.sf.click.control.Form;
import net.sf.click.control.HiddenField;
import net.sf.click.control.Submit;

import org.seasar.s2click.control.TextAndHidden;
import org.seasar.s2click.example.dao.exbhv.EmployeeBhv;
import org.seasar.s2click.example.dao.exentity.Employee;
import org.seasar.s2click.example.page.BorderPage;
import org.seasar.s2click.util.Utility;

public class ConfirmPage extends BorderPage{
	
	public Form form = new Form("form");
	private EmployeeBhv employeeBhv;
	private Submit submit =new Submit("submit"," OK ",this,"onOkClicked");
	private Submit submit2 =new Submit("submit2","戻る",this,"onPreviousClicked");	
	public ConfirmPage(){

	}
	public void onInit(){
		form.add(new HiddenField("mode",""));
		form.add(new TextAndHidden("id"));
		form.getField("id").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("empno"));
		form.getField("empno").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("empname"));
		form.getField("empname").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("job"));
		form.getField("job").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("manager"));
		form.getField("manager").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("managerName"));
		form.getField("managerName").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("hiredate"));
		form.getField("hiredate").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("salary"));
		form.getField("salary").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("deptid"));
		form.getField("deptid").setAttribute("style","font-weight:bold");
		form.add(new TextAndHidden("deptName"));
		form.getField("deptName").setAttribute("style","font-weight:bold");	
		form.add(new HiddenField("versionnos",""));
		form.add(submit);
		form.add(submit2);
	}
	public void onGet() {
		Hashtable ht =  
			(Hashtable)Utility.getParameterFromSession(this);
		if (ht==null){
			form.setError("このページには、直接飛べません");
			submit.setDisabled(true);
			return;
		}
		getModel().put("title","Confirm-"+ht.get("mode")+" Page");
		Employee employee = (Employee) ht.get("employee");
		form.copyFrom(employee);
		form.getField("versionnos").setValue(employee.getVersionno().toString());
		form.getField("mode").setValue((String) ht.get("mode"));
		form.getField("hiredate").setValue(Utility.getDataYYYYMMDD(employee.getHiredate()));
	}
	public boolean onOkClicked(){
		Employee employee = getEmployeeFromForm();
		String m = form.getFieldValue("mode");
		if (form.getFieldValue("mode").equals("new")){
			try {
				int res =employeeBhv.delegateInsert(employee);
			}
			catch (Exception e) {
				// TODO: handle exception
				form.setError("Insert Error 最初からやり直して下さい");
				return true;
			}
			setRedirect(getContext().getPagePath(EditPage.class) + "?mode=new");	
		}
		else if (form.getFieldValue("mode").equals("edit")){
			BigDecimal bid = employee.getId();
			try {
				int res =employeeBhv.delegateUpdate(employee);
			}
			catch (Exception e) {
				// TODO: handle exception
				form.setError("Update Error 最初からやり直して下さい");
				return true;
			}
			setRedirect(getContext().getPagePath(EditPage.class) +
					"?mode=edit&id="+bid.toString());	
		}
		return false;
	}
	private Employee getEmployeeFromForm() {
		Employee employee = new Employee();
		form.copyTo(employee);
		String versionnos = form.getFieldValue("versionnos");
		if (!versionnos.equals("")){
			employee.setVersionno(new BigDecimal(versionnos));
		}
		employee.setHiredate(Utility.convDataYYYYMMDD(form.getFieldValue("hiredate")));
		return employee;
	}
	public boolean onPreviousClicked(){
		Employee employee = getEmployeeFromForm();
		Hashtable ht = new Hashtable();
		ht.put("mode",form.getFieldValue("mode"));
		ht.put("employee",employee);
		Utility.setRedirectWithParameter(
    			this, ht,EditPage.class);
		return false;
	}
	public void setEmployeeBhv(EmployeeBhv employeeBhv) {
		this.employeeBhv = employeeBhv;
	}
}