package org.seasar.s2click.example.util;

import java.math.BigDecimal;
import java.util.Hashtable;

import net.sf.click.control.Form;
import net.sf.click.control.Option;
import net.sf.click.control.Select;

import org.seasar.s2click.example.dao.allcommon.cbean.ListResultBean;
import org.seasar.s2click.example.dao.cbean.DeptCB;
import org.seasar.s2click.example.dao.exbhv.DeptBhv;
import org.seasar.s2click.example.dao.exentity.Dept;

public class CommonLogic {
	private static ListResultBean<Dept> depts;
	private static Hashtable dept = new Hashtable();
	public static void setDeptOptions(Select select, Form form, DeptBhv deptbhv){
		if (depts == null) {
			DeptCB cb = new DeptCB();
			cb.query().addOrderBy_Deptno_Asc();
		    depts = deptbhv.selectList(cb);
			for (Dept d : depts.getSelectedList()){
				 dept.put(d.getId(),d.getDeptname());
			}
		}
		Option o = new Option("","");
		((Select)form.getField("deptid")).add(o);
		for (Dept d : depts.getSelectedList()){
			o = new Option(d.getId(),d.getDeptname());
			((Select)form.getField("deptid")).add(o);
		}		
	}
	public static String getDeptNameByDeptId(BigDecimal id){
		return (String) dept.get(id);
	}
}
