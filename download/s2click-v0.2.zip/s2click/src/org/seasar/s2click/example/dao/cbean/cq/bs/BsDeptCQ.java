
package org.seasar.s2click.example.dao.cbean.cq.bs;

import org.seasar.s2click.example.dao.cbean.cq.*;
  
import org.seasar.s2click.example.dao.allcommon.cbean.*;
import org.seasar.s2click.example.dao.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.dao.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.dao.allcommon.cbean.sqlclause.SqlClause;
import org.seasar.s2click.example.dao.cbean.cq.ciq.*;

/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class BsDeptCQ extends AbstractBsDeptCQ {

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    protected DeptCIQ _inlineQuery;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public BsDeptCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // =====================================================================================
    //                                                                                Inline
    //                                                                                ======
    /**
     * Get inline query.
     * 
     * @return Inline query. (NotNull)
     */
    public DeptCIQ inline() {
        if (_inlineQuery == null) {
            _inlineQuery = new DeptCIQ(getChildQuery(), getSqlClause(), getAliasName(), getNestLevel(), this);
        }
        return _inlineQuery;
    }

    // =====================================================================================
    //                                                                         IncludeAsMine
    //                                                                         =============
  
    /**
     * Include select-column of id as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Id() {
        registerIncludedSelectColumn("Id", getRealColumnName("id"));
    }

    /**
     * Include select-column of id as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Id(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("id"));
    }
  
    /**
     * Include select-column of deptno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Deptno() {
        registerIncludedSelectColumn("Deptno", getRealColumnName("deptno"));
    }

    /**
     * Include select-column of deptno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Deptno(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("deptno"));
    }
  
    /**
     * Include select-column of deptname as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Deptname() {
        registerIncludedSelectColumn("Deptname", getRealColumnName("deptname"));
    }

    /**
     * Include select-column of deptname as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Deptname(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("deptname"));
    }
  
    /**
     * Include select-column of loc as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Loc() {
        registerIncludedSelectColumn("Loc", getRealColumnName("loc"));
    }

    /**
     * Include select-column of loc as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Loc(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("loc"));
    }
  
    /**
     * Include select-column of versionno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     */
    public void includeAsMine_Versionno() {
        registerIncludedSelectColumn("Versionno", getRealColumnName("versionno"));
    }

    /**
     * Include select-column of versionno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     */
    public void includeAsMine_Versionno(String aliasName) {
        registerIncludedSelectColumn(aliasName, getRealColumnName("versionno"));
    }
  
    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [dept]
    // * * * * * * * * */

  
    /** The attribute of id. */
    protected ConditionValue _id;

    /**
     * Get the value of id.
     * 
     * @return The value of id.
     */
    public ConditionValue getId() {
        if (_id == null) {
            _id = new ConditionValue();
        }
        return _id;
    }

    protected ConditionValue getCValueId() {
        return getId();
    }

              
    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_Equal_AsInline(long value) {
        registerInlineId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_NotEqual_AsInline(long value) {
        registerInlineId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterThan_AsInline(long value) {
        registerInlineId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessThan_AsInline(long value) {
        registerInlineId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_GreaterEqual_AsInline(long value) {
        registerInlineId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineId(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_LessEqual_AsInline(long value) {
        registerInlineId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
                          
    /** The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeList;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery. (Nullable)
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeList() {
        return _id_InScopeSubQuery_EmployeeList;
    }

    public void keepId_InScopeSubQuery_EmployeeList(EmployeeCQ subQuery) {
        _id_InScopeSubQuery_EmployeeList = subQuery;
    }
          
    /** The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeList_AsInline;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline. (Nullable)
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeList_AsInline() {
        return _id_InScopeSubQuery_EmployeeList_AsInline;
    }

    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline.
     * { in (select xxx.deptid from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline. (NotNull)
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setId_InScopeSubQuery_EmployeeList_AsInline(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_InScopeSubQuery_EmployeeList_AsInline = subQuery;// for saving query-value.
        registerInlineInScopeSubQuery(subQuery, COL_id, "deptid", "id_InScopeSubQuery_EmployeeList_AsInline");
    }
                                      
    /** The sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery. */
    protected EmployeeCQ _id_ExistsSubQuery_EmployeeList;

    /**
     * Get the sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery.
     * 
     * @return The sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery. (Nullable)
     */
    public EmployeeCQ getId_ExistsSubQuery_EmployeeList() {
        return _id_ExistsSubQuery_EmployeeList;
    }

    public void keepId_ExistsSubQuery_EmployeeList(EmployeeCQ subQuery) {
        _id_ExistsSubQuery_EmployeeList = subQuery;
    }
                                      
    /**
     * Add order-by of id as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Id_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, true);return this;
    }

    /**
     * Add order-by of id as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Id_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, false);return this;
    }
      
    /** The attribute of deptno. */
    protected ConditionValue _deptno;

    /**
     * Get the value of deptno.
     * 
     * @return The value of deptno.
     */
    public ConditionValue getDeptno() {
        if (_deptno == null) {
            _deptno = new ConditionValue();
        }
        return _deptno;
    }

    protected ConditionValue getCValueDeptno() {
        return getDeptno();
    }

              
    /**
     * Set the value of deptno using equal as inline. { = }
     * 
     * @param value The value of deptno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineDeptno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of deptno using equal as inline. { = }
     * 
     * @param value The value of deptno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_Equal_AsInline(long value) {
        registerInlineDeptno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of deptno using notEqual as inline. { != }
     * 
     * @param value The value of deptno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineDeptno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of deptno using notEqual as inline. { != }
     * 
     * @param value The value of deptno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_NotEqual_AsInline(long value) {
        registerInlineDeptno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineDeptno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of deptno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_GreaterThan_AsInline(long value) {
        registerInlineDeptno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineDeptno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of deptno using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_LessThan_AsInline(long value) {
        registerInlineDeptno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineDeptno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of deptno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_GreaterEqual_AsInline(long value) {
        registerInlineDeptno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineDeptno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of deptno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptno_LessEqual_AsInline(long value) {
        registerInlineDeptno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
                                                
    /**
     * Add order-by of deptno as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Deptno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptno), null, true);return this;
    }

    /**
     * Add order-by of deptno as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Deptno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptno), null, false);return this;
    }
      
    /** The attribute of deptname. */
    protected ConditionValue _deptname;

    /**
     * Get the value of deptname.
     * 
     * @return The value of deptname.
     */
    public ConditionValue getDeptname() {
        if (_deptname == null) {
            _deptname = new ConditionValue();
        }
        return _deptname;
    }

    protected ConditionValue getCValueDeptname() {
        return getDeptname();
    }

          
    /**
     * Set the value of deptname using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_Equal_AsInline(String value) {
        registerInlineDeptname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }
      
    /**
     * Set the value of deptname using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_NotEqual_AsInline(String value) {
        registerInlineDeptname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_GreaterThan_AsInline(String value) {
        registerInlineDeptname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_LessThan_AsInline(String value) {
        registerInlineDeptname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_GreaterEqual_AsInline(String value) {
        registerInlineDeptname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_LessEqual_AsInline(String value) {
        registerInlineDeptname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as prefixSearch.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_PrefixSearch_AsInline(String value) {
        registerInlineDeptname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptname as inScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_InScope_AsInline(java.util.List<String> valueList) {
        registerInlineDeptname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of deptname using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptname as notInScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setDeptname_NotInScope_AsInline(java.util.List<String> valueList) {
        registerInlineDeptname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                                    
    /**
     * Add order-by of deptname as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Deptname_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptname), null, true);return this;
    }

    /**
     * Add order-by of deptname as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Deptname_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptname), null, false);return this;
    }
      
    /** The attribute of loc. */
    protected ConditionValue _loc;

    /**
     * Get the value of loc.
     * 
     * @return The value of loc.
     */
    public ConditionValue getLoc() {
        if (_loc == null) {
            _loc = new ConditionValue();
        }
        return _loc;
    }

    protected ConditionValue getCValueLoc() {
        return getLoc();
    }

          
    /**
     * Set the value of loc using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_Equal_AsInline(String value) {
        registerInlineLoc(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }
      
    /**
     * Set the value of loc using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_NotEqual_AsInline(String value) {
        registerInlineLoc(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_GreaterThan_AsInline(String value) {
        registerInlineLoc(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_LessThan_AsInline(String value) {
        registerInlineLoc(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_GreaterEqual_AsInline(String value) {
        registerInlineLoc(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_LessEqual_AsInline(String value) {
        registerInlineLoc(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as prefixSearch.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_PrefixSearch_AsInline(String value) {
        registerInlineLoc(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of loc as inScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_InScope_AsInline(java.util.List<String> valueList) {
        registerInlineLoc(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of loc using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of loc as notInScope.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setLoc_NotInScope_AsInline(java.util.List<String> valueList) {
        registerInlineLoc(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                                    
    /**
     * Add order-by of loc as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Loc_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_loc), null, true);return this;
    }

    /**
     * Add order-by of loc as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Loc_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_loc), null, false);return this;
    }
      
    /** The attribute of versionno. */
    protected ConditionValue _versionno;

    /**
     * Get the value of versionno.
     * 
     * @return The value of versionno.
     */
    public ConditionValue getVersionno() {
        if (_versionno == null) {
            _versionno = new ConditionValue();
        }
        return _versionno;
    }

    protected ConditionValue getCValueVersionno() {
        return getVersionno();
    }

              
    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_Equal_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_Equal_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_NotEqual_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_NotEqual_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterThan_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterThan_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessThan_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessThan_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_GreaterEqual_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessEqual_AsInline(java.math.BigDecimal value) {
        registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @deprecated This method is deprecated. Please use query().inline().setXxx_Xxx()!
     */
    public void setVersionno_LessEqual_AsInline(long value) {
        registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
                                                
    /**
     * Add order-by of versionno as ASC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Versionno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, true);return this;
    }

    /**
     * Add order-by of versionno as DESC.
     * 
     * @return this. (NotNull)
     */
    public BsDeptCQ addOrderBy_Versionno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, false);return this;
    }
      
    // =====================================================================================
    //                                                               Query-SetupOuter-Method
    //                                                               =======================

  
        
}
