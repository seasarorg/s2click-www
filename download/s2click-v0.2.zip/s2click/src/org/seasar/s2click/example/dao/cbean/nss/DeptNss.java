package org.seasar.s2click.example.dao.cbean.nss;


import org.seasar.s2click.example.dao.cbean.cq.DeptCQ;


/**
 * The nest select setupper.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class DeptNss {

    /** Base query. */
    protected DeptCQ _query;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param query Base query. (NotNull)
     */
    public DeptNss(DeptCQ query) {
        _query = query;
    }

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========
    public DeptCQ query() {
        return _query;
    }

    public boolean hasConditionQuery() {
        return _query != null;
    }

    // =====================================================================================
    //                                                                           SetupSelect
    //                                                                           ===========
  
    // =====================================================================================
    //                                                                                Helper
    //                                                                                ======
    protected void assertConditionQuery() {
        if (!hasConditionQuery()) {
            String msg = "The query should not be null.";
            throw new IllegalStateException(msg);
        }
    }
}
