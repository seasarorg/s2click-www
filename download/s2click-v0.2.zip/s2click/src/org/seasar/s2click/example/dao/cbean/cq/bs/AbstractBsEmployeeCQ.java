
package org.seasar.s2click.example.dao.cbean.cq.bs;



import org.seasar.s2click.example.dao.allcommon.cbean.*;
import org.seasar.s2click.example.dao.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.dao.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.dao.allcommon.cbean.sqlclause.SqlClause;
import org.seasar.s2click.example.dao.cbean.cq.*;

/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class AbstractBsEmployeeCQ extends AbstractConditionQuery {

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public AbstractBsEmployeeCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    final public String getTableDbName() {
        return "employee";
    }

    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [employee]
    // * * * * * * * * */

      
    /** Column db name of id. */
    protected static final String COL_id = "id";

    /** Column java name of id. */
    protected static final String J_Id = "Id";

    /** Column uncapitalised java name of id. */
    protected static final String UJ_id = "id";
            
    /**
     * Set the value of id using equal. { = }
     * 
     * @param id The value of id as equal.
     */
    public void setId_Equal(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_EQUAL, id);
    }
            
    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param id The value of id as notEqual.
     */
    public void setId_NotEqual(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_NOT_EQUAL, id);
    }
            
    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param id The value of id as greaterThan.
     */
    public void setId_GreaterThan(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_GREATER_THAN, id);
    }
            
    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param id The value of id as lessThan.
     */
    public void setId_LessThan(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_LESS_THAN, id);
    }
            
    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param id The value of id as greaterEqual.
     */
    public void setId_GreaterEqual(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_GREATER_EQUAL, id);
    }
            
    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param id The value of id as lessEqual.
     */
    public void setId_LessEqual(java.math.BigDecimal id) {
        registerId(ConditionKey.CK_LESS_EQUAL, id);
    }
            
    /**
     * Set the value of id using equal. { = }
     * 
     * @param id The value of id as equal.
     */
    public void setId_Equal(long id) {
        registerId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
        
    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param id The value of id as notEqual.
     */
    public void setId_NotEqual(long id) {
        registerId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param id The value of id as greaterThan.
     */
    public void setId_GreaterThan(long id) {
        registerId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param id The value of id as lessThan.
     */
    public void setId_LessThan(long id) {
        registerId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param id The value of id as greaterEqual.
     */
    public void setId_GreaterEqual(long id) {
        registerId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
                
    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param id The value of id as lessEqual.
     */
    public void setId_LessEqual(long id) {
        registerId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(id)));
    }
                    
    /**
     * Set the value of id using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param idList The value of id as inScope.
     */
    public void setId_InScope(java.util.List<java.math.BigDecimal> idList) {
        registerId(ConditionKey.CK_IN_SCOPE, idList);
    }
            
    /**
     * Set the value of id using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param idList The value of id as notInScope.
     */
    public void setId_NotInScope(java.util.List<java.math.BigDecimal> idList) {
        registerId(ConditionKey.CK_NOT_IN_SCOPE, idList);
    }
                          
    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery.
     * { in (select xxx.manager from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery. (NotNull)
     */
    public void setId_InScopeSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        keepId_InScopeSubQuery_EmployeeSelfList(subQuery);// for saving query-value.
        registerInScopeSubQuery(subQuery, COL_id, "manager", "id_InScopeSubQuery_EmployeeSelfList");
    }

    abstract public void keepId_InScopeSubQuery_EmployeeSelfList(EmployeeCQ subQuery);
                            
    /**
     * Set the sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery.
     * { exists (select xxx.manager from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery. (NotNull)
     */
    public void setId_ExistsSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        keepId_ExistsSubQuery_EmployeeSelfList(subQuery);// for saving query-value.
        registerExistsSubQuery(subQuery, COL_id, "manager", "id_ExistsSubQuery_EmployeeSelfList");
    }

    abstract public void keepId_ExistsSubQuery_EmployeeSelfList(EmployeeCQ subQuery);
                                      
    /**
     * Register condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     */
    protected void registerId(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueId(), COL_id, J_Id, UJ_id);
    }

    /**
     * Register inline condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     */
    protected void registerInlineId(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueId(), COL_id, J_Id, UJ_id);
    }

    abstract protected ConditionValue getCValueId();
      
    /** Column db name of empno. */
    protected static final String COL_empno = "empno";

    /** Column java name of empno. */
    protected static final String J_Empno = "Empno";

    /** Column uncapitalised java name of empno. */
    protected static final String UJ_empno = "empno";
            
    /**
     * Set the value of empno using equal. { = }
     * 
     * @param empno The value of empno as equal.
     */
    public void setEmpno_Equal(java.math.BigDecimal empno) {
        registerEmpno(ConditionKey.CK_EQUAL, empno);
    }
            
    /**
     * Set the value of empno using notEqual. { != }
     * 
     * @param empno The value of empno as notEqual.
     */
    public void setEmpno_NotEqual(java.math.BigDecimal empno) {
        registerEmpno(ConditionKey.CK_NOT_EQUAL, empno);
    }
            
    /**
     * Set the value of empno using greaterThan. { &gt; }
     * 
     * @param empno The value of empno as greaterThan.
     */
    public void setEmpno_GreaterThan(java.math.BigDecimal empno) {
        registerEmpno(ConditionKey.CK_GREATER_THAN, empno);
    }
            
    /**
     * Set the value of empno using lessThan. { &lt; }
     * 
     * @param empno The value of empno as lessThan.
     */
    public void setEmpno_LessThan(java.math.BigDecimal empno) {
        registerEmpno(ConditionKey.CK_LESS_THAN, empno);
    }
            
    /**
     * Set the value of empno using greaterEqual. { &gt;= }
     * 
     * @param empno The value of empno as greaterEqual.
     */
    public void setEmpno_GreaterEqual(java.math.BigDecimal empno) {
        registerEmpno(ConditionKey.CK_GREATER_EQUAL, empno);
    }
            
    /**
     * Set the value of empno using lessEqual. { &lt;= }
     * 
     * @param empno The value of empno as lessEqual.
     */
    public void setEmpno_LessEqual(java.math.BigDecimal empno) {
        registerEmpno(ConditionKey.CK_LESS_EQUAL, empno);
    }
            
    /**
     * Set the value of empno using equal. { = }
     * 
     * @param empno The value of empno as equal.
     */
    public void setEmpno_Equal(long empno) {
        registerEmpno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(empno)));
    }
        
    /**
     * Set the value of empno using notEqual. { != }
     * 
     * @param empno The value of empno as notEqual.
     */
    public void setEmpno_NotEqual(long empno) {
        registerEmpno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(empno)));
    }
                
    /**
     * Set the value of empno using greaterThan. { &gt; }
     * 
     * @param empno The value of empno as greaterThan.
     */
    public void setEmpno_GreaterThan(long empno) {
        registerEmpno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(empno)));
    }
                
    /**
     * Set the value of empno using lessThan. { &lt; }
     * 
     * @param empno The value of empno as lessThan.
     */
    public void setEmpno_LessThan(long empno) {
        registerEmpno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(empno)));
    }
                
    /**
     * Set the value of empno using greaterEqual. { &gt;= }
     * 
     * @param empno The value of empno as greaterEqual.
     */
    public void setEmpno_GreaterEqual(long empno) {
        registerEmpno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(empno)));
    }
                
    /**
     * Set the value of empno using lessEqual. { &lt;= }
     * 
     * @param empno The value of empno as lessEqual.
     */
    public void setEmpno_LessEqual(long empno) {
        registerEmpno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(empno)));
    }
                    
    /**
     * Set the value of empno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param empnoList The value of empno as inScope.
     */
    public void setEmpno_InScope(java.util.List<java.math.BigDecimal> empnoList) {
        registerEmpno(ConditionKey.CK_IN_SCOPE, empnoList);
    }
            
    /**
     * Set the value of empno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param empnoList The value of empno as notInScope.
     */
    public void setEmpno_NotInScope(java.util.List<java.math.BigDecimal> empnoList) {
        registerEmpno(ConditionKey.CK_NOT_IN_SCOPE, empnoList);
    }
                                                
    /**
     * Register condition of empno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empno. (Nullable)
     */
    protected void registerEmpno(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueEmpno(), COL_empno, J_Empno, UJ_empno);
    }

    /**
     * Register inline condition of empno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empno. (Nullable)
     */
    protected void registerInlineEmpno(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueEmpno(), COL_empno, J_Empno, UJ_empno);
    }

    abstract protected ConditionValue getCValueEmpno();
      
    /** Column db name of empname. */
    protected static final String COL_empname = "empname";

    /** Column java name of empname. */
    protected static final String J_Empname = "Empname";

    /** Column uncapitalised java name of empname. */
    protected static final String UJ_empname = "empname";
    
    /**
     * Set the value of empname using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param empname The value of empname as equal.
     */
    public void setEmpname_Equal(String empname) {
        registerEmpname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(empname));
    }
      
    /**
     * Set the empty-string of empname as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public void setEmpname_Equal_EmptyString() {
        registerEmpname(ConditionKey.CK_EQUAL, "");
    }
                  
    /**
     * Set the value of empname using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param empname The value of empname as notEqual.
     */
    public void setEmpname_NotEqual(String empname) {
        registerEmpname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(empname));
    }
            
    /**
     * Set the value of empname using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param empname The value of empname as greaterThan.
     */
    public void setEmpname_GreaterThan(String empname) {
        registerEmpname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(empname));
    }
            
    /**
     * Set the value of empname using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param empname The value of empname as lessThan.
     */
    public void setEmpname_LessThan(String empname) {
        registerEmpname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(empname));
    }
            
    /**
     * Set the value of empname using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param empname The value of empname as greaterEqual.
     */
    public void setEmpname_GreaterEqual(String empname) {
        registerEmpname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(empname));
    }
            
    /**
     * Set the value of empname using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param empname The value of empname as lessEqual.
     */
    public void setEmpname_LessEqual(String empname) {
        registerEmpname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(empname));
    }
            
    /**
     * Set the value of empname using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param empname The value of empname as prefixSearch.
     */
    public void setEmpname_PrefixSearch(String empname) {
        registerEmpname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(empname));
    }
            
    /**
     * Set the value of empname using likeSearch. { like '%xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * You can invoke this method several times and the conditions are set up.
     * 
     * @param empname The value of empname as likeSearch.
     * @param likeSearchOption Like search option. (NotNull)
     */
    public void setEmpname_LikeSearch(String empname, org.seasar.s2click.example.dao.allcommon.cbean.coption.LikeSearchOption option) {
        registerLikeSearchQuery(ConditionKey.CK_LIKE_SEARCH, filterRemoveEmptyString(empname), getCValueEmpname(), COL_empname, J_Empname, UJ_empname, option);
    }
            
    /**
     * Set the value of empname using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param empnameList The value of empname as inScope.
     */
    public void setEmpname_InScope(java.util.List<String> empnameList) {
        registerEmpname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(empnameList));
    }

    /**
     * Set the value of empname using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param empname The value of empname as inScope.
     */
    public void setEmpname_InScope(String empname, org.seasar.s2click.example.dao.allcommon.cbean.coption.InScopeOption option) {
        registerInScopeQuery(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyString(empname), getCValueEmpname(), COL_empname, J_Empname, UJ_empname, option);
    }
            
    /**
     * Set the value of empname using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param empnameList The value of empname as notInScope.
     */
    public void setEmpname_NotInScope(java.util.List<String> empnameList) {
        registerEmpname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(empnameList));
    }
                                                    
    /**
     * Register condition of empname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empname. (Nullable)
     */
    protected void registerEmpname(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueEmpname(), COL_empname, J_Empname, UJ_empname);
    }

    /**
     * Register inline condition of empname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empname. (Nullable)
     */
    protected void registerInlineEmpname(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueEmpname(), COL_empname, J_Empname, UJ_empname);
    }

    abstract protected ConditionValue getCValueEmpname();
      
    /** Column db name of job. */
    protected static final String COL_job = "job";

    /** Column java name of job. */
    protected static final String J_Job = "Job";

    /** Column uncapitalised java name of job. */
    protected static final String UJ_job = "job";
    
    /**
     * Set the value of job using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param job The value of job as equal.
     */
    public void setJob_Equal(String job) {
        registerJob(ConditionKey.CK_EQUAL, filterRemoveEmptyString(job));
    }
      
    /**
     * Set the empty-string of job as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public void setJob_Equal_EmptyString() {
        registerJob(ConditionKey.CK_EQUAL, "");
    }
                  
    /**
     * Set the value of job using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param job The value of job as notEqual.
     */
    public void setJob_NotEqual(String job) {
        registerJob(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(job));
    }
            
    /**
     * Set the value of job using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param job The value of job as greaterThan.
     */
    public void setJob_GreaterThan(String job) {
        registerJob(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(job));
    }
            
    /**
     * Set the value of job using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param job The value of job as lessThan.
     */
    public void setJob_LessThan(String job) {
        registerJob(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(job));
    }
            
    /**
     * Set the value of job using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param job The value of job as greaterEqual.
     */
    public void setJob_GreaterEqual(String job) {
        registerJob(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(job));
    }
            
    /**
     * Set the value of job using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param job The value of job as lessEqual.
     */
    public void setJob_LessEqual(String job) {
        registerJob(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(job));
    }
            
    /**
     * Set the value of job using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param job The value of job as prefixSearch.
     */
    public void setJob_PrefixSearch(String job) {
        registerJob(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(job));
    }
            
    /**
     * Set the value of job using likeSearch. { like '%xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * You can invoke this method several times and the conditions are set up.
     * 
     * @param job The value of job as likeSearch.
     * @param likeSearchOption Like search option. (NotNull)
     */
    public void setJob_LikeSearch(String job, org.seasar.s2click.example.dao.allcommon.cbean.coption.LikeSearchOption option) {
        registerLikeSearchQuery(ConditionKey.CK_LIKE_SEARCH, filterRemoveEmptyString(job), getCValueJob(), COL_job, J_Job, UJ_job, option);
    }
            
    /**
     * Set the value of job using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param jobList The value of job as inScope.
     */
    public void setJob_InScope(java.util.List<String> jobList) {
        registerJob(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(jobList));
    }

    /**
     * Set the value of job using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param job The value of job as inScope.
     */
    public void setJob_InScope(String job, org.seasar.s2click.example.dao.allcommon.cbean.coption.InScopeOption option) {
        registerInScopeQuery(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyString(job), getCValueJob(), COL_job, J_Job, UJ_job, option);
    }
            
    /**
     * Set the value of job using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param jobList The value of job as notInScope.
     */
    public void setJob_NotInScope(java.util.List<String> jobList) {
        registerJob(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(jobList));
    }
                                                    
    /**
     * Register condition of job.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of job. (Nullable)
     */
    protected void registerJob(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueJob(), COL_job, J_Job, UJ_job);
    }

    /**
     * Register inline condition of job.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of job. (Nullable)
     */
    protected void registerInlineJob(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueJob(), COL_job, J_Job, UJ_job);
    }

    abstract protected ConditionValue getCValueJob();
      
    /** Column db name of manager. */
    protected static final String COL_manager = "manager";

    /** Column java name of manager. */
    protected static final String J_Manager = "Manager";

    /** Column uncapitalised java name of manager. */
    protected static final String UJ_manager = "manager";
            
    /**
     * Set the value of manager using equal. { = }
     * 
     * @param manager The value of manager as equal.
     */
    public void setManager_Equal(java.math.BigDecimal manager) {
        registerManager(ConditionKey.CK_EQUAL, manager);
    }
            
    /**
     * Set the value of manager using notEqual. { != }
     * 
     * @param manager The value of manager as notEqual.
     */
    public void setManager_NotEqual(java.math.BigDecimal manager) {
        registerManager(ConditionKey.CK_NOT_EQUAL, manager);
    }
            
    /**
     * Set the value of manager using greaterThan. { &gt; }
     * 
     * @param manager The value of manager as greaterThan.
     */
    public void setManager_GreaterThan(java.math.BigDecimal manager) {
        registerManager(ConditionKey.CK_GREATER_THAN, manager);
    }
            
    /**
     * Set the value of manager using lessThan. { &lt; }
     * 
     * @param manager The value of manager as lessThan.
     */
    public void setManager_LessThan(java.math.BigDecimal manager) {
        registerManager(ConditionKey.CK_LESS_THAN, manager);
    }
            
    /**
     * Set the value of manager using greaterEqual. { &gt;= }
     * 
     * @param manager The value of manager as greaterEqual.
     */
    public void setManager_GreaterEqual(java.math.BigDecimal manager) {
        registerManager(ConditionKey.CK_GREATER_EQUAL, manager);
    }
            
    /**
     * Set the value of manager using lessEqual. { &lt;= }
     * 
     * @param manager The value of manager as lessEqual.
     */
    public void setManager_LessEqual(java.math.BigDecimal manager) {
        registerManager(ConditionKey.CK_LESS_EQUAL, manager);
    }
            
    /**
     * Set the value of manager using equal. { = }
     * 
     * @param manager The value of manager as equal.
     */
    public void setManager_Equal(long manager) {
        registerManager(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(manager)));
    }
        
    /**
     * Set the value of manager using notEqual. { != }
     * 
     * @param manager The value of manager as notEqual.
     */
    public void setManager_NotEqual(long manager) {
        registerManager(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(manager)));
    }
                
    /**
     * Set the value of manager using greaterThan. { &gt; }
     * 
     * @param manager The value of manager as greaterThan.
     */
    public void setManager_GreaterThan(long manager) {
        registerManager(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(manager)));
    }
                
    /**
     * Set the value of manager using lessThan. { &lt; }
     * 
     * @param manager The value of manager as lessThan.
     */
    public void setManager_LessThan(long manager) {
        registerManager(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(manager)));
    }
                
    /**
     * Set the value of manager using greaterEqual. { &gt;= }
     * 
     * @param manager The value of manager as greaterEqual.
     */
    public void setManager_GreaterEqual(long manager) {
        registerManager(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(manager)));
    }
                
    /**
     * Set the value of manager using lessEqual. { &lt;= }
     * 
     * @param manager The value of manager as lessEqual.
     */
    public void setManager_LessEqual(long manager) {
        registerManager(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(manager)));
    }
                    
    /**
     * Set the value of manager using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param managerList The value of manager as inScope.
     */
    public void setManager_InScope(java.util.List<java.math.BigDecimal> managerList) {
        registerManager(ConditionKey.CK_IN_SCOPE, managerList);
    }
            
    /**
     * Set the value of manager using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param managerList The value of manager as notInScope.
     */
    public void setManager_NotInScope(java.util.List<java.math.BigDecimal> managerList) {
        registerManager(ConditionKey.CK_NOT_IN_SCOPE, managerList);
    }
            
    /**
     * Set the sub-query of Manager_InScopeSubQuery_EmployeeSelf using inScopeSubQuery.
     * { in (select xxx.id from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Manager_InScopeSubQuery_EmployeeSelf using inScopeSubQuery. (NotNull)
     */
    public void setManager_InScopeSubQuery_EmployeeSelf(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        keepManager_InScopeSubQuery_EmployeeSelf(subQuery);// for saving query-value.
        registerInScopeSubQuery(subQuery, COL_manager, "id", "manager_InScopeSubQuery_EmployeeSelf");
    }

    abstract public void keepManager_InScopeSubQuery_EmployeeSelf(EmployeeCQ subQuery);
                                      
    /**
     * Set the value of manager using isNull. { is null }
     */
    public void setManager_IsNull() {
        registerManager(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of manager using isNotNull. { is not null }
     */
    public void setManager_IsNotNull() {
        registerManager(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of manager.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of manager. (Nullable)
     */
    protected void registerManager(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueManager(), COL_manager, J_Manager, UJ_manager);
    }

    /**
     * Register inline condition of manager.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of manager. (Nullable)
     */
    protected void registerInlineManager(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueManager(), COL_manager, J_Manager, UJ_manager);
    }

    abstract protected ConditionValue getCValueManager();
      
    /** Column db name of hiredate. */
    protected static final String COL_hiredate = "hiredate";

    /** Column java name of hiredate. */
    protected static final String J_Hiredate = "Hiredate";

    /** Column uncapitalised java name of hiredate. */
    protected static final String UJ_hiredate = "hiredate";
                
    /**
     * Set the value of hiredate using equal. { = }
     * 
     * @param hiredate The value of hiredate as equal.
     */
    public void setHiredate_Equal(java.util.Date hiredate) {
        registerHiredate(ConditionKey.CK_EQUAL, hiredate);
    }
      
    /**
     * Set the value of hiredate using notEqual. { != }
     * 
     * @param hiredate The value of hiredate as notEqual.
     */
    public void setHiredate_NotEqual(java.util.Date hiredate) {
        registerHiredate(ConditionKey.CK_NOT_EQUAL, hiredate);
    }
            
    /**
     * Set the value of hiredate using greaterThan. { &gt; }
     * 
     * @param hiredate The value of hiredate as greaterThan.
     */
    public void setHiredate_GreaterThan(java.util.Date hiredate) {
        registerHiredate(ConditionKey.CK_GREATER_THAN, hiredate);
    }
            
    /**
     * Set the value of hiredate using lessThan. { &lt; }
     * 
     * @param hiredate The value of hiredate as lessThan.
     */
    public void setHiredate_LessThan(java.util.Date hiredate) {
        registerHiredate(ConditionKey.CK_LESS_THAN, hiredate);
    }
            
    /**
     * Set the value of hiredate using greaterEqual. { &gt;= }
     * 
     * @param hiredate The value of hiredate as greaterEqual.
     */
    public void setHiredate_GreaterEqual(java.util.Date hiredate) {
        registerHiredate(ConditionKey.CK_GREATER_EQUAL, hiredate);
    }
            
    /**
     * Set the value of hiredate using lessEqual. { &lt;= }
     * 
     * @param hiredate The value of hiredate as lessEqual.
     */
    public void setHiredate_LessEqual(java.util.Date hiredate) {
        registerHiredate(ConditionKey.CK_LESS_EQUAL, hiredate);
    }
                          
    /**
     * Register condition of hiredate.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of hiredate. (Nullable)
     */
    protected void registerHiredate(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueHiredate(), COL_hiredate, J_Hiredate, UJ_hiredate);
    }

    /**
     * Register inline condition of hiredate.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of hiredate. (Nullable)
     */
    protected void registerInlineHiredate(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueHiredate(), COL_hiredate, J_Hiredate, UJ_hiredate);
    }

    abstract protected ConditionValue getCValueHiredate();
      
    /** Column db name of salary. */
    protected static final String COL_salary = "salary";

    /** Column java name of salary. */
    protected static final String J_Salary = "Salary";

    /** Column uncapitalised java name of salary. */
    protected static final String UJ_salary = "salary";
            
    /**
     * Set the value of salary using equal. { = }
     * 
     * @param salary The value of salary as equal.
     */
    public void setSalary_Equal(java.math.BigDecimal salary) {
        registerSalary(ConditionKey.CK_EQUAL, salary);
    }
            
    /**
     * Set the value of salary using notEqual. { != }
     * 
     * @param salary The value of salary as notEqual.
     */
    public void setSalary_NotEqual(java.math.BigDecimal salary) {
        registerSalary(ConditionKey.CK_NOT_EQUAL, salary);
    }
            
    /**
     * Set the value of salary using greaterThan. { &gt; }
     * 
     * @param salary The value of salary as greaterThan.
     */
    public void setSalary_GreaterThan(java.math.BigDecimal salary) {
        registerSalary(ConditionKey.CK_GREATER_THAN, salary);
    }
            
    /**
     * Set the value of salary using lessThan. { &lt; }
     * 
     * @param salary The value of salary as lessThan.
     */
    public void setSalary_LessThan(java.math.BigDecimal salary) {
        registerSalary(ConditionKey.CK_LESS_THAN, salary);
    }
            
    /**
     * Set the value of salary using greaterEqual. { &gt;= }
     * 
     * @param salary The value of salary as greaterEqual.
     */
    public void setSalary_GreaterEqual(java.math.BigDecimal salary) {
        registerSalary(ConditionKey.CK_GREATER_EQUAL, salary);
    }
            
    /**
     * Set the value of salary using lessEqual. { &lt;= }
     * 
     * @param salary The value of salary as lessEqual.
     */
    public void setSalary_LessEqual(java.math.BigDecimal salary) {
        registerSalary(ConditionKey.CK_LESS_EQUAL, salary);
    }
            
    /**
     * Set the value of salary using equal. { = }
     * 
     * @param salary The value of salary as equal.
     */
    public void setSalary_Equal(long salary) {
        registerSalary(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(salary)));
    }
        
    /**
     * Set the value of salary using notEqual. { != }
     * 
     * @param salary The value of salary as notEqual.
     */
    public void setSalary_NotEqual(long salary) {
        registerSalary(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(salary)));
    }
                
    /**
     * Set the value of salary using greaterThan. { &gt; }
     * 
     * @param salary The value of salary as greaterThan.
     */
    public void setSalary_GreaterThan(long salary) {
        registerSalary(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(salary)));
    }
                
    /**
     * Set the value of salary using lessThan. { &lt; }
     * 
     * @param salary The value of salary as lessThan.
     */
    public void setSalary_LessThan(long salary) {
        registerSalary(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(salary)));
    }
                
    /**
     * Set the value of salary using greaterEqual. { &gt;= }
     * 
     * @param salary The value of salary as greaterEqual.
     */
    public void setSalary_GreaterEqual(long salary) {
        registerSalary(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(salary)));
    }
                
    /**
     * Set the value of salary using lessEqual. { &lt;= }
     * 
     * @param salary The value of salary as lessEqual.
     */
    public void setSalary_LessEqual(long salary) {
        registerSalary(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(salary)));
    }
                    
    /**
     * Set the value of salary using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param salaryList The value of salary as inScope.
     */
    public void setSalary_InScope(java.util.List<java.math.BigDecimal> salaryList) {
        registerSalary(ConditionKey.CK_IN_SCOPE, salaryList);
    }
            
    /**
     * Set the value of salary using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param salaryList The value of salary as notInScope.
     */
    public void setSalary_NotInScope(java.util.List<java.math.BigDecimal> salaryList) {
        registerSalary(ConditionKey.CK_NOT_IN_SCOPE, salaryList);
    }
                                            
    /**
     * Set the value of salary using isNull. { is null }
     */
    public void setSalary_IsNull() {
        registerSalary(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of salary using isNotNull. { is not null }
     */
    public void setSalary_IsNotNull() {
        registerSalary(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of salary.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of salary. (Nullable)
     */
    protected void registerSalary(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueSalary(), COL_salary, J_Salary, UJ_salary);
    }

    /**
     * Register inline condition of salary.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of salary. (Nullable)
     */
    protected void registerInlineSalary(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueSalary(), COL_salary, J_Salary, UJ_salary);
    }

    abstract protected ConditionValue getCValueSalary();
      
    /** Column db name of deptid. */
    protected static final String COL_deptid = "deptid";

    /** Column java name of deptid. */
    protected static final String J_Deptid = "Deptid";

    /** Column uncapitalised java name of deptid. */
    protected static final String UJ_deptid = "deptid";
            
    /**
     * Set the value of deptid using equal. { = }
     * 
     * @param deptid The value of deptid as equal.
     */
    public void setDeptid_Equal(java.math.BigDecimal deptid) {
        registerDeptid(ConditionKey.CK_EQUAL, deptid);
    }
            
    /**
     * Set the value of deptid using notEqual. { != }
     * 
     * @param deptid The value of deptid as notEqual.
     */
    public void setDeptid_NotEqual(java.math.BigDecimal deptid) {
        registerDeptid(ConditionKey.CK_NOT_EQUAL, deptid);
    }
            
    /**
     * Set the value of deptid using greaterThan. { &gt; }
     * 
     * @param deptid The value of deptid as greaterThan.
     */
    public void setDeptid_GreaterThan(java.math.BigDecimal deptid) {
        registerDeptid(ConditionKey.CK_GREATER_THAN, deptid);
    }
            
    /**
     * Set the value of deptid using lessThan. { &lt; }
     * 
     * @param deptid The value of deptid as lessThan.
     */
    public void setDeptid_LessThan(java.math.BigDecimal deptid) {
        registerDeptid(ConditionKey.CK_LESS_THAN, deptid);
    }
            
    /**
     * Set the value of deptid using greaterEqual. { &gt;= }
     * 
     * @param deptid The value of deptid as greaterEqual.
     */
    public void setDeptid_GreaterEqual(java.math.BigDecimal deptid) {
        registerDeptid(ConditionKey.CK_GREATER_EQUAL, deptid);
    }
            
    /**
     * Set the value of deptid using lessEqual. { &lt;= }
     * 
     * @param deptid The value of deptid as lessEqual.
     */
    public void setDeptid_LessEqual(java.math.BigDecimal deptid) {
        registerDeptid(ConditionKey.CK_LESS_EQUAL, deptid);
    }
            
    /**
     * Set the value of deptid using equal. { = }
     * 
     * @param deptid The value of deptid as equal.
     */
    public void setDeptid_Equal(long deptid) {
        registerDeptid(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(deptid)));
    }
        
    /**
     * Set the value of deptid using notEqual. { != }
     * 
     * @param deptid The value of deptid as notEqual.
     */
    public void setDeptid_NotEqual(long deptid) {
        registerDeptid(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(deptid)));
    }
                
    /**
     * Set the value of deptid using greaterThan. { &gt; }
     * 
     * @param deptid The value of deptid as greaterThan.
     */
    public void setDeptid_GreaterThan(long deptid) {
        registerDeptid(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(deptid)));
    }
                
    /**
     * Set the value of deptid using lessThan. { &lt; }
     * 
     * @param deptid The value of deptid as lessThan.
     */
    public void setDeptid_LessThan(long deptid) {
        registerDeptid(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(deptid)));
    }
                
    /**
     * Set the value of deptid using greaterEqual. { &gt;= }
     * 
     * @param deptid The value of deptid as greaterEqual.
     */
    public void setDeptid_GreaterEqual(long deptid) {
        registerDeptid(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(deptid)));
    }
                
    /**
     * Set the value of deptid using lessEqual. { &lt;= }
     * 
     * @param deptid The value of deptid as lessEqual.
     */
    public void setDeptid_LessEqual(long deptid) {
        registerDeptid(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(deptid)));
    }
                    
    /**
     * Set the value of deptid using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param deptidList The value of deptid as inScope.
     */
    public void setDeptid_InScope(java.util.List<java.math.BigDecimal> deptidList) {
        registerDeptid(ConditionKey.CK_IN_SCOPE, deptidList);
    }
            
    /**
     * Set the value of deptid using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param deptidList The value of deptid as notInScope.
     */
    public void setDeptid_NotInScope(java.util.List<java.math.BigDecimal> deptidList) {
        registerDeptid(ConditionKey.CK_NOT_IN_SCOPE, deptidList);
    }
            
    /**
     * Set the sub-query of Deptid_InScopeSubQuery_Dept using inScopeSubQuery.
     * { in (select xxx.id from dept where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query keep the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Deptid_InScopeSubQuery_Dept using inScopeSubQuery. (NotNull)
     */
    public void setDeptid_InScopeSubQuery_Dept(DeptCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        keepDeptid_InScopeSubQuery_Dept(subQuery);// for saving query-value.
        registerInScopeSubQuery(subQuery, COL_deptid, "id", "deptid_InScopeSubQuery_Dept");
    }

    abstract public void keepDeptid_InScopeSubQuery_Dept(DeptCQ subQuery);
                                      
    /**
     * Set the value of deptid using isNull. { is null }
     */
    public void setDeptid_IsNull() {
        registerDeptid(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of deptid using isNotNull. { is not null }
     */
    public void setDeptid_IsNotNull() {
        registerDeptid(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of deptid.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptid. (Nullable)
     */
    protected void registerDeptid(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueDeptid(), COL_deptid, J_Deptid, UJ_deptid);
    }

    /**
     * Register inline condition of deptid.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptid. (Nullable)
     */
    protected void registerInlineDeptid(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueDeptid(), COL_deptid, J_Deptid, UJ_deptid);
    }

    abstract protected ConditionValue getCValueDeptid();
      
    /** Column db name of versionno. */
    protected static final String COL_versionno = "versionno";

    /** Column java name of versionno. */
    protected static final String J_Versionno = "Versionno";

    /** Column uncapitalised java name of versionno. */
    protected static final String UJ_versionno = "versionno";
            
    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param versionno The value of versionno as equal.
     */
    public void setVersionno_Equal(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param versionno The value of versionno as notEqual.
     */
    public void setVersionno_NotEqual(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_NOT_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param versionno The value of versionno as greaterThan.
     */
    public void setVersionno_GreaterThan(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_GREATER_THAN, versionno);
    }
            
    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param versionno The value of versionno as lessThan.
     */
    public void setVersionno_LessThan(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_LESS_THAN, versionno);
    }
            
    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param versionno The value of versionno as greaterEqual.
     */
    public void setVersionno_GreaterEqual(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_GREATER_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param versionno The value of versionno as lessEqual.
     */
    public void setVersionno_LessEqual(java.math.BigDecimal versionno) {
        registerVersionno(ConditionKey.CK_LESS_EQUAL, versionno);
    }
            
    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param versionno The value of versionno as equal.
     */
    public void setVersionno_Equal(long versionno) {
        registerVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
        
    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param versionno The value of versionno as notEqual.
     */
    public void setVersionno_NotEqual(long versionno) {
        registerVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param versionno The value of versionno as greaterThan.
     */
    public void setVersionno_GreaterThan(long versionno) {
        registerVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param versionno The value of versionno as lessThan.
     */
    public void setVersionno_LessThan(long versionno) {
        registerVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param versionno The value of versionno as greaterEqual.
     */
    public void setVersionno_GreaterEqual(long versionno) {
        registerVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                
    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param versionno The value of versionno as lessEqual.
     */
    public void setVersionno_LessEqual(long versionno) {
        registerVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(versionno)));
    }
                    
    /**
     * Set the value of versionno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param versionnoList The value of versionno as inScope.
     */
    public void setVersionno_InScope(java.util.List<java.math.BigDecimal> versionnoList) {
        registerVersionno(ConditionKey.CK_IN_SCOPE, versionnoList);
    }
            
    /**
     * Set the value of versionno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param versionnoList The value of versionno as notInScope.
     */
    public void setVersionno_NotInScope(java.util.List<java.math.BigDecimal> versionnoList) {
        registerVersionno(ConditionKey.CK_NOT_IN_SCOPE, versionnoList);
    }
                                                
    /**
     * Register condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     */
    protected void registerVersionno(ConditionKey key, Object value) {
        registerQuery(key, value, getCValueVersionno(), COL_versionno, J_Versionno, UJ_versionno);
    }

    /**
     * Register inline condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     */
    protected void registerInlineVersionno(ConditionKey key, Object value) {
        registerInlineQuery(key, value, getCValueVersionno(), COL_versionno, J_Versionno, UJ_versionno);
    }

    abstract protected ConditionValue getCValueVersionno();
  
    // =====================================================================================
    //                                                                 Basic-Override Method
    //                                                                 =====================
    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Clause string. (NotNull)
     */
    public String toString() {
        return getSqlClause().getClause();
    }
}
