package org.seasar.s2click.example.dao.bsentity;


import org.seasar.s2click.example.dao.allcommon.Entity;
import org.seasar.s2click.example.dao.allcommon.dbmeta.DBMeta;
import org.seasar.s2click.example.dao.bsentity.dbmeta.EmployeeDbm;


/**
 * The entity of employee.
 * 
 * <pre>
 * [primary-key]
 *     id
 * 
 * [column-property]
 *     id, empno, empname, job, manager, hiredate, salary, deptid, versionno
 * 
 * [foreign-property]
 *     dept, employeeSelf
 * 
 * [refferer-property]
 *     employeeSelfList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     id
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     Versionno
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class BsEmployee implements Entity, java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /** TABLE-Annotation for S2Dao */
    public static final String TABLE = "employee";

    
    /** VERSION_NO-Annotation */
    public static final String VERSION_NO_PROPERTY = "versionno";
    
    /** ID-Annotation */
    public static final String id_ID = "identity";

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    /** Entity modified properties. (for S2Dao) */
    protected EntityModifiedProperties _modifiedProperties = newEntityModifiedProperties();

  
    /** The value of id. */
    protected java.math.BigDecimal _id;

    /** Has the setter of id been invoked? */
    protected boolean _isSetterInvokedId;
    
    /** The value of empno. */
    protected java.math.BigDecimal _empno;

    /** Has the setter of empno been invoked? */
    protected boolean _isSetterInvokedEmpno;
    
    /** The value of empname. */
    protected String _empname;

    /** Has the setter of empname been invoked? */
    protected boolean _isSetterInvokedEmpname;
    
    /** The value of job. */
    protected String _job;

    /** Has the setter of job been invoked? */
    protected boolean _isSetterInvokedJob;
    
    /** The value of manager. */
    protected java.math.BigDecimal _manager;

    /** Has the setter of manager been invoked? */
    protected boolean _isSetterInvokedManager;
    
    /** The value of hiredate. */
    protected java.util.Date _hiredate;

    /** Has the setter of hiredate been invoked? */
    protected boolean _isSetterInvokedHiredate;
    
    /** The value of salary. */
    protected java.math.BigDecimal _salary;

    /** Has the setter of salary been invoked? */
    protected boolean _isSetterInvokedSalary;
    
    /** The value of deptid. */
    protected java.math.BigDecimal _deptid;

    /** Has the setter of deptid been invoked? */
    protected boolean _isSetterInvokedDeptid;
    
    /** The value of versionno. */
    protected java.math.BigDecimal _versionno;

    /** Has the setter of versionno been invoked? */
    protected boolean _isSetterInvokedVersionno;
  
    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public BsEmployee() {
    }

    // =====================================================================================
    //                                                                                DBMeta
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return EmployeeDbm.getInstance();
    }

    // =====================================================================================
    //                                                                            Table Name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return getDBMeta().getTableDbName();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table cap-prop-name. (NotNull)
     */
    public String getTableCapPropName() {
        return getDBMeta().getTableCapPropName();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table uncap-prop-name. (NotNull)
     */
    public String getTableUncapPropName() {
        return getDBMeta().getTableUncapPropName();
    }

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========

    /** Column-Annotation for S2Dao */
    public static final String id_COLUMN = "id";

    /**
     * Get the value of id.
     * 
     * @return The value of id. (Nullable)
     */
    public java.math.BigDecimal getId() {
        return _id;
    }
  
    /**
     * Set the value of id.
     * 
     * @param id The value of id. (Nullable)
     */
    public void setId(java.math.BigDecimal id) {
        _isSetterInvokedId = true;
        _modifiedProperties.addPropertyName("id");
        _id = id;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String empno_COLUMN = "empno";

    /**
     * Get the value of empno.
     * 
     * @return The value of empno. (Nullable)
     */
    public java.math.BigDecimal getEmpno() {
        return _empno;
    }
  
    /**
     * Set the value of empno.
     * 
     * @param empno The value of empno. (Nullable)
     */
    public void setEmpno(java.math.BigDecimal empno) {
        _isSetterInvokedEmpno = true;
        _modifiedProperties.addPropertyName("empno");
        _empno = empno;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String empname_COLUMN = "empname";

    /**
     * Get the value of empname.
     * 
     * @return The value of empname. (Nullable)
     */
    public String getEmpname() {
        return _empname;
    }
  
    /**
     * Set the value of empname.
     * 
     * @param empname The value of empname. (Nullable)
     */
    public void setEmpname(String empname) {
        _isSetterInvokedEmpname = true;
        _modifiedProperties.addPropertyName("empname");
        _empname = empname;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String job_COLUMN = "job";

    /**
     * Get the value of job.
     * 
     * @return The value of job. (Nullable)
     */
    public String getJob() {
        return _job;
    }
  
    /**
     * Set the value of job.
     * 
     * @param job The value of job. (Nullable)
     */
    public void setJob(String job) {
        _isSetterInvokedJob = true;
        _modifiedProperties.addPropertyName("job");
        _job = job;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String manager_COLUMN = "manager";

    /**
     * Get the value of manager.
     * 
     * @return The value of manager. (Nullable)
     */
    public java.math.BigDecimal getManager() {
        return _manager;
    }
  
    /**
     * Set the value of manager.
     * 
     * @param manager The value of manager. (Nullable)
     */
    public void setManager(java.math.BigDecimal manager) {
        _isSetterInvokedManager = true;
        _modifiedProperties.addPropertyName("manager");
        _manager = manager;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String hiredate_COLUMN = "hiredate";

    /**
     * Get the value of hiredate.
     * 
     * @return The value of hiredate. (Nullable)
     */
    public java.util.Date getHiredate() {
        return _hiredate;
    }
  
    /**
     * Set the value of hiredate.
     * 
     * @param hiredate The value of hiredate. (Nullable)
     */
    public void setHiredate(java.util.Date hiredate) {
        _isSetterInvokedHiredate = true;
        _modifiedProperties.addPropertyName("hiredate");
        _hiredate = hiredate;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String salary_COLUMN = "salary";

    /**
     * Get the value of salary.
     * 
     * @return The value of salary. (Nullable)
     */
    public java.math.BigDecimal getSalary() {
        return _salary;
    }
  
    /**
     * Set the value of salary.
     * 
     * @param salary The value of salary. (Nullable)
     */
    public void setSalary(java.math.BigDecimal salary) {
        _isSetterInvokedSalary = true;
        _modifiedProperties.addPropertyName("salary");
        _salary = salary;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String deptid_COLUMN = "deptid";

    /**
     * Get the value of deptid.
     * 
     * @return The value of deptid. (Nullable)
     */
    public java.math.BigDecimal getDeptid() {
        return _deptid;
    }
  
    /**
     * Set the value of deptid.
     * 
     * @param deptid The value of deptid. (Nullable)
     */
    public void setDeptid(java.math.BigDecimal deptid) {
        _isSetterInvokedDeptid = true;
        _modifiedProperties.addPropertyName("deptid");
        _deptid = deptid;
    }
  
    /** Column-Annotation for S2Dao */
    public static final String versionno_COLUMN = "versionno";

    /**
     * Get the value of versionno.
     * 
     * @return The value of versionno. (Nullable)
     */
    public java.math.BigDecimal getVersionno() {
        return _versionno;
    }
  
    /**
     * Set the value of versionno.
     * 
     * @param versionno The value of versionno. (Nullable)
     */
    public void setVersionno(java.math.BigDecimal versionno) {
        _isSetterInvokedVersionno = true;
        _modifiedProperties.addPropertyName("versionno");
        _versionno = versionno;
    }
  
    // =====================================================================================
    //                                                                Invoking Determination
    //                                                                ======================
  
    /**
     * Has the setter of id been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedId() {
        return _isSetterInvokedId;
    }
    
    /**
     * Has the setter of empno been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedEmpno() {
        return _isSetterInvokedEmpno;
    }
    
    /**
     * Has the setter of empname been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedEmpname() {
        return _isSetterInvokedEmpname;
    }
    
    /**
     * Has the setter of job been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedJob() {
        return _isSetterInvokedJob;
    }
    
    /**
     * Has the setter of manager been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedManager() {
        return _isSetterInvokedManager;
    }
    
    /**
     * Has the setter of hiredate been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedHiredate() {
        return _isSetterInvokedHiredate;
    }
    
    /**
     * Has the setter of salary been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedSalary() {
        return _isSetterInvokedSalary;
    }
    
    /**
     * Has the setter of deptid been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedDeptid() {
        return _isSetterInvokedDeptid;
    }
    
    /**
     * Has the setter of versionno been invoked?
     * 
     * @return Determination.
     * @deprecated Please use modified-properties.
     */
    public boolean isSetterInvokedVersionno() {
        return _isSetterInvokedVersionno;
    }
  
    // =====================================================================================
    //                                                                       Classify Method
    //                                                                       ===============
                  
    // =====================================================================================
    //                                                          Classification Determination
    //                                                          ============================
                  
    // =====================================================================================
    //                                                                 Classification Getter
    //                                                                 =====================
                  
    // =====================================================================================
    //                                                                         Foreign Table
    //                                                                         =============

    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [dept]
    //   ForeignProperty = [dept]
    // * * * * * * * * */

    /** RELNO of foreign table for s2dao. */
    public static final int dept_RELNO = 0;

    /** RELKEYS of foreign table for s2dao. */
    public static final String dept_RELKEYS = "deptid:id";

    /** The entity of foreign table. */
    protected org.seasar.s2click.example.dao.exentity.Dept _parentDept;

    /**
     * Get the entity of foreign table without lazyload.
     * 
     * @return The entity of foreign table.
     */
    public org.seasar.s2click.example.dao.exentity.Dept getDept() {
        return _parentDept;
    }

    /**
     * Set the entity of foreign table.
     * 
     * @param v The entity of foreign table.
     */
    public void setDept(org.seasar.s2click.example.dao.exentity.Dept v) {
        _parentDept = v;
    }

    /**
     * Has relation of dept.
     * 
     * @return Determination.
     */
    public boolean hasRelationDept() {
        return _parentDept != null && _parentDept.hasPrimaryKeyValue();
    }

  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [employee]
    //   ForeignProperty = [employeeSelf]
    // * * * * * * * * */

    /** RELNO of foreign table for s2dao. */
    public static final int employeeSelf_RELNO = 1;

    /** RELKEYS of foreign table for s2dao. */
    public static final String employeeSelf_RELKEYS = "manager:id";

    /** The entity of foreign table. */
    protected org.seasar.s2click.example.dao.exentity.Employee _parentEmployeeSelf;

    /**
     * Get the entity of foreign table without lazyload.
     * 
     * @return The entity of foreign table.
     */
    public org.seasar.s2click.example.dao.exentity.Employee getEmployeeSelf() {
        return _parentEmployeeSelf;
    }

    /**
     * Set the entity of foreign table.
     * 
     * @param v The entity of foreign table.
     */
    public void setEmployeeSelf(org.seasar.s2click.example.dao.exentity.Employee v) {
        _parentEmployeeSelf = v;
    }

    /**
     * Has relation of employeeSelf.
     * 
     * @return Determination.
     */
    public boolean hasRelationEmployeeSelf() {
        return _parentEmployeeSelf != null && _parentEmployeeSelf.hasPrimaryKeyValue();
    }

  
    // =====================================================================================
    //                                                                        Refferer Table
    //                                                                        ==============

  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ReffererTable    = [employee]
    //   ReffererProperty = [employeeSelfList]
    // * * * * * * * * */
  
    /** The list of refferer table. */
    protected java.util.List<org.seasar.s2click.example.dao.exentity.Employee> _childrenEmployeeSelfList;

    /**
     * Get the list of refferer table without lazyload.
     * If it's not loaded yet, returns null.
     * 
     * @return The list of refferer table. (Nullable)
     */
    public java.util.List<org.seasar.s2click.example.dao.exentity.Employee> getEmployeeSelfList() {
        return _childrenEmployeeSelfList;
    }

    /**
     * Set the list of refferer table.
     * 
     * @param value The list of refferer table. (Nullable)
     */
    public void setEmployeeSelfList(java.util.List<org.seasar.s2click.example.dao.exentity.Employee> value) {
        _childrenEmployeeSelfList = value;
    }
  
    // =====================================================================================
    //                                                                                Accept
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMap Primary key map. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMap(java.util.Map<String, ? extends Object> primaryKeyMap) {
        MapAssertUtil.assertPrimaryKeyMapNotNullAndNotEmpty(primaryKeyMap);
  
        MapAssertUtil.assertColumnExistingInPrimaryKeyMap(primaryKeyMap, "id");
        {
            final Object obj = primaryKeyMap.get("id");
            if (obj == null) {
                _id = null; _modifiedProperties.remove("id");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setId((java.math.BigDecimal)obj);
                } else {
                    try {
                        setId(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMapString Primary-key map-string. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMapString(String primaryKeyMapString) {
        MapStringUtil.acceptPrimaryKeyMapString(primaryKeyMapString, this);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param columnValueMap Column-value map. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMap(java.util.Map<String, ? extends Object> columnValueMap) {
        MapAssertUtil.assertColumnValueMapNotNullAndNotEmpty(columnValueMap);
  
        {
            final Object obj = columnValueMap.get("id");
            if (obj == null) {
                _id = null; _modifiedProperties.remove("id");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setId((java.math.BigDecimal)obj);
                } else {
                    try {
                        setId(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("empno");
            if (obj == null) {
                _empno = null; _modifiedProperties.remove("empno");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setEmpno((java.math.BigDecimal)obj);
                } else {
                    try {
                        setEmpno(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setEmpno(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("empname");
            if (obj == null) {
                _empname = null; _modifiedProperties.remove("empname");
            } else {
    
                checkTypeString(obj, "empname", "String");
                setEmpname((String)obj);
            }
        }
      
        {
            final Object obj = columnValueMap.get("job");
            if (obj == null) {
                _job = null; _modifiedProperties.remove("job");
            } else {
    
                checkTypeString(obj, "job", "String");
                setJob((String)obj);
            }
        }
      
        {
            final Object obj = columnValueMap.get("manager");
            if (obj == null) {
                _manager = null; _modifiedProperties.remove("manager");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setManager((java.math.BigDecimal)obj);
                } else {
                    try {
                        setManager(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setManager(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("hiredate");
            if (obj == null) {
                _hiredate = null; _modifiedProperties.remove("hiredate");
            } else {
          
                if (obj instanceof java.util.Date) {
                    setHiredate((java.util.Date)obj);
                } else {
                    setHiredate(new java.util.Date(parseDateString(obj, "hiredate", "java.util.Date")));
                }
            }
        }
            
        {
            final Object obj = columnValueMap.get("salary");
            if (obj == null) {
                _salary = null; _modifiedProperties.remove("salary");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setSalary((java.math.BigDecimal)obj);
                } else {
                    try {
                        setSalary(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setSalary(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("deptid");
            if (obj == null) {
                _deptid = null; _modifiedProperties.remove("deptid");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setDeptid((java.math.BigDecimal)obj);
                } else {
                    try {
                        setDeptid(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setDeptid(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("versionno");
            if (obj == null) {
                _versionno = null; _modifiedProperties.remove("versionno");
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setVersionno((java.math.BigDecimal)obj);
                } else {
                    try {
                        setVersionno(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setVersionno(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param columnValueMapString Column-value map-string. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMapString(String columnValueMapString) {
        MapStringUtil.acceptColumnValueMapString(columnValueMapString, this);
    }

    private void checkTypeString(Object value, String propertyName, String typeName) {
        MapStringUtil.checkTypeString(value, propertyName, typeName);
    }

    private long parseDateString(Object value, String propertyName, String typeName) {
        return MapStringUtil.parseDateString(value, propertyName, typeName);
    }

    // =====================================================================================
    //                                                                               Extract
    //                                                                               =======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString() {
        return MapStringUtil.extractPrimaryKeyMapString(this);
    }

    /**
     * Extract primary-key map-string.
     * 
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString(String startBrace, String endBrace, String delimiter, String equal) {
        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();
  
        appendColumnValueString(sb, delimiter, equal, "id", _id);
  
        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();

    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString() {
        return MapStringUtil.extractColumnValueMapString(this);
    }

    /**
     * Extract column-value map-string.
     * 
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString(String startBrace, String endBrace, String delimiter, String equal) {
        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();
        appendColumnValueString(sb, delimiter, equal, "id", _id);
        appendColumnValueString(sb, delimiter, equal, "empno", _empno);
        appendColumnValueString(sb, delimiter, equal, "empname", _empname);
        appendColumnValueString(sb, delimiter, equal, "job", _job);
        appendColumnValueString(sb, delimiter, equal, "manager", _manager);
        appendColumnValueString(sb, delimiter, equal, "hiredate", _hiredate);
        appendColumnValueString(sb, delimiter, equal, "salary", _salary);
        appendColumnValueString(sb, delimiter, equal, "deptid", _deptid);
        appendColumnValueString(sb, delimiter, equal, "versionno", _versionno);

        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();
    }

    private void appendColumnValueString(StringBuffer sb, String delimiter, String equal, String colName, Object value) {
        sb.append(delimiter).append(colName).append(equal);
        if (value instanceof java.util.Date) {
            sb.append((value != null ? formatDate((java.util.Date)value) : ""));
        } else {
            sb.append((value != null ? value.toString() : ""));
        }
    }



    protected String formatDate(java.util.Date value) {
        return MapStringUtil.formatDate(value);
    }

    // =====================================================================================
    //                                                                         Determination
    //                                                                         =============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Determination.
     */
    public boolean hasPrimaryKeyValue() {
  
        if (_id == null) {
            return false;
        }
  
        return true;
    }

    // =====================================================================================
    //                                                                   Modified Properties
    //                                                                   ===================
    public java.util.Set<String> getModifiedPropertyNames() {
        return _modifiedProperties.getPropertyNames();
    }

    protected EntityModifiedProperties newEntityModifiedProperties() {
        return new EntityModifiedProperties();
    }

    /**
     * Clear modified property names.
     */
    public void clearModifiedPropertyNames() {
        _modifiedProperties.clear();
    }

    // =====================================================================================
    //                                                                        Basic Override
    //                                                                        ==============

    /**
     * This method overrides the method that is declared at super.
     * If the primary-key of the other is same as this one, returns true.
     * 
     * @param other Other entity.
     * @return Comparing result.
     */
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (!(other instanceof BsEmployee)) {
            return false;
        }
        final BsEmployee otherEntity = (BsEmployee)other;
  
        if (getId() == null || !getId().equals(otherEntity.getId())) {
            return false;
        }
  
        return true;
    }

    /**
     * This method overrides the method that is declared at super.
     * Calculates hash-code from primary-key.
     * 
     * @return Hash-code from primary-keys.
     */
    public int hashCode() {
        int result = 0;
  
        if (this.getId() != null) {
            result = result + getId().hashCode();
        }
  
        return result;
    }

    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String toString() {
        final String delimiter = ",";
        final StringBuffer sb = new StringBuffer();

        sb.append(delimiter).append(getId());

        sb.append(delimiter).append(getEmpno());

        sb.append(delimiter).append(getEmpname());

        sb.append(delimiter).append(getJob());

        sb.append(delimiter).append(getManager());

        sb.append(delimiter).append(getHiredate());

        sb.append(delimiter).append(getSalary());

        sb.append(delimiter).append(getDeptid());

        sb.append(delimiter).append(getVersionno());

        sb.delete(0, delimiter.length());
        sb.insert(0, "{").append("}");
        return sb.toString();
    }
}
