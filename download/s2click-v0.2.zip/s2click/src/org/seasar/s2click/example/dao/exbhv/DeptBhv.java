package org.seasar.s2click.example.dao.exbhv;


/**
 * The behavior of dept.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class DeptBhv extends org.seasar.s2click.example.dao.bsbhv.BsDeptBhv {
}
