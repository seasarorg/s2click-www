package org.seasar.s2click.example.page.employee;

import java.math.BigDecimal;
import java.util.List;

import net.sf.click.control.ActionLink;
import net.sf.click.control.Column;
import net.sf.click.control.Table;
import net.sf.click.extras.control.LinkDecorator;

import org.seasar.s2click.example.dao.exbhv.EmployeeBhv;
import org.seasar.s2click.example.dao.exentity.Employee;
import org.seasar.s2click.example.dto.EmployeeSearchDto;
import org.seasar.s2click.example.page.BorderPage;

public class ListPage extends BorderPage {
	public Table table = new Table();
	private EmployeeBhv employeeBhv;
	private EmployeeSearchDto employeeSearchDto;
    public ActionLink editLink = new ActionLink("edit", "Edit", this, "onEditClick");
    public ActionLink deleteLink = new ActionLink("delete", "Delete", this, "onDeleteClick");

	public ListPage() {
		table.addColumn(new Column("id"));
		table.addColumn(new Column("empno"));
		table.addColumn(new Column("empname"));
		table.addColumn(new Column("job"));
		table.addColumn(new Column("managerName"));
        Column column = new Column("hiredate");
        column.setFormat("{0,date,medium}");
		table.addColumn(column);
        column = new Column("salary");
        column.setFormat("{0,number,#,###}");
		table.addColumn(column);
		table.addColumn(new Column("deptName"));
        column = new Column("Action");
        ActionLink[] links = new ActionLink[]{editLink, deleteLink};
        column.setDecorator(new LinkDecorator(table, links, "id"));
        table.addColumn(column);
        deleteLink.setAttribute("onclick", "return window.confirm('削除していいですか');");

	}
	public void onInit() {
		employeeSearchDto = 
			(EmployeeSearchDto) getContext().getSession().getAttribute("employeeSearchDto");
	}
	public void onRender() {
		if (employeeSearchDto!=null){
			List <Employee> employees = 
				employeeBhv.getMyDao().searchEmployeeDtoList(employeeSearchDto);
			table.setRowList(employees);
		}
	}
    public boolean onEditClick() {
        Integer id = editLink.getValueInteger();
		setRedirect(getContext().getPagePath(EditPage.class) + "?mode=edit&id="+id.toString());
        return false;
    }

    public boolean onDeleteClick() {
    	Integer id = deleteLink.getValueInteger();
    	Employee emp = employeeBhv.getMyDao().getEntity(new BigDecimal(id));
    	try {
    		employeeBhv.getMyDao().delete(emp);
		}
		catch (Exception e) {
			//TO-DO Errorの表示が必要
			//setError("Delete Error 最初からやり直して下さい");
			return true;
		}
        return true;
    }

	public void setEmployeeBhv(EmployeeBhv employeeBhv) {
		this.employeeBhv = employeeBhv;
	}
}
