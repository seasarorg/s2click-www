package org.seasar.s2click.example.dao.cbean;


/**
 * The condition-bean of dept.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class DeptCB extends org.seasar.s2click.example.dao.cbean.bs.BsDeptCB {
}
