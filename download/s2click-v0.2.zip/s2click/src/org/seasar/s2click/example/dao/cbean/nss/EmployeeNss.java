package org.seasar.s2click.example.dao.cbean.nss;


import org.seasar.s2click.example.dao.cbean.cq.EmployeeCQ;


/**
 * The nest select setupper.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class EmployeeNss {

    /** Base query. */
    protected EmployeeCQ _query;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param query Base query. (NotNull)
     */
    public EmployeeNss(EmployeeCQ query) {
        _query = query;
    }

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========
    public EmployeeCQ query() {
        return _query;
    }

    public boolean hasConditionQuery() {
        return _query != null;
    }

    // =====================================================================================
    //                                                                           SetupSelect
    //                                                                           ===========

    protected boolean _isSelectDept;
    public boolean isSelectDept() {
        return _isSelectDept;
    }
    public void withDept() {
        assertConditionQuery();
        query().queryDept();
        _isSelectDept = true;
    }

    protected boolean _isSelectEmployeeSelf;
    public boolean isSelectEmployeeSelf() {
        return _isSelectEmployeeSelf;
    }
    public void withEmployeeSelf() {
        assertConditionQuery();
        query().queryEmployeeSelf();
        _isSelectEmployeeSelf = true;
    }
  
    // =====================================================================================
    //                                                                                Helper
    //                                                                                ======
    protected void assertConditionQuery() {
        if (!hasConditionQuery()) {
            String msg = "The query should not be null.";
            throw new IllegalStateException(msg);
        }
    }
}
