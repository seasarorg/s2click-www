package org.seasar.s2click.example.page.employee;

import java.util.List;

import net.sf.click.Context;
import net.sf.click.control.Column;
import net.sf.click.control.Decorator;
import net.sf.click.control.Form;
import net.sf.click.control.Select;
import net.sf.click.control.Submit;
import net.sf.click.control.Table;
import net.sf.click.control.TextField;

import org.seasar.s2click.control.ImageDataSetParentId;
import org.seasar.s2click.example.dao.exbhv.DeptBhv;
import org.seasar.s2click.example.dao.exbhv.EmployeeBhv;
import org.seasar.s2click.example.dao.exentity.Employee;
import org.seasar.s2click.example.dto.ManagerSearchDto;
import org.seasar.s2click.example.util.CommonLogic;

public class ManagerSelectPage extends net.sf.click.Page {
	private DeptBhv deptbhv;
	private ImageDataSetParentId imgSet = new ImageDataSetParentId("img");	
	public Form form = new Form("form");
	public Table table = new Table();
	private EmployeeBhv employeeBhv;
	private Select deptid = new Select("deptid","dept");
	public ManagerSelectPage(){
		form.add(new TextField("empname","Name(一部可)"));
		form.add(deptid);
		form.add(new Submit("search","検索",this,"onSearchClicked"));
		table.addColumn(new Column("empname"));
		table.addColumn(new Column("deptName"));
		Column column = new Column("Sel");
		column.setDecorator(new Decorator() {
            public String render(Object row, Context context) {
            	Employee employee = (Employee) row;
            	imgSet.setContext(table.getContext());
            	imgSet.setData(employee.getEmpname(),employee.getId().toString());
            	return imgSet.toString();
            }
        });
        table.addColumn(column);
	}
	public void onInit(){
		CommonLogic.setDeptOptions(deptid, form, deptbhv);		
	}
	public boolean onSearchClicked(){
        if (form.isValid()) {	
        	ManagerSearchDto managerSearchDto = new ManagerSearchDto();
        	form.copyTo(managerSearchDto);
			List <Employee> employees = 
				employeeBhv.getMyDao().searchManagerList(managerSearchDto);
			table.setRowList(employees);
        	return false;
        }
        return true;
	}
	
	public void setEmployeeBhv(EmployeeBhv employeeBhv) {
		this.employeeBhv = employeeBhv;
	}
	public void setDeptbhv(DeptBhv deptbhv) {
		this.deptbhv = deptbhv;
	}
}