
/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.s2click.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.click.ClickServlet;
import net.sf.click.Page;
import net.sf.click.util.ClickLogger;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;

/**
 * @author shimura
 *
 */
public class S2ClickServlet extends ClickServlet {
	private static final long serialVersionUID = 1L;
	private S2Container s2Container;


    /**
     * @see net.sf.click.ClickServlet#init()
     */
    public void init() throws ServletException {
        super.init();
        s2Container = SingletonS2ContainerFactory.getContainer(); 

    }

    /**
     * @see net.sf.click.ClickServlet#newPageInstance(java.lang.String, java.lang.Class, javax.servlet.http.HttpServletRequest)
     */
    protected Page newPageInstance(String path, Class pageClass,
            HttpServletRequest request) throws Exception {
        Page page = null;
        page = (Page)s2Container.getComponent(pageClass);  
        return page;
    }
	/**
	 * @param request
	 * @param response
	 */
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {

        ClickLogger.setInstance(logger);

        ensureAppInitialized();

        if (ifAuthorizedReloadRequest(request)) {
            reloadClickApp(request, response);

        } else {
            handleRequest(request, response, false);
        }
    }
}
