AJS={BASE_URL:"",drag_obj:null,drag_elm:null,_drop_zones:[],_cur_pos:null,_unloadListeners:function(){
if(AJS.listeners){
AJS.map(AJS.listeners,function(_1,_2,fn){
AJS.removeEventListener(_1,_2,fn);
});
}
AJS.listeners=[];
},setLeft:function(){
var _4=AJS.flattenList(arguments);
var l=_4.pop();
AJS.map(_4,function(_6){
_6.style.left=AJS.getCssDim(l);
});
},getScrollTop:function(){
var t;
if(document.documentElement&&document.documentElement.scrollTop){
t=document.documentElement.scrollTop;
}else{
if(document.body){
t=document.body.scrollTop;
}
}
return t;
},preventDefault:function(e){
if(AJS.isIe()){
window.event.returnValue=false;
}else{
e.preventDefault();
}
},isArray:function(_9){
return _9 instanceof Array;
},removeElement:function(){
var _a=AJS.flattenList(arguments);
AJS.map(_a,function(_b){
AJS.swapDOM(_b,null);
});
},isDict:function(o){
var _d=String(o);
return _d.indexOf(" Object")!=-1;
},isString:function(_e){
return (typeof _e=="string");
},getIndex:function(_f,_10,_11){
for(var i=0;i<_10.length;i++){
if(_11&&_11(_10[i])||_f==_10[i]){
return i;
}
}
return -1;
},createDOM:function(_13,_14){
var i=0,_16;
elm=document.createElement(_13);
if(AJS.isDict(_14[i])){
for(k in _14[0]){
_16=_14[0][k];
if(k=="style"){
elm.style.cssText=_16;
}else{
if(k=="class"||k=="className"){
elm.className=_16;
}else{
elm.setAttribute(k,_16);
}
}
}
i++;
}
if(_14[0]==null){
i=1;
}
AJS.map(_14,function(n){
if(n){
if(AJS.isString(n)||AJS.isNumber(n)){
n=AJS.TN(n);
}
elm.appendChild(n);
}
},i);
return elm;
},isIe:function(){
return (navigator.userAgent.toLowerCase().indexOf("msie")!=-1&&navigator.userAgent.toLowerCase().indexOf("opera")==-1);
},addEventListener:function(elm,_19,fn,_1b,_1c){
if(!_1c){
_1c=false;
}
var _1d=AJS.$A(elm);
AJS.map(_1d,function(_1e){
if(_1b){
fn=AJS._listenOnce(_1e,_19,fn);
}
if(AJS.isIn(_19,["submit","load","scroll","resize"])){
var old=elm["on"+_19];
elm["on"+_19]=function(){
if(old){
fn(arguments);
return old(arguments);
}else{
return fn(arguments);
}
};
return;
}
if(AJS.isIn(_19,["keypress","keydown","keyup"])){
var _20=fn;
fn=function(e){
e.key=e.keyCode?e.keyCode:e.charCode;
switch(e.key){
case 63232:
e.key=38;
break;
case 63233:
e.key=40;
break;
case 63235:
e.key=39;
break;
case 63234:
e.key=37;
break;
}
return _20.apply(null,arguments);
};
}
if(_1e.attachEvent){
_1e.attachEvent("on"+_19,fn);
}else{
if(_1e.addEventListener){
_1e.addEventListener(_19,fn,_1c);
}
}
AJS.listeners=AJS.$A(AJS.listeners);
AJS.listeners.push([_1e,_19,fn]);
});
},getElement:function(id){
if(AJS.isString(id)||AJS.isNumber(id)){
return document.getElementById(id);
}else{
return id;
}
},addClass:function(){
var _23=AJS.flattenList(arguments);
var cls=_23.pop();
var _25=function(o){
if(!new RegExp("(^|\\s)"+cls+"(\\s|$)").test(o.className)){
o.className+=(o.className?" ":"")+cls;
}
};
AJS.map(_23,function(elm){
_25(elm);
});
},setWidth:function(){
var _28=AJS.flattenList(arguments);
var w=_28.pop();
AJS.map(_28,function(elm){
elm.style.width=AJS.getCssDim(w);
});
},swapDOM:function(_2b,src){
_2b=AJS.getElement(_2b);
var _2d=_2b.parentNode;
if(src){
src=AJS.getElement(src);
_2d.replaceChild(src,_2b);
}else{
_2d.removeChild(_2b);
}
return src;
},setHeight:function(){
var _2e=AJS.flattenList(arguments);
var h=_2e.pop();
AJS.map(_2e,function(elm){
elm.style.height=AJS.getCssDim(h);
});
},bindMethods:function(_31){
for(var k in _31){
var _33=_31[k];
if(typeof (_33)=="function"){
_31[k]=AJS.$b(_33,_31);
}
}
},getElementsByTagAndClassName:function(_34,_35,_36){
var _37=[];
if(!AJS.isDefined(_36)){
_36=document;
}
if(!AJS.isDefined(_34)){
_34="*";
}
var els=_36.getElementsByTagName(_34);
var _39=els.length;
var _3a=new RegExp("(^|\\s)"+_35+"(\\s|$)");
for(i=0,j=0;i<_39;i++){
if(_3a.test(els[i].className)||_35==null){
_37[j]=els[i];
j++;
}
}
return _37;
},setHTML:function(elm,_3c){
elm.innerHTML=_3c;
return elm;
},map:function(_3d,fn,_3f,_40){
var i=0,l=_3d.length;
if(_3f){
i=_3f;
}
if(_40){
l=_40;
}
for(i;i<l;i++){
fn.apply(null,[_3d[i],i]);
}
},isOpera:function(){
return (navigator.userAgent.toLowerCase().indexOf("opera")!=-1);
},isMozilla:function(){
return (navigator.userAgent.toLowerCase().indexOf("gecko")!=-1&&navigator.productSub>=20030210);
},getBody:function(){
return AJS.$bytc("body")[0];
},removeClass:function(){
var _43=AJS.flattenList(arguments);
var cls=_43.pop();
var _45=function(o){
o.className=o.className.replace(new RegExp("\\s?"+cls),"");
};
AJS.map(_43,function(elm){
_45(elm);
});
},getWindowSize:function(){
var _48,_49;
if(self.innerHeight){
_48=self.innerWidth;
_49=self.innerHeight;
}else{
if(document.documentElement&&document.documentElement.clientHeight){
_48=document.documentElement.clientWidth;
_49=document.documentElement.clientHeight;
}else{
if(document.body){
_48=document.body.clientWidth;
_49=document.body.clientHeight;
}
}
}
return {"w":_48,"h":_49};
},showElement:function(){
var _4a=AJS.flattenList(arguments);
AJS.map(_4a,function(elm){
elm.style.display="";
});
},removeEventListener:function(elm,_4d,fn,_4f){
if(!_4f){
_4f=false;
}
if(elm.removeEventListener){
elm.removeEventListener(_4d,fn,_4f);
if(AJS.isOpera()){
elm.removeEventListener(_4d,fn,!_4f);
}
}else{
if(elm.detachEvent){
elm.detachEvent("on"+_4d,fn);
}
}
},_getRealScope:function(fn,_51,_52,_53){
var _54=window;
_51=AJS.$A(_51);
if(fn._cscope){
_54=fn._cscope;
}
return function(){
var _55=[];
var i=0;
if(_52){
i=1;
}
AJS.map(arguments,function(arg){
_55.push(arg);
},i);
_55=_55.concat(_51);
if(_53){
_55=_55.reverse();
}
return fn.apply(_54,_55);
};
},setTop:function(){
var _58=AJS.flattenList(arguments);
var t=_58.pop();
AJS.map(_58,function(elm){
elm.style.top=AJS.getCssDim(t);
});
},isNumber:function(obj){
return (typeof obj=="number");
},bind:function(fn,_5d,_5e,_5f,_60){
fn._cscope=_5d;
return AJS._getRealScope(fn,_5e,_5f,_60);
},log:function(o){
if(AJS.isMozilla()){
console.log(o);
}else{
var div=AJS.DIV({"style":"color: green"});
AJS.ACN(AJS.getBody(),AJS.setHTML(div,""+o));
}
},appendChildNodes:function(elm){
if(arguments.length>=2){
AJS.map(arguments,function(n){
if(AJS.isString(n)){
n=AJS.TN(n);
}
if(AJS.isDefined(n)){
elm.appendChild(n);
}
},1);
}
return elm;
},isDefined:function(o){
return (o!="undefined"&&o!=null);
},insertBefore:function(elm,_67){
_67.parentNode.insertBefore(elm,_67);
return elm;
},isIn:function(elm,_69){
var i=AJS.getIndex(elm,_69);
if(i!=-1){
return true;
}else{
return false;
}
},hideElement:function(elm){
var _6c=AJS.flattenList(arguments);
AJS.map(_6c,function(elm){
elm.style.display="none";
});
},createArray:function(v){
if(AJS.isArray(v)&&!AJS.isString(v)){
return v;
}else{
if(!v){
return [];
}else{
return [v];
}
}
},getCssDim:function(dim){
if(AJS.isString(dim)){
return dim;
}else{
return dim+"px";
}
},_listenOnce:function(elm,_71,fn){
var _73=function(){
AJS.removeEventListener(elm,_71,_73);
fn(arguments);
};
return _73;
},flattenList:function(_74){
var r=[];
var _76=function(r,l){
AJS.map(l,function(o){
if(AJS.isArray(o)){
_76(r,o);
}else{
r.push(o);
}
});
};
_76(r,_74);
return r;
},_createDomShortcuts:function(){
var _7a=["ul","li","td","tr","th","tbody","table","input","span","b","a","div","img","button","h1","h2","h3","br","textarea","form","p","select","option","iframe","script","center","dl","dt","dd","small","pre"];
var _7b=function(elm){
var _7d="return AJS.createDOM.apply(null, ['"+elm+"', arguments]);";
var _7e="function() { "+_7d+"  }";
eval("AJS."+elm.toUpperCase()+"="+_7e);
};
AJS.map(_7a,_7b);
AJS.TN=function(_7f){
return document.createTextNode(_7f);
};
}};
AJS.$=AJS.getElement;
AJS.$$=AJS.getElements;
AJS.$f=AJS.getFormElement;
AJS.$b=AJS.bind;
AJS.$A=AJS.createArray;
AJS.DI=AJS.documentInsert;
AJS.ACN=AJS.appendChildNodes;
AJS.RCN=AJS.replaceChildNodes;
AJS.AEV=AJS.addEventListener;
AJS.REV=AJS.removeEventListener;
AJS.$bytc=AJS.getElementsByTagAndClassName;
AJS.addEventListener(window,"unload",AJS._unloadListeners);
AJS._createDomShortcuts();
script_loaded=true;

