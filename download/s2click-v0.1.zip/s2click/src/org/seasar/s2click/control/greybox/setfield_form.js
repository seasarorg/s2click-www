var GP_P = parent.parent; 
function S2C_SET(data){
	GP_P.S2C_SET(data);
	GP_P.GB_hide(); 
}
function S2C_ID_SET(data,id){
	GP_P.S2C_ID_SET(data,id);
	GP_P.GB_hide(); 
}

