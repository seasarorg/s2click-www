GB_showFullScreenSet=function(_1,_2,_3){
var _4=new GreyBox.Sets(_1,_3);
_4.GB.setFullScreen(true);
_4.GB.setType("page");
_4.show(_2-1);
return false;
};
GB_showImageSet=function(_5,_6,_7){
var _8=new GreyBox.Sets(_5,_7);
_8.GB.setCenterWindow(true);
_8.GB.setFullScreen(false);
_8.GB.setType("image");
_8.show(_6-1);
return false;
};
GreyBox.Sets=function(_9,_a){
GB_ONLY_ONE=null;
GB_initOneIfNeeded();
this.GB=GB_ONLY_ONE;
this.callback_fn=_a;
this.current_set=_9;
AJS.bindMethods(this);
};
GreyBox.Sets.prototype={show:function(_b){
this.current_index=_b;
var _c=this.current_set[this.current_index];
this.GB.setCallback(this.callback_fn);
this.GB.show(_c.caption,_c.url);
this.btn_prev=this.GB.createNavButton("Previous",this.GB.img_dir+"prev.gif",this.switchPrev,this.checkPrev);
this.btn_next=this.GB.createNavButton("Next",this.GB.img_dir+"next.gif",this.switchNext,this.checkNext);
AJS.insertBefore(this.btn_next,this.GB.nav_bar.childNodes[0]);
AJS.insertBefore(this.btn_prev,this.GB.nav_bar.childNodes[0]);
GB_STATUS=AJS.SPAN({"class":"GB_navStatus"});
this.updateStatus();
AJS.insertBefore(GB_STATUS,this.GB.nav_bar.childNodes[0]);
},updateStatus:function(){
AJS.setHTML(GB_STATUS,(this.current_index+1)+" out of "+this.current_set.length);
if(this.current_index==0){
AJS.addClass(this.btn_prev,"GB_navDisabled");
AJS.removeClass(AJS.$bytc("span",null,this.btn_prev)[0],"GB_navOver");
}else{
AJS.removeClass(this.btn_prev,"GB_navDisabled");
}
if(this.current_index==this.current_set.length-1){
AJS.addClass(this.btn_next,"GB_navDisabled");
AJS.removeClass(AJS.$bytc("span",null,this.btn_next)[0],"GB_navOver");
}else{
AJS.removeClass(this.btn_next,"GB_navDisabled");
}
},updateFrame:function(){
var _d=this.current_set[this.current_index];
GB_ONLY_ONE.caption=_d.caption;
AJS.setHTML(GB_ONLY_ONE.div_caption,_d.caption);
GB_ONLY_ONE.url=_d.url;
GB_ONLY_ONE.destroyIframe();
GB_ONLY_ONE.initIframe();
GB_ONLY_ONE.startLoading();
},switchPrev:function(){
this.current_index--;
this.updateFrame();
this.updateStatus();
},switchNext:function(){
this.current_index++;
this.updateFrame();
this.updateStatus();
},checkPrev:function(){
return this.current_index!=0;
},checkNext:function(){
return this.current_index!=this.current_set.length-1;
}};
script_loaded=true;

