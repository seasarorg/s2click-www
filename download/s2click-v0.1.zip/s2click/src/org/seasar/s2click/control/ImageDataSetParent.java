package org.seasar.s2click.control;

import java.text.MessageFormat;

import javax.servlet.ServletContext;

import net.sf.click.util.ClickUtils;

public class ImageDataSetParent extends Image {
    protected static final String HTML_IMPORTS =
       "<script type=\"text/javascript\" src=\"{0}/click/greybox/setfield_form.js\"></script>\n";
    protected static final String[] GREYBOX_RESOURCES =
    {"setfield_form.js"  	
    };
    public ImageDataSetParent() {
     }
    public ImageDataSetParent(String name) {
    	super(name,null);
    }
    public ImageDataSetParent(String name, String src) {
    	super(name,src);
    }
	public ImageDataSetParent(String name, String label, String src){
		super(name, label, src);
	}
	public void setData(String data){
		setAttribute("onclick", "S2C_SET('"+data+ "')");
	}
	public String toString(){
		String renderString = "";
		if (super.getSrc()==null){
			String path = getContext().getRequest().getContextPath();
			super.setSrc(path+
					"/click/greybox/edit-button.gif");
		}
		if (this.getForm()==null &&  this.context.getRequest().getAttribute("__S2_setfield_form") == null){
//	        String[] args = {
//	                getContext().getRequest().getContextPath()
//	            };
//
//	        renderString = MessageFormat.format(HTML_IMPORTS, args);
			renderString = getHtmlImports();
			this.context.getRequest().setAttribute("__S2_setfield_form","rendered");
		}
		return renderString + super.toString();
	}
    public void onDeploy(ServletContext servletContext) {
        // Deploy DateField resources files
        for (int i = 0; i < GREYBOX_RESOURCES.length; i++) {
            String greyboxFilename = GREYBOX_RESOURCES[i];
            String greyboxResource =
                "/org/seasar/s2click/control/greybox/" + greyboxFilename;

            ClickUtils.deployFile(servletContext,
                                  greyboxResource,
                                  "click/greybox");
        }
    }
    public String getHtmlImports() {
        String[] args = {
            getContext().getRequest().getContextPath()
        };

        return MessageFormat.format(HTML_IMPORTS, args);
    }
}
