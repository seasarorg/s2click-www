package org.seasar.s2click.control;

import net.sf.click.control.Field;
import net.sf.click.util.HtmlStringBuffer;

public class TextAndHidden extends Field {
	public TextAndHidden(){
	}
	public TextAndHidden(String name, String value){
		super(name);
		this.setValue(value);
	}
	public TextAndHidden(String name){
		super(name);
	}
	public String getType(){
		return "textAndHidden";
	}
	public String toString(){

        HtmlStringBuffer buffer = new HtmlStringBuffer(96);
        buffer.elementStart("input");
        buffer.appendAttribute("type", "hidden");
        buffer.appendAttribute("name", getName());
        buffer.appendAttribute("id", getId());
        buffer.appendAttribute("value", getValue());
        buffer.elementEnd();
		String output = buffer.toString();      
		buffer = new HtmlStringBuffer(48);
        buffer.elementStart("span");
        if (hasAttributes()) {
            buffer.appendAttributes(getAttributes());
        }
        buffer.closeTag();
		buffer.append(getValue());
		buffer.elementEnd("span");
		return output + buffer.toString();
	}
}
