package org.seasar.s2click.control;

import java.text.MessageFormat;

import javax.servlet.ServletContext;

import net.sf.click.control.Field;
import net.sf.click.util.ClickUtils;
import net.sf.click.util.HtmlStringBuffer;

public class Image extends Field {

    public Image(){
    	
    }
 
    public Image(String name, String src){
		setName(name);
		setLabel("");
		setSrc(src);
	}
	public Image(String name, String label, String src){
		setName(name);
		setLabel(label);
		setSrc(src);
	}
    public void setSrc(String src) {
        setAttribute("src", src);
    }
    
    public String getSrc() {
    	return (String)getAttribute("src");
    }
	public String getType(){
		return "image";
	}
	public String toString(){
        HtmlStringBuffer buffer = new HtmlStringBuffer(40);

        buffer.elementStart("img");
        buffer.appendAttribute("name", getName());
        buffer.appendAttribute("id", getId());
        if (hasAttributes()) {
            buffer.appendAttributes(getAttributes());
        }
        buffer.elementEnd();
        return buffer.toString();	
	}


}
