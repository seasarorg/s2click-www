package org.seasar.s2click.control;

import java.text.SimpleDateFormat;

import net.sf.click.extras.control.DateField;

public class DateFieldYYMMDD extends DateField {
 /**
  * 
  */
 private static final long serialVersionUID = 1L;
	public DateFieldYYMMDD(){
		super();
		setYYMMDD();
	}
	public DateFieldYYMMDD(String name){
		super(name);
		setYYMMDD();
	}
	public DateFieldYYMMDD(String name, boolean required){
		super(name, required);
		setYYMMDD();
	}
	public DateFieldYYMMDD(String name, String label){ 
		super(name, label);
		setYYMMDD();
	}
	public DateFieldYYMMDD(String name, String label, boolean required){
		super(name, label, required); 
		setYYMMDD();
	}
	private void setYYMMDD(){
		dateFormat=new SimpleDateFormat("yy/MM/dd");				  
		super.setFormatPattern("yy/MM/dd");	 
	}

}


