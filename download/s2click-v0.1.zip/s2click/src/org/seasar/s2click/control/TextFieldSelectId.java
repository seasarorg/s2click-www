package org.seasar.s2click.control;

import net.sf.click.control.Field;

public class TextFieldSelectId extends TextFieldSelect {
	private Field idField;
	public TextFieldSelectId(){
		
	}
	TextFieldSelectId(String name, boolean required){
		super(name, required);
		this.readonly = true;
	}
    public TextFieldSelectId(String name, String label) {
        super(name, label);
		this.readonly = true;
    }
    public TextFieldSelectId(String name, String label, boolean required) {
        super(name, label,required);
		this.readonly = true;
    }
    public TextFieldSelectId(String name, String label, int size) {
        super(name, label, size);
		this.readonly = true;
    }
	public Field getIdField() {
		return idField;
	}
	public void setIdField(Field idField) {
		this.idField = idField;
	}
	public void setSelectPage(String windowTitle, String path)
	{
		if (idField==null) {
			throw new RuntimeException("ID Field Not Set");
		}
		image.setAttribute("onclick","S2C_ID_SHOW_URL('"+getId()+"','"+idField.getId()+"','"+"windowTitle"+"','"+ path + "')");
	}
}
