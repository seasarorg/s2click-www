package org.seasar.s2click.control;

import net.sf.click.control.Field;
import net.sf.click.util.HtmlStringBuffer;

public class Text extends Field {
	private static final long serialVersionUID = 1L;
	private String paraValue;
	public Text(){
		
	}
	public Text(String name, String paragraph){
		setName(name);
		setString(paragraph);
		setLabel("");
	}
	public Text(String name, String paragraph, String label){
		setName(name);
		setString(paragraph);
		setLabel(label);
	}
	public String getType(){
		return "paragraph";
	}
	public String toString(){
		HtmlStringBuffer buffer = new HtmlStringBuffer(48);
        buffer.elementStart("span");
        if (hasAttributes()) {
            buffer.appendAttributes(getAttributes());
        }
        buffer.closeTag();
		buffer.append(getString());
		buffer.elementEnd("span");

		return buffer.toString();
	}
	public void setString(String s) {
		paraValue = s;
	}
	public String getString(){
		return paraValue;
	}

}
