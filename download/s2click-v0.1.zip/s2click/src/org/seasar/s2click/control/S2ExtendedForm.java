package org.seasar.s2click.control;

import java.util.HashMap;
import java.util.Map;

import net.sf.click.control.Field;
import net.sf.click.control.FieldSet;
import net.sf.click.control.Form;
import net.sf.click.control.Label;
import net.sf.click.util.HtmlStringBuffer;

public class S2ExtendedForm extends Form {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected final Map fieldColSpan = new HashMap();  
	public void add(Field field,int colSpan){
		 super.add(field);
		 fieldColSpan.put(field.getName(),new Integer(colSpan));
	 }
    protected void renderFields(HtmlStringBuffer buffer) {
        if (getFieldList().size() == 1
            && getFields().containsKey("form_name")) {
            return;
        }

        buffer.append("<tr><td>\n");
        buffer.append("<table class=\"fields\" id=\"");
        buffer.append(getId());
        buffer.append("-fields\">\n");

        int column = 1;
        int colSpan = 1;

        for (int i = 0, size = getFieldList().size(); i < size; i++) {

            Field field = (Field) getFieldList().get(i);
            colSpan = 1;
            if (fieldColSpan.containsKey(field.getName())) {
            	colSpan = (Integer)(fieldColSpan.get(field.getName()));
            }
            if (!field.isHidden()) {

                if (column == 1) {
                    buffer.append("<tr class=\"fields\">\n");
                }

                if (field instanceof FieldSet) {
                    buffer.append("<td class=\"fields\" colspan=\""
                    		+String.valueOf(2 * colSpan)+ "\">\n");
                    buffer.append(field);
                    buffer.append("</td>\n");

                } else if (field instanceof Label) {
                    buffer.append("<td class=\"fields\" colspan=\""
                    		+String.valueOf(2 * colSpan)
                    		+"\" align=\"");
                    buffer.append(getLabelAlign());
                    buffer.append("\"");
                    if (field.hasAttributes()) {
                        buffer.appendAttributes(field.getAttributes());
                    }
                    buffer.append(">");
                    buffer.append(field);
                    buffer.append("</td>\n");

                } else {
                    // Write out label
                    if (POSITION_LEFT.equals(getLabelsPosition())) {
                        buffer.append("<td class=\"fields\"");
                        if (colSpan > 1) {
                        	buffer.appendAttribute("colspan",
                        			String.valueOf(colSpan));
                        }
                        buffer.appendAttribute("align", getLabelAlign());
                        buffer.appendAttribute("style", getLabelStyle());
                        buffer.append(">");
                    } else {
                        buffer.append("<td class=\"fields\" valign=\"top\"");
                        if (colSpan > 1) {
                        	buffer.appendAttribute("colspan",
                        			String.valueOf(colSpan));
                        }
                        buffer.appendAttribute("style", getLabelStyle());
                        buffer.append(">");
                    }

                    if (field.isRequired()) {
                        buffer.append(getLabelRequiredPrefix());
                    }
                    buffer.append("<label");
                    if (field.isDisabled()) {
                        buffer.append(" disabled=\"disabled\"");
                    }
                    if (field.getError() != null) {
                        buffer.append(" class=\"error\"");
                    }
                    buffer.append(">");
                    buffer.append(field.getLabel());
                    buffer.append("</label>");
                    if (field.isRequired()) {
                        buffer.append(getLabelRequiredSuffix());
                    }

                    if (POSITION_LEFT.equals(getLabelsPosition())) {
                        buffer.append("</td>\n");
                        buffer.append("<td align=\"left\"");
                        if (colSpan > 1) {
                        	buffer.appendAttribute("colspan",
                        			String.valueOf(colSpan));
                        }
                        buffer.appendAttribute("style", getFieldStyle());
                        buffer.append(">");
                    } else {
                        buffer.append("<br>");
                    }

                    // Write out field
                    buffer.append(field);
                    buffer.append("</td>\n");
                }

                if (column + colSpan> getColumns()) {
                    buffer.append("</tr>\n");
                    column = 1;

                } else if (field instanceof FieldSet) {
                    buffer.append("</tr>\n");
                    column+=colSpan;

                } else {
                	column+=colSpan;
                }
            }

        }
        buffer.append("</table>\n");
        buffer.append("</td></tr>\n");
    }

}
