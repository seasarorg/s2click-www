package org.seasar.s2click.control;

public class ButtonDataSetParentId extends ButtonDataSetParent {
    public ButtonDataSetParentId() {
    }
    public ButtonDataSetParentId(String name) {
        super(name);
    }
    public ButtonDataSetParentId(String name, String label) {
    	super(name, label);
    }
	public void setData(String data, String id){
		setAttribute("onclick", "S2C_ID_SET('"+data+ "','"+id+"')");
	}
}
