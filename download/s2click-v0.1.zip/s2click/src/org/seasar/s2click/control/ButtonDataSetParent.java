package org.seasar.s2click.control;

import java.text.MessageFormat;

import javax.servlet.ServletContext;

import net.sf.click.control.Button;
import net.sf.click.util.ClickUtils;

public class ButtonDataSetParent extends Button {
    protected static final String HTML_IMPORTS =
        "<script type=\"text/javascript\" src=\"{0}/click/greybox/setfield_form.js\"></script>\n";
//     protected static final String[] GREYBOX_RESOURCES =
//     {"setfield_form.js"  	
//     };
    public ButtonDataSetParent() {
    }
    public ButtonDataSetParent(String name) {
        super(name);
    }
    public ButtonDataSetParent(String name, String label) {
    	super(name, label);
    }
	public void setData(String data){
		setAttribute("onclick", "S2C_SET('"+data+ "')");
	}
	
	public String toString(){
		String renderString = "";
		if (this.getForm()==null &&  this.context.getRequest().getAttribute("__S2_setfield_form") == null){
			renderString = getHtmlImports();
			this.context.getRequest().setAttribute("__S2_setfield_form","rendered");
		}
		return renderString + super.toString();
	}
//    public void onDeploy(ServletContext servletContext) {
//        // Deploy DateField resources files
//        for (int i = 0; i < GREYBOX_RESOURCES.length; i++) {
//            String greyboxFilename = GREYBOX_RESOURCES[i];
//            String greyboxResource =
//                "/org/seasar/s2click/control/greybox/" + greyboxFilename;
//
//            ClickUtils.deployFile(servletContext,
//                                  greyboxResource,
//                                  "click/greybox");
//        }
//    }
    public String getHtmlImports() {
        String[] args = {
            getContext().getRequest().getContextPath()
        };

        return MessageFormat.format(HTML_IMPORTS, args);
    }
}
