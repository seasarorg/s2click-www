package org.seasar.s2click.control;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.MessageFormat;
import java.util.Enumeration;

import javax.servlet.ServletContext;

import net.sf.click.Context;
import net.sf.click.control.TextField;
import net.sf.click.util.ClickUtils;
import net.sf.click.util.HtmlStringBuffer;
import org.seasar.s2click.util.*;
public class TextFieldSelect extends TextField {
    protected static final String HTML_IMPORTS =
        "<link type=\"text/css\" rel=\"stylesheet\" href=\"{0}/click/greybox/greybox.css\"/>\n"
        + "<script type=\"text/javascript\" src=\"{0}/click/greybox/AJS_compressed.js\"></script>\n"
        + "<script type=\"text/javascript\" src=\"{0}/click/greybox/greybox_compressed.js\"></script>\n"
        + "<script type=\"text/javascript\" src=\"{0}/click/greybox/setfields.js\"></script>\n";
    protected static final String[] GREYBOX_RESOURCES =
    { "AJS_compressed.js", "blank.gif", "blank.html", "close.gif",
      "greybox_compressed.js", "greybox_nav_compressed.js", "greybox.css",
      "header_bg.gif", "indicator.gif", "loader_frame.html", 
      "next.gif", "overlay_dark.png", "overlay_light.png", "prev.gif",
      "edit-button.gif"};
	protected Image image = new Image();
	public TextFieldSelect(){
		
	}
	TextFieldSelect(String name, boolean required){
		super(name, required);
	}
    public TextFieldSelect(String name, String label) {
        super(name, label);
    }
    public TextFieldSelect(String name, String label, boolean required) {
        super(name, label,required);
    }
    public TextFieldSelect(String name, String label, int size) {
        super(name, label, size);
    }

	public void setImageSrc(String src) {
		 image.setSrc(src);
	}
	public void setSelectPage(String windowTitle, String path)
	{
		image.setAttribute("onclick","S2C_SHOW_URL('"+getId()+"','"+"windowTitle"+"','"+ path + "')");
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		Utility.copyGrayboxJs(getForm().getContext());
		return super.toString() + imageToString();

	}
	private String imageToString(){
		if (image.getName()==null){
			image.setName(getName()+"_s2img");
		}
		if (image.getSrc() == null){
			image.setSrc(getContext().getRequest().getContextPath()+
					"/click/greybox/edit-button.gif");
		}
		return image.toString();
	
	}


    public void onDeploy(ServletContext servletContext) {
        // Deploy DateField resources files
        for (int i = 0; i < GREYBOX_RESOURCES.length; i++) {
            String greyboxFilename = GREYBOX_RESOURCES[i];
            String greyboxResource =
                "/org/seasar/s2click/control/greybox/" + greyboxFilename;

            ClickUtils.deployFile(servletContext,
                                  greyboxResource,
                                  "click/greybox");
        }
        Utility.removeGrayboxJs(servletContext);    
    }
    public String getHtmlImports() {
        String[] args = {
            getContext().getRequest().getContextPath()
        };
        return MessageFormat.format(HTML_IMPORTS, args);
    }
}
