package org.seasar.s2click.control;

import java.text.SimpleDateFormat;

import net.sf.click.extras.control.DateField;

public class DateFieldYYYYMMDD extends DateField {
 /**
  * 
  */
 private static final long serialVersionUID = 1L;
	public DateFieldYYYYMMDD(){
		super();
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name){
		super(name);
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name, boolean required){
		super(name, required);
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name, String label){ 
		super(name, label);
		setYYYYMMDD();
	}
	public DateFieldYYYYMMDD(String name, String label, boolean required){
		super(name, label, required); 
		setYYYYMMDD();
	}
	private void setYYYYMMDD(){
		dateFormat=new SimpleDateFormat("yyyy/MM/dd");				  
		super.setFormatPattern("yyyy/MM/dd");	 
	}
	public void validate() {
        super.validate();
   		String s = getValue();
    		
		int pos = s.indexOf("/");
		if (pos!=-1 && pos !=4){
			String s2 = getFormatPattern(); 
			Object[] args = new Object[] {
                    getErrorLabel(), formatPattern
                };
        	setError(getMessage("date-format-error", args));
        	return;
		}		
	

	}

}


