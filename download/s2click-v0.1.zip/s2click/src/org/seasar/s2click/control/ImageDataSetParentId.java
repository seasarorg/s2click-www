package org.seasar.s2click.control;

public class ImageDataSetParentId extends ImageDataSetParent {
    public ImageDataSetParentId() {
    }
   public ImageDataSetParentId(String name) {
   	super(name);
   }
   public ImageDataSetParentId(String name, String src) {
   	super(name,src);
   }
	public ImageDataSetParentId(String name, String label, String src){
		super(name, label, src);
	}
	public void setData(String data, String id){
		setAttribute("onclick", "S2C_ID_SET('"+data+ "','"+id+"')");
	}
}
