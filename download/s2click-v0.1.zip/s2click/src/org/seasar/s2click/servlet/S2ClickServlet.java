
package org.seasar.s2click.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;

import net.sf.click.ClickServlet;
import net.sf.click.Control;
import net.sf.click.Page;
import net.sf.click.util.ClickLogger;




public class S2ClickServlet extends ClickServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private S2Container s2Container;
    public void init() throws ServletException {
        super.init();

    }

    protected Page newPageInstance(String path, Class pageClass,
            HttpServletRequest request) throws Exception {

        Page page = null;
        if (s2Container==null)
        {
            s2Container = SingletonS2ContainerFactory.getContainer();     	
        }
        page = (Page)s2Container.getComponent(pageClass);  

        return page;
    }
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {

        ClickLogger.setInstance(logger);

        ensureAppInitialized();

        if (ifAuthorizedReloadRequest(request)) {
            reloadClickApp(request, response);

        } else {
            handleRequest(request, response, false);
        }
    }
}
