package org.seasar.s2click.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.seasar.framework.container.ArgDef;
import org.seasar.framework.container.AspectDef;
import org.seasar.framework.container.ComponentDef;
import org.seasar.framework.container.DestroyMethodDef;
import org.seasar.framework.container.InitMethodDef;
import org.seasar.framework.container.PropertyDef;
import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.servlet.S2ContainerServlet;

public class CopyOfModS2ContainerServlet extends S2ContainerServlet {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    public static final String COMPONENT = "component";
@Override
public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	// TODO Auto-generated method stub
	super.doGet(request, response);
    String command = request.getParameter(COMMAND);
    if (command != null && COMPONENT.equalsIgnoreCase(command)) {
		PrintWriter writer = response.getWriter();
	
		try {
			writer.write("<html><head><title>S2 Components</title></head><body><pre>");
			writer.flush();
	
			S2Container s2 = getContainer();
			int componentDefSize = s2.getComponentDefSize();
	
			for (int i = 0; i < componentDefSize; i++) {
				ComponentDef cd = s2.getComponentDef(i);
				if (cd == null) {
					continue;
				}
	
				writer.write("ComponentDef: ");
				writer.write(cd.getComponentName() == null?
					"":"[" +cd.getComponentName() + "] ");
				writer.write(cd.getComponentClass().getName());
				writer.write("\n");
	
				Class[] classes = getAssignableClasses(cd.getComponentClass());
				for (int j = 0; j < classes.length; j++) {
					if (classes[j].isInterface()) {
						writer.write("    implements ");
						writer.write(classes[j].getName());
						writer.write("\n");
					}
				}
				for (int j = 0; j < classes.length; j++) {
					if (!classes[j].isInterface()
							&& !classes[j].equals(cd.getComponentClass())) {
						writer.write("    extends    ");
						writer.write(classes[j].getName());
						writer.write("\n");
					}
				}
	
				writer.write("  autoBinding = ");
				writer.write(cd.getAutoBindingDef().getName());
				writer.write("\n");
				writer.write("  instanceMode = ");
				writer.write(cd.getInstanceDef().getName());
				writer.write("\n");
				writer.write("\n");
				writer.flush();
	
				int argDefSize = cd.getArgDefSize();
				for (int j = 0; j < argDefSize; j++) {
					ArgDef ad = cd.getArgDef(j);
	
					writer.write("  ArgDef: ");
					writer.write(String.valueOf(ad.getValue()));
					writer.write("\n");
				}
				writer.flush();
	
				int propertyDefSize = cd.getPropertyDefSize();
				for (int j = 0; j < propertyDefSize; j++) {
					PropertyDef pd = cd.getPropertyDef(j);
	
					writer.write("  PropertyDef: ");
					writer.write(pd.getPropertyName());
					writer.write(" = ");
					writer.write(String.valueOf(pd.getValue()));
					writer.write("\n");
				}
				writer.flush();
	
				int initMethodDefSize = cd.getInitMethodDefSize();
				for (int j = 0; j < initMethodDefSize; j++) {
					InitMethodDef imd = cd.getInitMethodDef(j);
	
					writer.write("  InitMethod: ");
					writer.write(imd.getMethodName());
					writer.write("\n");
					int imdArgDefSize = imd.getArgDefSize();
					for (int k = 0; k < imdArgDefSize; k++) {
						ArgDef ad = imd.getArgDef(k);
	
						writer.write("    ArgDef: ");
						writer.write(String.valueOf(ad.getValue()));
						writer.write("\n");
					}
				}
				writer.flush();
	
				int destroyMethodDefSize = cd.getDestroyMethodDefSize();
				for (int j = 0; j < destroyMethodDefSize; j++) {
					DestroyMethodDef dmd = cd.getDestroyMethodDef(j);
	
					writer.write("  DestroyMethod: ");
					writer.write(dmd.getMethodName());
					writer.write("\n");
					int imdArgDefSize = dmd.getArgDefSize();
					for (int k = 0; k < imdArgDefSize; k++) {
						ArgDef ad = dmd.getArgDef(k);
	
						writer.write("    ArgDef: ");
						writer.write(String.valueOf(ad.getValue()));
						writer.write("\n");
					}
				}
				writer.flush();
	
				int aspectDefSize = cd.getAspectDefSize();
				for (int j = 0; j < aspectDefSize; j++) {
					AspectDef ad = cd.getAspectDef(j);
	
					writer.write("  Aspect: ");
					writer.write(String.valueOf(ad.getExpression()));
					writer.write("\n");
					writer.write("    interceptor: ");
					writer.write(String.valueOf(ad.getAspect().getMethodInterceptor().getClass().getName()));
					writer.write("\n");
					writer.write("    pointcut: ");
					writer.write(String.valueOf(ad.getAspect().getPointcut()));
					writer.write("\n");
				}
	
				writer.write("\n");
				writer.flush();
			}
	
			writer.write("</body></html>");
		} catch (Exception e) {
			e.printStackTrace(writer);
		}
    }
}
	private static Class[] getAssignableClasses(Class componentClass) {
		Set classes = new HashSet();
		for (Class clazz = componentClass;
			clazz != Object.class && clazz != null;
			clazz = clazz.getSuperclass()) {
			classes.add(clazz);
			Class[] interfaces = clazz.getInterfaces();
			for (int i = 0; i < interfaces.length; ++i) {
				classes.add(interfaces[i]);
			}
		}
		return (Class[]) classes.toArray(new Class[classes.size()]);
	}
}