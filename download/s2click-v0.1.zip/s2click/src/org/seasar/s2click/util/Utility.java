package org.seasar.s2click.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletContext;
import org.seasar.s2click.example.dto.EmployeeSearchDto;
import net.sf.click.Context;
import net.sf.click.Page;
import net.sf.click.util.ClickUtils;

public class Utility {
	private static boolean greyboxCopied = false;
	public static String getFullPagePath(Page page, Class pageClass){
		return 
		page.getContext().getRequest().getContextPath()
		+ page.getContext().getPagePath(pageClass);
	}
	public static String CreateSeq(){
		return String.valueOf(new Date().getTime());
	}
	public static void setRedirectWithParameter(
			Page page, Object parameter, Class pageClass){
		String seq = CreateSeq();
		page.getContext().getSession().
			setAttribute(seq, parameter);
		page.setRedirect(page.getContext().getPagePath(pageClass) 
				+ "?seq=" + seq);		
	}
	public static Object getParameterFromSession(Page page){
		String seq = page.getContext().getRequest().getParameter("seq");
		Object parameter = null;
		if (seq != null){
			parameter = page.getContext().getSession().
			getAttribute(seq);
			page.getContext().getSession().removeAttribute(seq);
		}		
		return parameter;
	}
	public static void copyGrayboxJs(Context context)
	{
		if (greyboxCopied){
			return;
		}
		greyboxCopied = true;	
        String destination = getDestination(context.getServletContext());	
        try {
            File destinationFile = new File(destination);
            if (!destinationFile.exists()) {
                InputStream inputStream =
                    ClickUtils.class.getResourceAsStream(
                    		"/org/seasar/s2click/control/greybox/setfields-org.js"); 
	//			FileOutputStream fos = new FileOutputStream(destinationFile);
				FileWriter writer = new FileWriter(destination);
				writer.write("var GB_IMG_DIR = \"" +context.getRequest().getContextPath()
						+"/click/greybox/"+"\"\n;");
				InputStreamReader inputReader = new InputStreamReader(inputStream );
				BufferedReader bufferedReader = new BufferedReader(inputReader);
				String line;
				while ((line = bufferedReader.readLine()) != null){
					writer.write(line+"\n"); 
				}
				writer.close();
				inputStream.close();
            }

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void removeGrayboxJs(ServletContext context){
        String destination = getDestination(context);	
        File destinationFile = new File(destination); 
        if (destinationFile.exists()) {
        	destinationFile.delete();
        }
	}
	private static String getDestination(ServletContext context) {
		String destination = context.getRealPath("/")+"click" +
        File.separator +"greybox" +File.separator +"setfields.js";
		return destination;
	}
	public static String getDataYYMMDD(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy/MM/dd");
		return dateFormat.format(date);
	}
	public static String getDataYYYYMMDD(Date date){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		return dateFormat.format(date);
	}
	public static Date convDataYYMMDD(String value){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy/MM/dd");
		try {
			return dateFormat.parse(value);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public static Date convDataYYYYMMDD(String value){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		try {
			return dateFormat.parse(value);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}	
	
}
