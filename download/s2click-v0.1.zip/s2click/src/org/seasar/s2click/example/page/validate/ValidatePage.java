package org.seasar.s2click.example.page.validate;

import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.extras.control.EmailField;
import net.sf.click.extras.control.IntegerField;

public class ValidatePage extends org.seasar.s2click.example.page.BorderPage {
	
	private Form form = new Form("form");
	
	public ValidatePage(){
		addControl(form);
		IntegerField intfield = new IntegerField("int","Integer Test 最大10");
		intfield.setMaxValue(10);
		form.add(intfield);
		form.add(new EmailField("email","EMAIL ADDRESS"));
		form.add(new Submit("submit"));
	}

}