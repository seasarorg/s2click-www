package org.seasar.s2click.example.ldb.exentity;


/**
 * The entity of dept.
 * 
 * @author AutoGenerator
 */
public class Dept extends org.seasar.s2click.example.ldb.bsentity.BsDept {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
}
