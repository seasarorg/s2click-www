package org.seasar.s2click.example.page.employee;

import java.math.BigDecimal;
import java.util.Hashtable;
import java.util.List;

import net.sf.click.control.Form;
import net.sf.click.control.HiddenField;
import net.sf.click.control.Select;
import net.sf.click.control.Submit;
import net.sf.click.control.TextField;
import net.sf.click.extras.control.DateField;
import net.sf.click.extras.control.IntegerField;

import org.seasar.s2click.control.DateFieldYYYYMMDD;
import org.seasar.s2click.control.TextFieldSelectId;
import org.seasar.s2click.example.ldb.cbean.EmployeeCB;
import org.seasar.s2click.example.ldb.exbhv.DeptBhv;
import org.seasar.s2click.example.ldb.exbhv.EmployeeBhv;
import org.seasar.s2click.example.ldb.exentity.Employee;
import org.seasar.s2click.example.page.BorderPage;
import org.seasar.s2click.example.util.CommonLogic;
import org.seasar.s2click.util.Utility;

public class EditPage extends BorderPage {
	private DeptBhv deptbhv;
	private EmployeeBhv employeeBhv;
	public Form form = new Form("form");
	private HiddenField hmode = new HiddenField("hmode","");
	private IntegerField id = new IntegerField("id");
	private TextFieldSelectId textSelect = 
		new TextFieldSelectId("managerName","managerName");
	private TextField manageid = new TextField("manager","managerId");
	private Select deptid = new Select("deptid","dept");
	private Submit submit =new Submit("submit","更新",this,"onEditClicked");
	private Submit submit2 =new Submit("submit2","新規",this,"onNewClicked");
	public  EditPage (){
		manageid.setReadonly(true);
		form.add(hmode);
		id.setReadonly(true);
		form.add(id);
		form.add(new IntegerField("empno",true));
		form.add(new TextField("empname",true));
		form.add(new TextField("job",true));
		form.add(textSelect);
		form.add(manageid);
		form.add(new DateFieldYYYYMMDD("hiredate",true));
		form.add(new IntegerField("salary"));
		form.add(new HiddenField("versionno","0"));
		form.add(deptid);
		form.add(submit);
		form.add(submit2);

	}
	public void onInit() {
		textSelect.setIdField(manageid);
		textSelect.setSelectPage("ManagerSelect",
				Utility.getFullPagePath(this, ManagerSelectPage.class));
		CommonLogic.setDeptOptions(deptid, form, deptbhv);
	}
	public void onRender() {
		if (hmode.getValue().equals("new")){	
			form.removeField("submit");
			} else {
			form.removeField("submit2");	
			}
	}
	public void onGet(){
		String mode = getContext().getRequest().getParameter("mode");
		if (mode!=null) {
			hmode.setValue(mode);
			if (mode.equals("edit")){
				BigDecimal bid = new BigDecimal(getContext().getRequest().getParameter("id"));
				EmployeeCB cb = new EmployeeCB();
				cb.query().setId_Equal(bid);
				cb.query().queryEmployeeSelf().includeAsMine_Empname("managerName");
				Employee emp = employeeBhv.getMyDao().selectEntity(cb);
				if (emp!=null){
					form.copyFrom(emp);
					form.getField("versionno").setValue(emp.getVersionno().toString());
				}
			}
		} else {
			Hashtable ht = (Hashtable) Utility.getParameterFromSession(this);
			if (ht!=null){
				hmode.setValue((String) ht.get("mode"));
				Employee employee = (Employee) ht.get("employee");
				form.copyFrom(employee);
			}
		}
	}
	public void setDeptbhv(DeptBhv deptbhv) {
		this.deptbhv = deptbhv;
	}
	public boolean onEditClicked(){
		return process();	
	}
	public boolean onNewClicked(){
		return process();
	}
	
	public boolean process() {
		Employee employee = new Employee();
		form.copyTo(employee);
		if (employee.getDeptid()!=null){
			employee.setDeptName(CommonLogic.getDeptNameByDeptId(employee.getDeptid()));
		}
		if (form.isValid()) {
			if (checkEmpno(employee)==false){
				form.getField("empno").setError("Duplicate Empno");
				return true;
			}
			Hashtable ht = new Hashtable();
			ht.put("mode",hmode.getValue());
			ht.put("employee",employee);
			Utility.setRedirectWithParameter(
        			this, ht,ConfirmPage.class);
        	return false;			
		}
		return true;	
	}
	private boolean checkEmpno(Employee employee){
		EmployeeCB cb = new EmployeeCB();
		cb.query().setEmpno_Equal(employee.getEmpno());
		if (id.getInteger()!=null) {
			cb.query().setId_NotEqual(id.getInteger());
		}
		List<Employee> ls = employeeBhv.getMyDao().selectList(cb);
		return (ls.size()==0)? true:false;
	}
	public void setEmployeeBhv(EmployeeBhv employeeBhv) {
		this.employeeBhv = employeeBhv;
	}
}
