select employee.id, employee.manager, employee.empno, employee.empname, 
 employee.job, employee.hiredate, employee.salary, employee.deptid,
 employee.versionno , EmployeeSelf.empname as managerName,
 EmployeeSelf.id as managerId,
  Dept.deptname as deptName ,Dept.id as deptId 
  from employee 
  left outer join employee EmployeeSelf 
  on employee.manager = EmployeeSelf.id 
  left outer join dept Dept 
  on employee.deptid = Dept.id

/*BEGIN*/
where
/*IF dto.empno != null*/employee.empno = /*dto.empno*/7788/*END*/
/*IF dto.empname != null*/and employee.empname = /*dto.empname*/'SCOTT'/*END*/
/*IF dto.job != null*/and employee.job = /*dto.job*/'ANALYST'/*END*/
/*IF dto.managerId != null*/and EmployeeSelf.id = /*dto.managerId*/7566/*END*/
/*IF dto.hiredateFrom != null*/and employee.hiredate >= /*dto.hiredateFrom*/'1982-12-01'/*END*/
/*IF dto.hiredateTo != null*/and employee.hiredate <= /*dto.hiredateTo*/'1982-12-31'/*END*/
/*IF dto.salaryFrom != null*/and employee.salary >= /*dto.salaryFrom*/1000/*END*/
/*IF dto.salaryTo != null*/and employee.salary <= /*dto.salaryTo*/4000/*END*/
/*IF dto.deptid != null*/and employee.deptid = /*dto.deptid*/20/*END*/
/*END*/
  order by employee.id