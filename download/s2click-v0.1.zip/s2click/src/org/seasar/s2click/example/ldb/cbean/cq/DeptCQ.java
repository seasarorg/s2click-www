package org.seasar.s2click.example.ldb.cbean.cq;


import org.seasar.s2click.example.ldb.allcommon.cbean.*;
import org.seasar.s2click.example.ldb.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.ldb.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.ldb.allcommon.cbean.sqlclause.SqlClause;


/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class DeptCQ extends AbstractConditionQuery {

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public DeptCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    final public String getTableDbName() {
        return "dept";
    }

    // =====================================================================================
    //                                                                         IncludeAsMine
    //                                                                         =============
  
    /**
     * Include select-column of id as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Id() {
        return registerIncludedSelectColumn("Id", getRealColumnName("id"));
    }

    /**
     * Include select-column of id as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Id(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("id"));
    }
  
    /**
     * Include select-column of deptno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Deptno() {
        return registerIncludedSelectColumn("Deptno", getRealColumnName("deptno"));
    }

    /**
     * Include select-column of deptno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Deptno(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("deptno"));
    }
  
    /**
     * Include select-column of deptname as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Deptname() {
        return registerIncludedSelectColumn("Deptname", getRealColumnName("deptname"));
    }

    /**
     * Include select-column of deptname as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Deptname(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("deptname"));
    }
  
    /**
     * Include select-column of loc as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Loc() {
        return registerIncludedSelectColumn("Loc", getRealColumnName("loc"));
    }

    /**
     * Include select-column of loc as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Loc(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("loc"));
    }
  
    /**
     * Include select-column of versionno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Versionno() {
        return registerIncludedSelectColumn("Versionno", getRealColumnName("versionno"));
    }

    /**
     * Include select-column of versionno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ includeAsMine_Versionno(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("versionno"));
    }
  
    /**
     * Register included-select-column.
     * 
     * @param aliasName Alias name. This should not contain comma. (NotNull)
     * @param realColumnName Real column name. This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    protected DeptCQ registerIncludedSelectColumn(String aliasName, String realColumnName) {
        assertAliasName(aliasName);
        assertColumnName(realColumnName);
        getSqlClause().registerIncludedSelectColumn(aliasName, realColumnName);
        return this;
    }

    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [dept]
    // * * * * * * * * */

      
    /** Column db name of id. */
    protected static final String COL_id = "id";

    /** Column java name of id. */
    protected static final String J_Id = "Id";

    /** Column uncapitalised java name of id. */
    protected static final String UJ_id = "id";

    /** The attribute of id. */
    protected ConditionValue _id;

    /**
     * Get the value of id.
     * 
     * @return The value of id.
     */
    public ConditionValue getId() {
        if (_id == null) {
            _id = new ConditionValue();
        }
        return _id;
    }
            
    /**
     * Set the value of id using equal. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setId_Equal(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setId_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of id using equal. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setId_Equal(long value) {
        return registerId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setId_Equal_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_NotEqual(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_NotEqual(long value) {
        return registerId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_NotEqual_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterThan(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterThan(long value) {
        return registerId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterThan_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessThan(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessThan(long value) {
        return registerId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessThan_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterEqual(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterEqual(long value) {
        return registerId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_GreaterEqual_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessEqual(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessEqual(long value) {
        return registerId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setId_LessEqual_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of id as inScope.
     * @return this. (NotNull)
     */
    public DeptCQ setId_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerId(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of id using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of id as notInScope.
     * @return this. (NotNull)
     */
    public DeptCQ setId_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerId(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
              
    /** The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeList;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery. (Nullable)
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeList() {
        return _id_InScopeSubQuery_EmployeeList;
    }

    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery.
     * { in (select xxx.deptid from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query save the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ setId_InScopeSubQuery_EmployeeList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_InScopeSubQuery_EmployeeList = subQuery;// for saving query-value.
        registerInScopeSubQuery(subQuery, COL_id, "deptid", "id_InScopeSubQuery_EmployeeList");
        return this;
    }

    /** The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeList_AsInline;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline. (Nullable)
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeList_AsInline() {
        return _id_InScopeSubQuery_EmployeeList_AsInline;
    }

    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline.
     * { in (select xxx.deptid from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query save the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeList using inScopeSubQuery as inline. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ setId_InScopeSubQuery_EmployeeList_AsInline(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_InScopeSubQuery_EmployeeList_AsInline = subQuery;// for saving query-value.
        registerInlineInScopeSubQuery(subQuery, COL_id, "deptid", "id_InScopeSubQuery_EmployeeList_AsInline");
        return this;
    }
                            
    /** The sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery. */
    protected EmployeeCQ _id_ExistsSubQuery_EmployeeList;

    /**
     * Get the sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery.
     * 
     * @return The sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery. (Nullable)
     */
    public EmployeeCQ getId_ExistsSubQuery_EmployeeList() {
        return _id_ExistsSubQuery_EmployeeList;
    }

    /**
     * Set the sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery.
     * { exists (select xxx.deptid from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query save the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_ExistsSubQuery_EmployeeList using existsSubQuery. (NotNull)
     * @return this. (NotNull)
     */
    public DeptCQ setId_ExistsSubQuery_EmployeeList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_ExistsSubQuery_EmployeeList = subQuery;// for saving query-value.
        registerExistsSubQuery(subQuery, COL_id, "deptid", "id_ExistsSubQuery_EmployeeList");
        return this;
    }
                                      
    /**
     * Register condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerId(ConditionKey key, Object value) {
        if (key.isValidRegistration(getId(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Id")) {
            key.setupConditionValue(getId(), value, getLocation(UJ_id, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_id), key, getId());
        }
        return this;
    }

    /**
     * Register inline condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerInlineId(ConditionKey key, Object value) {
        if (key.isValidRegistration(getId(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Id")) {
            key.setupConditionValue(getId(), value, getLocation(UJ_id, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_id, key, getId());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_id, key, getId());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of id as ASC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Id_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, true);return this;
    }

    /**
     * Add order-by of id as DESC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Id_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, false);return this;
    }
          
    /** Column db name of deptno. */
    protected static final String COL_deptno = "deptno";

    /** Column java name of deptno. */
    protected static final String J_Deptno = "Deptno";

    /** Column uncapitalised java name of deptno. */
    protected static final String UJ_deptno = "deptno";

    /** The attribute of deptno. */
    protected ConditionValue _deptno;

    /**
     * Get the value of deptno.
     * 
     * @return The value of deptno.
     */
    public ConditionValue getDeptno() {
        if (_deptno == null) {
            _deptno = new ConditionValue();
        }
        return _deptno;
    }
            
    /**
     * Set the value of deptno using equal. { = }
     * 
     * @param value The value of deptno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_Equal(java.math.BigDecimal value) {
        return registerDeptno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of deptno using equal as inline. { = }
     * 
     * @param value The value of deptno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of deptno using equal. { = }
     * 
     * @param value The value of deptno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_Equal(long value) {
        return registerDeptno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using equal as inline. { = }
     * 
     * @param value The value of deptno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_Equal_AsInline(long value) {
        return registerInlineDeptno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of deptno using notEqual. { != }
     * 
     * @param value The value of deptno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_NotEqual(java.math.BigDecimal value) {
        return registerDeptno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of deptno using notEqual as inline. { != }
     * 
     * @param value The value of deptno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of deptno using notEqual. { != }
     * 
     * @param value The value of deptno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_NotEqual(long value) {
        return registerDeptno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using notEqual as inline. { != }
     * 
     * @param value The value of deptno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_NotEqual_AsInline(long value) {
        return registerInlineDeptno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using greaterThan. { &gt; }
     * 
     * @param value The value of deptno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterThan(java.math.BigDecimal value) {
        return registerDeptno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of deptno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of deptno using greaterThan. { &gt; }
     * 
     * @param value The value of deptno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterThan(long value) {
        return registerDeptno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterThan_AsInline(long value) {
        return registerInlineDeptno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using lessThan. { &lt; }
     * 
     * @param value The value of deptno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessThan(java.math.BigDecimal value) {
        return registerDeptno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of deptno using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of deptno using lessThan. { &lt; }
     * 
     * @param value The value of deptno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessThan(long value) {
        return registerDeptno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessThan_AsInline(long value) {
        return registerInlineDeptno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using greaterEqual. { &gt;= }
     * 
     * @param value The value of deptno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterEqual(java.math.BigDecimal value) {
        return registerDeptno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of deptno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of deptno using greaterEqual. { &gt;= }
     * 
     * @param value The value of deptno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterEqual(long value) {
        return registerDeptno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_GreaterEqual_AsInline(long value) {
        return registerInlineDeptno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using lessEqual. { &lt;= }
     * 
     * @param value The value of deptno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessEqual(java.math.BigDecimal value) {
        return registerDeptno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of deptno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of deptno using lessEqual. { &lt;= }
     * 
     * @param value The value of deptno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessEqual(long value) {
        return registerDeptno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_LessEqual_AsInline(long value) {
        return registerInlineDeptno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptno as inScope.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerDeptno(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of deptno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptno as notInScope.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptno_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerDeptno(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
                                    
    /**
     * Register condition of deptno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptno. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerDeptno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getDeptno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Deptno")) {
            key.setupConditionValue(getDeptno(), value, getLocation(UJ_deptno, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_deptno), key, getDeptno());
        }
        return this;
    }

    /**
     * Register inline condition of deptno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptno. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerInlineDeptno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getDeptno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Deptno")) {
            key.setupConditionValue(getDeptno(), value, getLocation(UJ_deptno, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_deptno, key, getDeptno());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_deptno, key, getDeptno());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of deptno as ASC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Deptno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptno), null, true);return this;
    }

    /**
     * Add order-by of deptno as DESC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Deptno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptno), null, false);return this;
    }
          
    /** Column db name of deptname. */
    protected static final String COL_deptname = "deptname";

    /** Column java name of deptname. */
    protected static final String J_Deptname = "Deptname";

    /** Column uncapitalised java name of deptname. */
    protected static final String UJ_deptname = "deptname";

    /** The attribute of deptname. */
    protected ConditionValue _deptname;

    /**
     * Get the value of deptname.
     * 
     * @return The value of deptname.
     */
    public ConditionValue getDeptname() {
        if (_deptname == null) {
            _deptname = new ConditionValue();
        }
        return _deptname;
    }
    
    /**
     * Set the value of deptname using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_Equal(String value) {
        return registerDeptname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_Equal_AsInline(String value) {
        return registerInlineDeptname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the empty-string of deptname as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_Equal_EmptyString() {
        return registerDeptname(ConditionKey.CK_EQUAL, "");
    }
      
    /**
     * Set the value of deptname using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_NotEqual(String value) {
        return registerDeptname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_NotEqual_AsInline(String value) {
        return registerInlineDeptname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_GreaterThan(String value) {
        return registerDeptname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_GreaterThan_AsInline(String value) {
        return registerInlineDeptname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_LessThan(String value) {
        return registerDeptname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_LessThan_AsInline(String value) {
        return registerInlineDeptname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_GreaterEqual(String value) {
        return registerDeptname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_GreaterEqual_AsInline(String value) {
        return registerInlineDeptname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_LessEqual(String value) {
        return registerDeptname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_LessEqual_AsInline(String value) {
        return registerInlineDeptname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as prefixSearch.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_PrefixSearch(String value) {
        return registerDeptname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of deptname as prefixSearch.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_PrefixSearch_AsInline(String value) {
        return registerInlineDeptname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of deptname using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptname as inScope.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_InScope(java.util.List<String> valueList) {
        return registerDeptname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of deptname using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptname as inScope.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_InScope_AsInline(java.util.List<String> valueList) {
        return registerInlineDeptname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of deptname using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptname as notInScope.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_NotInScope(java.util.List<String> valueList) {
        return registerDeptname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of deptname using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptname as notInScope.
     * @return this. (NotNull)
     */
    public DeptCQ setDeptname_NotInScope_AsInline(java.util.List<String> valueList) {
        return registerInlineDeptname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                        
    /**
     * Register condition of deptname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptname. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerDeptname(ConditionKey key, Object value) {
        if (key.isValidRegistration(getDeptname(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Deptname")) {
            key.setupConditionValue(getDeptname(), value, getLocation(UJ_deptname, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_deptname), key, getDeptname());
        }
        return this;
    }

    /**
     * Register inline condition of deptname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptname. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerInlineDeptname(ConditionKey key, Object value) {
        if (key.isValidRegistration(getDeptname(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Deptname")) {
            key.setupConditionValue(getDeptname(), value, getLocation(UJ_deptname, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_deptname, key, getDeptname());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_deptname, key, getDeptname());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of deptname as ASC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Deptname_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptname), null, true);return this;
    }

    /**
     * Add order-by of deptname as DESC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Deptname_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptname), null, false);return this;
    }
          
    /** Column db name of loc. */
    protected static final String COL_loc = "loc";

    /** Column java name of loc. */
    protected static final String J_Loc = "Loc";

    /** Column uncapitalised java name of loc. */
    protected static final String UJ_loc = "loc";

    /** The attribute of loc. */
    protected ConditionValue _loc;

    /**
     * Get the value of loc.
     * 
     * @return The value of loc.
     */
    public ConditionValue getLoc() {
        if (_loc == null) {
            _loc = new ConditionValue();
        }
        return _loc;
    }
    
    /**
     * Set the value of loc using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_Equal(String value) {
        return registerLoc(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_Equal_AsInline(String value) {
        return registerInlineLoc(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the empty-string of loc as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_Equal_EmptyString() {
        return registerLoc(ConditionKey.CK_EQUAL, "");
    }
      
    /**
     * Set the value of loc using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_NotEqual(String value) {
        return registerLoc(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_NotEqual_AsInline(String value) {
        return registerInlineLoc(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_GreaterThan(String value) {
        return registerLoc(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_GreaterThan_AsInline(String value) {
        return registerInlineLoc(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_LessThan(String value) {
        return registerLoc(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_LessThan_AsInline(String value) {
        return registerInlineLoc(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_GreaterEqual(String value) {
        return registerLoc(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_GreaterEqual_AsInline(String value) {
        return registerInlineLoc(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_LessEqual(String value) {
        return registerLoc(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_LessEqual_AsInline(String value) {
        return registerInlineLoc(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as prefixSearch.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_PrefixSearch(String value) {
        return registerLoc(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of loc as prefixSearch.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_PrefixSearch_AsInline(String value) {
        return registerInlineLoc(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of loc using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of loc as inScope.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_InScope(java.util.List<String> valueList) {
        return registerLoc(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of loc using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of loc as inScope.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_InScope_AsInline(java.util.List<String> valueList) {
        return registerInlineLoc(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of loc using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of loc as notInScope.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_NotInScope(java.util.List<String> valueList) {
        return registerLoc(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of loc using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of loc as notInScope.
     * @return this. (NotNull)
     */
    public DeptCQ setLoc_NotInScope_AsInline(java.util.List<String> valueList) {
        return registerInlineLoc(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                        
    /**
     * Register condition of loc.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of loc. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerLoc(ConditionKey key, Object value) {
        if (key.isValidRegistration(getLoc(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Loc")) {
            key.setupConditionValue(getLoc(), value, getLocation(UJ_loc, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_loc), key, getLoc());
        }
        return this;
    }

    /**
     * Register inline condition of loc.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of loc. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerInlineLoc(ConditionKey key, Object value) {
        if (key.isValidRegistration(getLoc(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Loc")) {
            key.setupConditionValue(getLoc(), value, getLocation(UJ_loc, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_loc, key, getLoc());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_loc, key, getLoc());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of loc as ASC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Loc_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_loc), null, true);return this;
    }

    /**
     * Add order-by of loc as DESC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Loc_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_loc), null, false);return this;
    }
          
    /** Column db name of versionno. */
    protected static final String COL_versionno = "versionno";

    /** Column java name of versionno. */
    protected static final String J_Versionno = "Versionno";

    /** Column uncapitalised java name of versionno. */
    protected static final String UJ_versionno = "versionno";

    /** The attribute of versionno. */
    protected ConditionValue _versionno;

    /**
     * Get the value of versionno.
     * 
     * @return The value of versionno.
     */
    public ConditionValue getVersionno() {
        if (_versionno == null) {
            _versionno = new ConditionValue();
        }
        return _versionno;
    }
            
    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_Equal(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_Equal(long value) {
        return registerVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_Equal_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_NotEqual(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_NotEqual(long value) {
        return registerVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_NotEqual_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterThan(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterThan(long value) {
        return registerVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterThan_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessThan(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessThan(long value) {
        return registerVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessThan_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterEqual(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterEqual(long value) {
        return registerVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_GreaterEqual_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessEqual(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessEqual(long value) {
        return registerVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_LessEqual_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of versionno as inScope.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerVersionno(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of versionno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of versionno as notInScope.
     * @return this. (NotNull)
     */
    public DeptCQ setVersionno_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerVersionno(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
                                    
    /**
     * Register condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerVersionno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getVersionno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Versionno")) {
            key.setupConditionValue(getVersionno(), value, getLocation(UJ_versionno, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_versionno), key, getVersionno());
        }
        return this;
    }

    /**
     * Register inline condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     * @return this. (NotNull)
     */
    protected DeptCQ registerInlineVersionno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getVersionno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Versionno")) {
            key.setupConditionValue(getVersionno(), value, getLocation(UJ_versionno, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_versionno, key, getVersionno());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_versionno, key, getVersionno());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of versionno as ASC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Versionno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, true);return this;
    }

    /**
     * Add order-by of versionno as DESC.
     * 
     * @return this. (NotNull)
     */
    public DeptCQ addOrderBy_Versionno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, false);return this;
    }
      
    // =====================================================================================
    //                                                               Query-SetupOuter-Method
    //                                                               =======================

  
        
    // =====================================================================================
    //                                                                                Helper
    //                                                                                ======
    /**
     * Filter removing empty-string.
     * If the value is null or empty-string, returns null.
     * 
     * @param value Query-value-string. (Nullable)
     * @return Filtered value. (Nullable)
     */
    protected String filterRemoveEmptyString(String value) {
        return ((value != null && !"".equals(value)) ? value : null);
    }

    /**
     * Filter removing empty-string from the list.
     * If the list is null or empty-string, returns null.
     * 
     * @param ls List. (Nullable)
     * @return Filtered list. (Nullable)
     */
    protected java.util.List<String> filterRemoveEmptyStringFromList(java.util.List<String> ls) {
        if (ls == null) {
            return null;
        }
        java.util.List<String> newList = new java.util.ArrayList<String>();
        for (final java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final String str = (String)ite.next();
            if ("".equals(str)) {
                continue;
            }
            newList.add(str);
        }
        return newList;
    }

    // =====================================================================================
    //                                                                 Basic-Override Method
    //                                                                 =====================
    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Clause string. (NotNull)
     */
    public String toString() {
        return getSqlClause().getClause();
    }
}
