package org.seasar.s2click.example.ldb.allcommon.bhv;

import org.seasar.s2click.example.ldb.allcommon.DaoSelector;
import org.seasar.s2click.example.ldb.allcommon.DaoReadable;
import org.seasar.s2click.example.ldb.allcommon.Entity;
import org.seasar.s2click.example.ldb.allcommon.cbean.ConditionBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.ListResultBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.OrderByBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.PagingBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.PagingResultBean;
import org.seasar.s2click.example.ldb.allcommon.dbmeta.DBMeta;

/**
 * The interface of behavior-readable.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface BehaviorReadable {

    // =====================================================================================
    //                                                                            Definition
    //                                                                            ==========
    /** Map-string map-mark. */
    public static final String MAP_STRING_MAP_MARK = "map:";

    /** Map-string list-mark. */
    public static final String MAP_STRING_LIST_MARK = "list:";

    /** Map-string start-brace. */
    public static final String MAP_STRING_START_BRACE = "@{";

    /** Map-string end-brace. */
    public static final String MAP_STRING_END_BRACE = "@}";

    /** Map-string delimiter. */
    public static final String MAP_STRING_DELIMITER = "@;";

    /** Map-string equal. */
    public static final String MAP_STRING_EQUAL = "@=";

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * Get table db-name.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName();

    // =====================================================================================
    //                                                                                DBMeta
    //                                                                                ======
    /**
     * Get dbmeta.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta();

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========
    /**
     * Get dao-readable.
     * 
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable getDaoReadable();

    /**
     * Get dao-selector.
     * 
     * @return Dao-selector.
     */
    public DaoSelector getDaoSelector();

    /**
     * Set dao-selector.
     * 
     * @param value Dao-selector.
     */
    public void setDaoSelector(DaoSelector value);

    // =====================================================================================
    //                                                                          New Instance
    //                                                                          ============
    /**
     * New condition-bean.
     * 
     * @return Condition-bean. (NotNull)
     */
    public ConditionBean newConditionBean();

    // =====================================================================================
    //                                                                       Delegate Method
    //                                                                       ===============
    /**
     * Read count as all. (Delegate-Method)
     * 
     * @return All count. (NotNull)
     */
    public int delegateReadCountAll() ;

    /**
     * Read list as all. (Delegate-Method)
     * 
     * @return All list. (NotNull)
     */
    public java.util.List<Entity> delegateReadListAll();

    /**
     * Read count by condition-bean. (Delegate-Method)
     * Ignore fetchFirst() and fetchScope() and fetchPage(). But the fetch status of the condition-bean remains as it is.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read count. (NotNull)
     */
    public int delegateReadCountIgnoreFetchScope(ConditionBean cb);

    /**
     * Read entity by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read entity. If the select result is zero, it returns null. (Nullable)
     */
    public Entity delegateReadEntity(ConditionBean cb);

    /**
     * Read list by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read list. If the select result is zero, it returns empty list. (NotNull)
     */
    public java.util.List<Entity> delegateReadList(ConditionBean cb);

    // =====================================================================================
    //                                                                          Basic Select
    //                                                                          ============
    /**
     * Read list.
     * 
     * @param cb Condition-bean.
     * @return List-result-bean. If the select result is zero, it returns empty list. (NotNull)
     */
    public ListResultBean<Entity> readList(ConditionBean cb);

    /**
     * Read page.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb);

    /**
     * Read page.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb, SelectPageInvoker<Entity> invoker);

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Entity that is selected from database. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Entity readEntityWithDeletedCheck(ConditionBean cb);

    // =====================================================================================
    //                                                                        Various Select
    //                                                                        ==============
    /**
     * Read list after checking count(ignore fetch scope).
     * 
     * @param cb Condition-bean.
     * @param maxCount Max count.
     * @return List-result-bean. If the select result is zero, it returns empty list. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.SelectedCountExceedMaxCountException
     */
    public ListResultBean<Entity> readListAfterCheckingCountIgnoreFetchScope(ConditionBean cb, int maxCount);

    /**
     * Read for read only by primary-key map-string with deleted check.
     * 
     * @param primaryKeyMapString Primary-Key map-string. (NotNull)
     * @return Entity that is read from database by select-for-read-only. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Entity readForReadOnlyByPKMapStringWithDeletedCheck(String primaryKeyMapString);

    /**
     * Read for update by primary-key map-string with deleted check.
     * 
     * @param primaryKeyMapString Primary-Key map-string. (NotNull)
     * @return Entity that is read from database by select-for-update. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Entity readForUpdateByPKMapStringWithDeletedCheck(String primaryKeyMapString);

    /**
     * The interface of select-page callback.
     * 
     * @param <T> The generic template for 'selectedList'.
     */
    public static interface SelectPageCallback<T> {
        public PagingBean getPagingBean();
        public int selectCountIgnoreFetchScope();
        public java.util.List<T> selectList();
    }

    /**
     * The object of result-bean builder.
     * 
     * @param <T> The generic template for 'resultBean'.
     */
    public static class ResultBeanBuilder<T> {
        protected BehaviorReadable _bhv;
        public ResultBeanBuilder(BehaviorReadable bhv) {
            _bhv = bhv;
        }
        /**
         * Build list-reuslt-bean.
         * 
         * @param ob Order-by-bean. (NotNull)
         * @param selectedList Selected list. (NotNull)
         * @return List-result-bean. (NotNull)
         */
        public ListResultBean<T> buildListResultBean(OrderByBean ob, java.util.List<T> selectedList) {
            ListResultBean<T> rb = new ListResultBean<T>();
            rb.setTableDbName(_bhv.getTableDbName());
            rb.setAllRecordCount(selectedList.size());
            rb.setSelectedList(selectedList);
            rb.setOrderByClause(ob.getSqlComponentOfOrderByClause());
            return rb;
        }
        /**
         * Build paging-reuslt-bean.
         * 
         * @param pb Paging-bean. (NotNull)
         * @param allRecordCount All-record-count.
         * @param selectedList Selected list. (NotNull)
         * @return Paging-result-bean. (NotNull)
         */
        public PagingResultBean<T> buildPagingResultBean(PagingBean pb, int allRecordCount, java.util.List<T> selectedList) {
            PagingResultBean<T> rb = new PagingResultBean<T>();
            rb.setTableDbName(_bhv.getTableDbName());
            rb.setAllRecordCount(allRecordCount);
            rb.setSelectedList(selectedList);
            rb.setPageSize(pb.getFetchSize());
            rb.setCurrentPageNumber(pb.getFetchPageNumber());
            rb.setOrderByClause(pb.getSqlComponentOfOrderByClause());
            return rb;
        }
    }

    public static interface SelectPageInvoker<T> {
        /**
         * Invoke select-page by callback.
         * 
         * @param callback Callback. (NotNull)
         * @return Paging-result-bean. (NotNull)
         */
        public PagingResultBean<T> invokeSelectPage(SelectPageCallback<T> callback);
    }

    /**
     * The object of result-bean builder.
     * 
     * @param <T> The generic template for 'resultBean'.
     */
    public static class SelectPageSimpleInvoker<T> implements SelectPageInvoker<T> {
        protected BehaviorReadable _bhv;
        public SelectPageSimpleInvoker(BehaviorReadable bhv) {
            _bhv = bhv;
        }

        /**
         * Invoke select-page by callback.
         * 
         * @param callback Callback. (NotNull)
         * @return Paging-result-bean. (NotNull)
         */
        public PagingResultBean<T> invokeSelectPage(SelectPageCallback<T> callback) {
            assertObjectNotNull("callback", callback);
            final int allRecordCount = callback.selectCountIgnoreFetchScope();
            final java.util.List<T> selectedList = callback.selectList();
            final PagingResultBean<T> rb = new ResultBeanBuilder<T>(_bhv).buildPagingResultBean(callback.getPagingBean(), allRecordCount, selectedList);
            if (isNecessaryToReadPageAgain(rb)) {
                callback.getPagingBean().fetchPage(rb.getAllPageCount());
                final int reAllRecordCount = callback.selectCountIgnoreFetchScope();
                final java.util.List<T> reSelectedList = callback.selectList();
                return new ResultBeanBuilder<T>(_bhv).buildPagingResultBean(callback.getPagingBean(), reAllRecordCount, reSelectedList);
            } else {
                return rb;
            }
        }

        /**
         * Is it necessary to read page again?
         * 
         * @param rb Paging-result-bean. (NotNull)
         * @return Determination.
         */
        protected boolean isNecessaryToReadPageAgain(PagingResultBean<T> rb) {
            return rb.getAllRecordCount() > 0 && rb.getSelectedList().isEmpty();
        }

        /**
         * Assert that the object is not null.
         * 
         * @param variableName Variable name. (NotNull)
         * @param value Value. (NotNull)
         * @exception IllegalArgumentException
         */
        protected void assertObjectNotNull(String variableName, Object value) {
            if (variableName == null) {
                String msg = "The value should not be null: variableName=" + variableName + " value=" + value;
                throw new IllegalArgumentException(msg);
            }
            if (value == null) {
                String msg = "The value should not be null: variableName=" + variableName;
                throw new IllegalArgumentException(msg);
            }
        }
    }

    /**
     * The marker interface of simple condition-bean setupper.
     */
    public static interface SimpleCBSetupper {
    }
}
