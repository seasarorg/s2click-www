package org.seasar.s2click.example.ldb.cbean;


/**
 * The condition-bean of employee.
 * 
 * @author AutoGenerator
 */
public class EmployeeCB extends org.seasar.s2click.example.ldb.cbean.bs.BsEmployeeCB {
}
