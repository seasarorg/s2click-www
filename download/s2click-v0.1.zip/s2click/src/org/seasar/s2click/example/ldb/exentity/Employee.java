package org.seasar.s2click.example.ldb.exentity;

import java.math.BigDecimal;


/**
 * The entity of employee.
 * 
 * @author AutoGenerator
 */
public class Employee extends org.seasar.s2click.example.ldb.bsentity.BsEmployee {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
    private String managerName;
    private String deptName;
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}


}
