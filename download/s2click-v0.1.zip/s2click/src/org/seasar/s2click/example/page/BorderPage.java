package org.seasar.s2click.example.page;
import net.sf.click.Page;
import net.sf.click.util.HtmlStringBuffer;

public class BorderPage extends Page {


    public BorderPage() {
        String className = getClass().getName();

        String shortName = className.substring(className.lastIndexOf('.') + 1);
        HtmlStringBuffer title = new HtmlStringBuffer();
        title.append(shortName.charAt(0));
        for (int i = 1; i < shortName.length(); i++) {
            char aChar = shortName.charAt(i);
            if (Character.isUpperCase(aChar)) {
                title.append(' ');
            }
            title.append(aChar);
        }
        addModel("title", title);

        String srcPath = className.replace('.', '/') + ".java";
        addModel("srcPath", srcPath);
    }


    public String getTemplate() {
        return "/border-template.htm";
    }

    // ------------------------------------------------------ Protected Methods

    protected Object getSessionObject(Class aClass) {
        if (aClass == null) {
            throw new IllegalArgumentException("Null class parameter.");
        }
        Object object = getContext().getSessionAttribute(aClass.getName());
        if (object == null) {
            try {
                object = aClass.newInstance();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return object;
    }

    protected void setSessionObject(Object object) {
        if (object != null) {
            getContext().setSessionAttribute(object.getClass().getName(), object);
        }
    }

    protected void removeSessionObject(Class aClass) {
        if (getContext().hasSession() && aClass != null) {
            getContext().getSession().removeAttribute(aClass.getName());
        }
    }

}

