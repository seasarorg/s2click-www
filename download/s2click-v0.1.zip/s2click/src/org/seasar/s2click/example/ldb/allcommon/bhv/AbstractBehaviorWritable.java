
package org.seasar.s2click.example.ldb.allcommon.bhv;

import org.seasar.s2click.example.ldb.allcommon.Entity;
import org.seasar.s2click.example.ldb.allcommon.helper.MapStringBuilder;
import org.seasar.s2click.example.ldb.allcommon.helper.MapStringBuilderImpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * The abstract class of behavior-writable.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class AbstractBehaviorWritable extends AbstractBehaviorReadable implements BehaviorWritable {

    /** Log-instance. */
    private static final Log _log = LogFactory.getLog(AbstractBehaviorWritable.class);

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public AbstractBehaviorWritable() {
    }

    // =====================================================================================
    //                                                                       Delegate Method
    //                                                                       ===============
    /**
     * This method implements the method that is declared at super.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Inserted count.
     */
    public int delegateCreate(Entity entity) {
        assertEntityNotNull(entity);// If this table use identity, the entity does not have primary-key.
        filterEntityOfInsert(entity);
        assertEntityOfInsert(entity);
        return getDaoWritable().create(entity);
    }

    /**
     * Filter the entity of insert.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void filterEntityOfInsert(Entity entity) {
    }

    /**
     * Assert the entity of insert.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void assertEntityOfInsert(Entity entity) {
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Updated count.
     */
    public int delegateModify(Entity entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        filterEntityOfUpdate(entity);
        assertEntityOfUpdate(entity);
        return getDaoWritable().modify(entity);
    }

    /**
     * Filter the entity of update.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void filterEntityOfUpdate(Entity entity) {
    }

    /**
     * Assert the entity of update.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void assertEntityOfUpdate(Entity entity) {
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     * @return Deleted count.
     */
    public int delegateRemove(Entity entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        filterEntityOfDelete(entity);
        assertEntityOfDelete(entity);
        return getDaoWritable().remove(entity);
    }

    /**
     * Filter the entity of delete.
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void filterEntityOfDelete(Entity entity) {
    }

    /**
     * Assert the entity of delete
     * 
     * @param entity Entity that the type is entity-interface. (NotNull)
     */
    protected void assertEntityOfDelete(Entity entity) {
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param entityList Entity-list that the type is entity-interface. (NotNull)
     * @return Inserted count.
     */
    public int delegateCreateList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        for (final java.util.Iterator ite = entityList.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            filterEntityOfInsert(entity);
            assertEntityOfInsert(entity);
        }
        return getDaoWritable().createList(entityList);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param entityList Entity-list that the type is entity-interface. (NotNull)
     * @return Updated count.
     */
    public int delegateModifyList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        for (final java.util.Iterator ite = entityList.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            filterEntityOfUpdate(entity);
            assertEntityOfUpdate(entity);
        }
        return getDaoWritable().modifyList(entityList);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param entityList Entity-list that the type is entity-interface. (NotNull)
     * @return Deleted count.
     */
    public int delegateRemoveList(java.util.List<Entity> entityList) {
        assertListNotNullAndNotEmpty(entityList);
        for (final java.util.Iterator ite = entityList.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            filterEntityOfDelete(entity);
            assertEntityOfDelete(entity);
        }
        return getDaoWritable().removeList(entityList);
    }

    // =====================================================================================
    //                                                                    Dao Various Method
    //                                                                    ==================
    /**
     * Create or modify after select-for-update.
     * 
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @return Updated count.
     */
    public int createOrModifyAfterSelectForUpdate(org.seasar.s2click.example.ldb.allcommon.Entity entity) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            return delegateCreate(entity);
        }
        final String mapString = entity.extractPrimaryKeyMapString();
        org.seasar.s2click.example.ldb.allcommon.Entity currentEntity = null;
        try {
            currentEntity = readForUpdateByPKMapStringWithDeletedCheck(mapString);
        } catch (org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException e) {
            return delegateCreate(entity);
        }
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        mergeEntity(entity, currentEntity);
        return delegateModify(currentEntity);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param entity Entity having primary-key value. (NotNull)
     * @return Updated count.
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public int modifyAfterSelectForUpdate(Entity entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        final Entity currentEntity = readForUpdateByPKMapStringWithDeletedCheck(entity.extractPrimaryKeyMapString());
        mergeEntity(entity, currentEntity);
        return delegateModify(currentEntity);
    }

    /**
     * Merge entity.
     * Copy the column data of sourceEntity that the setter has been invoked to destinationEntity.
     * 
     * @param sourceEntity Source entity. (NotNull)
     * @param destinationEntity Destination entity. (NotNull)
     */
    abstract protected void mergeEntity(Entity sourceEntity, Entity destinationEntity);

    /**
     * Reflect(insert or update) from separated-file.
     * 
     * @param filename Name of the file. (NotNull and NotEmpty)
     * @param encoding Encoding of the file. (NotNull and NotEmpty)
     * @param delimiter Delimiter of the file. (NotNull and NotEmpty)
     * @param batchCount Batch-count for transaction. If this value is 0, all records are done in one transaction.
     * @param isErrorContinue If true, this method continue in spite of throwing the exception.   
     * @return The list of InsertOrUpdateExceptionResult. (NotNull)
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public java.util.List<OneEntityExceptionResult> reflectFromSeparatedFile(
            String filename, String encoding,
            String delimiter, int batchCount, boolean isErrorContinue
            ) throws java.io.FileNotFoundException, java.io.IOException {
        assertStringNotNullAndNotTrimmedEmpty("filename", filename);
        assertStringNotNullAndNotTrimmedEmpty("encoding", encoding);
        assertObjectNotNull("delimiter", delimiter);
        final java.util.List<OneEntityExceptionResult> exceptionList = new java.util.ArrayList<OneEntityExceptionResult>();

        java.io.FileInputStream fis = null;
        java.io.InputStreamReader ir = null;
        java.io.BufferedReader br = null;
        try {
            fis = new java.io.FileInputStream(filename);
            ir = new java.io.InputStreamReader(fis, encoding);
            br = new java.io.BufferedReader(ir);

            final MapStringBuilder builder = new MapStringBuilderImpl();
            builder.setMsMapMark(MAP_STRING_MAP_MARK);
            builder.setMsStartBrace(MAP_STRING_START_BRACE);
            builder.setMsEndBrace(MAP_STRING_END_BRACE);
            builder.setMsDelimiter(MAP_STRING_DELIMITER);
            builder.setMsEqual(MAP_STRING_EQUAL);
            final java.util.List<Entity> entityList = new java.util.ArrayList<Entity>();
            int count = 0;
            while (true) {
                ++count;

                final String lineString = br.readLine();
                if (lineString == null) {
                    if (entityList.size() > 0) {
                        final java.util.List<OneEntityExceptionResult> tmpList = reflectAfterSelectForUpdateNewTx(entityList, isErrorContinue);
                        exceptionList.addAll(tmpList);
                        entityList.clear();
                    }
                    break;
                }
                if (count == 1) {
                    builder.setColumnNames(lineString.split(delimiter));
                    continue;
                }

                final String mapString = builder.buildByDelimiter(lineString, delimiter);
                final Entity entity = getDBMeta().newEntity();
                entity.acceptColumnValueMapString(mapString);
                entityList.add(entity);

                if (entityList.size() == batchCount) {
                    final java.util.List<OneEntityExceptionResult> tmpList = reflectAfterSelectForUpdateNewTx(entityList, isErrorContinue);
                    exceptionList.addAll(tmpList);
                    entityList.clear();
                }
            }
        } catch (java.io.FileNotFoundException e) {
            throw e;
        } catch (java.io.IOException e) {
            throw e;
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                if (ir != null) {
                    ir.close();
                }
                if (br != null) {
                    br.close();
                }
            } catch (java.io.IOException ignored) {
                _log.warn("File-close threw the exception: ", ignored);
            }
        }
        return exceptionList;
    }

    /**
     * Reflect(insert or update) from separated-file.
     * 
     * @param entityList The list of entity that is reflection target. (NotNull)
     * @param isErrorContinue If true, this method continue in spite of throwing the exception.
     * @return The list of InsertOrUpdateExceptionResult. (NotNull)
     */
    public java.util.List<OneEntityExceptionResult> reflectAfterSelectForUpdateNewTx(java.util.List<Entity> entityList,
            boolean isErrorContinue) {
        final java.util.List<OneEntityExceptionResult> exceptionList = new java.util.ArrayList<OneEntityExceptionResult>();
        for (final java.util.Iterator ite = entityList.iterator(); ite.hasNext(); ) {
            final Entity entity = (Entity)ite.next();
            try {
                createOrModifyAfterSelectForUpdate(entity);
            } catch (RuntimeException e) {
                if (isErrorContinue) {
                    final OneEntityExceptionResult result = new OneEntityExceptionResult();
                    result.setPrimaryKeyMapString(entity.extractPrimaryKeyMapString());
                    result.setEntity(entity);
                    result.setException(e);
                    exceptionList.add(result);
                    continue;
                }
                throw e;
            }
        }
        return exceptionList;
    }
}
