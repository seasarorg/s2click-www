package org.seasar.s2click.example.logic;

public interface TestLogic {

	public abstract String test();

}