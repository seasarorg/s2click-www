package org.seasar.s2click.example.logic.impl;

import org.seasar.s2click.example.logic.TestLogic;

public class TestLogicImpl implements TestLogic {
	/* (non-Javadoc)
	 * @see org.seasar.s2click.example.logic.Impl.TestLogic#test()
	 */
	public String test(){
		return "AAABBB";
	}
}
