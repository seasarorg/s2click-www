
package org.seasar.s2click.example.ldb.bsdao;

import org.seasar.s2click.example.ldb.exentity.Employee;

/**
 * The dao interface of employee.
 * 
 * <pre>
 * [primary-key]
 *     id
 * 
 * [column-property]
 *     id, empno, empname, job, manager, hiredate, salary, deptid, versionno
 * 
 * [foreign-property]
 *     dept, employeeSelf
 * 
 * [refferer-property]
 *     employeeSelfList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     id
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     Versionno
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface BsEmployeeDao extends org.seasar.s2click.example.ldb.allcommon.DaoWritable {

    /** BEAN-Annotation. */
    public Class BEAN = org.seasar.s2click.example.ldb.exentity.Employee.class;

    /** SQL-Annotation for getCountAll(). */
    public static final String getCountAll_SQL = "select count(*) from employee";

    /**
     * Get count as all.
     * 
     * @return All count.
     */
    public int getCountAll();

    /** SQL-Annotation for getListAll(). */
    public static final String getListAll_SQL = "select * from employee";

    /**
     * Get list as all.
     * 
     * @return All list. (NotNull)
     */
    public java.util.List<Employee> getListAll();

    /** SQL-Annotation for getEntity(). */
    public static final String getEntity_SQL = "select * from employee where employee.id = /*id*/null";

    /** Args-Annotation for getEntity(). */
    public static final String getEntity_ARGS = "id";

    public Employee getEntity(java.math.BigDecimal id);

    /**
     * Select count by condition-bean.
     * Ignore fetchFirst() and fetchScope() and fetchPage(). But the fetch status of the condition-bean remains as it is.
     * This select method generates SQL based on condition-bean.
     * <pre>
     * Example)
     *   final EmployeeCB cb = new EmployeeCB();
     *   cb.query().setXxx_GreaterEqual(new BigDecimal(14));
     *   final int count = dao.${database.ConditionBeanSelectCountMethodName}(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     */
    public int selectCountIgnoreFetchScope(org.seasar.s2click.example.ldb.cbean.EmployeeCB cb);

    /**
     * Select entity 'Employee' by condition-bean.
     * This select method generates SQL based on condition-bean.
     * <pre>
     * Example)
     *   final EmployeeCB cb = new EmployeeCB();
     *   cb.query().setXxxCode_Equal("abc");// It is assumed that this is the primary key...
     *   cb.lockForUpdate();
     *   final Employee entity = dao.selectEntity(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. If the select result is zero, it returns null. (Nullable)
     */
    public Employee selectEntity(org.seasar.s2click.example.ldb.cbean.EmployeeCB cb);

    /**
     * Select list by condition-bean.
     * This select method generates SQL based on condition-bean.
     * <pre>
     * Example)
     *   final EmployeeCB cb = new EmployeeCB();
     *   cb.setupSelect_Xxx(); // Including the foreign table in select clause
     *   cb.query().setXxxName_PrefixSearch("abc");
     *   cb.query().setXxxStartDate_IsNotNull();
     *   cb.addOrderBy_PK_Asc().fetchFirst(20);
     *   final List resultList = dao.selectList(cb);
     * </pre>
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list. If the select result is zero, it returns empty list. (NotNull)
     */
    public java.util.List<Employee> selectList(org.seasar.s2click.example.ldb.cbean.EmployeeCB cb);


    /**
     * Insert one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Inserted count.
     */
    public int insert(Employee entity);

    /**
     * Update one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int update(Employee entity);

    /**
     * Delete one entity.
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delete(Employee entity);

    /**
     * Insert several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return Inserted count.
     */
    public int insertList(java.util.List<Employee> entityList);

    /**
     * Update several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return Updated count.
     */
    public int updateList(java.util.List<Employee> entityList);

    /**
     * Delete several entities.
     * 
     * @param entityList Entity-list. (NotNull)
     * @return Deleted count.
     */
    public int deleteList(java.util.List<Employee> entityList);

}
