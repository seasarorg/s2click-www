package org.seasar.s2click.example.ldb.exbhv;


/**
 * The behavior of dept.
 * 
 * @author AutoGenerator
 */
public class DeptBhv extends org.seasar.s2click.example.ldb.bsbhv.BsDeptBhv {
}
