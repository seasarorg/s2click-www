package org.seasar.s2click.example.ldb.exdao;


/**
 * The dao interface of dept.
 * 
 * @author AutoGenerator
 */
public interface DeptDao extends org.seasar.s2click.example.ldb.bsdao.BsDeptDao {
}
