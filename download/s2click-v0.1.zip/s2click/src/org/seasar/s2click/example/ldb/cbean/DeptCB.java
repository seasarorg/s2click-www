package org.seasar.s2click.example.ldb.cbean;


/**
 * The condition-bean of dept.
 * 
 * @author AutoGenerator
 */
public class DeptCB extends org.seasar.s2click.example.ldb.cbean.bs.BsDeptCB {
}
