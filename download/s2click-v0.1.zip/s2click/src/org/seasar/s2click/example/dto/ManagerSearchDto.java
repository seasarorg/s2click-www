package org.seasar.s2click.example.dto;

import java.math.BigDecimal;

public class ManagerSearchDto {
	private String empname;
	private BigDecimal deptid;
	public BigDecimal getDeptid() {
		return deptid;
	}
	public void setDeptid(BigDecimal deptid) {
		this.deptid = deptid;
	}
	public String getEmpname() {
		if (empname!=null){
			return "%"+empname+"%";
		}
		else {
			return null;
		}
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
}
