package org.seasar.s2click.example.logic;

public interface AddLogic {

	public abstract Integer calculate(Integer para1, Integer para2);

}