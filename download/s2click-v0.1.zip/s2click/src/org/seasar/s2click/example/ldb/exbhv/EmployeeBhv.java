package org.seasar.s2click.example.ldb.exbhv;


/**
 * The behavior of employee.
 * 
 * @author AutoGenerator
 */
public class EmployeeBhv extends org.seasar.s2click.example.ldb.bsbhv.BsEmployeeBhv {
}
