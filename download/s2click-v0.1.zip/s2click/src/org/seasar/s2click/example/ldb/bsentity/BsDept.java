package org.seasar.s2click.example.ldb.bsentity;


import org.seasar.s2click.example.ldb.allcommon.Entity;
import org.seasar.s2click.example.ldb.allcommon.dbmeta.DBMeta;
import org.seasar.s2click.example.ldb.bsentity.dbmeta.DeptDbm;


/**
 * The entity of dept.
 * 
 * <pre>
 * [primary-key]
 *     id
 * 
 * [column-property]
 *     id, deptno, deptname, loc, versionno
 * 
 * [foreign-property]
 *     
 * 
 * [refferer-property]
 *     employeeList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     id
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     Versionno
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class BsDept implements Entity, java.io.Serializable {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;

    /** TABLE-Annotation for S2Dao */
    public static final String TABLE = "dept";

    
    /** VERSION_NO-Annotation */
    public static final String VERSION_NO_PROPERTY = "versionno";
    
    /** ID-Annotation */
    public static final String id_ID = "identity";

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    
    /** The value of id. */
    protected java.math.BigDecimal _id;

    /** Has the setter of id been invoked? */
    protected boolean _isSetterInvokedId;
    
    /** The value of deptno. */
    protected java.math.BigDecimal _deptno;

    /** Has the setter of deptno been invoked? */
    protected boolean _isSetterInvokedDeptno;
    
    /** The value of deptname. */
    protected String _deptname;

    /** Has the setter of deptname been invoked? */
    protected boolean _isSetterInvokedDeptname;
    
    /** The value of loc. */
    protected String _loc;

    /** Has the setter of loc been invoked? */
    protected boolean _isSetterInvokedLoc;
    
    /** The value of versionno. */
    protected java.math.BigDecimal _versionno;

    /** Has the setter of versionno been invoked? */
    protected boolean _isSetterInvokedVersionno;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public BsDept() {
    }

    // =====================================================================================
    //                                                                                DBMeta
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return DeptDbm.getInstance();
    }

    // =====================================================================================
    //                                                                            Table Name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return getDBMeta().getTableDbName();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table cap-prop-name. (NotNull)
     */
    public String getTableCapPropName() {
        return getDBMeta().getTableCapPropName();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table uncap-prop-name. (NotNull)
     */
    public String getTableUncapPropName() {
        return getDBMeta().getTableUncapPropName();
    }

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========

    /**
     * Get the value of id.
     * 
     * @return The value of id. (Nullable)
     */
    public java.math.BigDecimal getId() {
        return _id;
    }

    /**
     * Set the value of id.
     * 
     * @param id The value of id. (Nullable)
     */
    public void setId(java.math.BigDecimal id) {
        _isSetterInvokedId = true;
        _id = id;
    }

    /**
     * Get the value of deptno.
     * 
     * @return The value of deptno. (Nullable)
     */
    public java.math.BigDecimal getDeptno() {
        return _deptno;
    }

    /**
     * Set the value of deptno.
     * 
     * @param deptno The value of deptno. (Nullable)
     */
    public void setDeptno(java.math.BigDecimal deptno) {
        _isSetterInvokedDeptno = true;
        _deptno = deptno;
    }

    /**
     * Get the value of deptname.
     * 
     * @return The value of deptname. (Nullable)
     */
    public String getDeptname() {
        return _deptname;
    }

    /**
     * Set the value of deptname.
     * 
     * @param deptname The value of deptname. (Nullable)
     */
    public void setDeptname(String deptname) {
        _isSetterInvokedDeptname = true;
        _deptname = deptname;
    }

    /**
     * Get the value of loc.
     * 
     * @return The value of loc. (Nullable)
     */
    public String getLoc() {
        return _loc;
    }

    /**
     * Set the value of loc.
     * 
     * @param loc The value of loc. (Nullable)
     */
    public void setLoc(String loc) {
        _isSetterInvokedLoc = true;
        _loc = loc;
    }

    /**
     * Get the value of versionno.
     * 
     * @return The value of versionno. (Nullable)
     */
    public java.math.BigDecimal getVersionno() {
        return _versionno;
    }

    /**
     * Set the value of versionno.
     * 
     * @param versionno The value of versionno. (Nullable)
     */
    public void setVersionno(java.math.BigDecimal versionno) {
        _isSetterInvokedVersionno = true;
        _versionno = versionno;
    }

    // =====================================================================================
    //                                                                Invoking Determination
    //                                                                ======================

    /**
     * Has the setter of id been invoked?
     * 
     * @return Determination.
     */
    public boolean isSetterInvokedId() {
        return _isSetterInvokedId;
    }

    /**
     * Has the setter of deptno been invoked?
     * 
     * @return Determination.
     */
    public boolean isSetterInvokedDeptno() {
        return _isSetterInvokedDeptno;
    }

    /**
     * Has the setter of deptname been invoked?
     * 
     * @return Determination.
     */
    public boolean isSetterInvokedDeptname() {
        return _isSetterInvokedDeptname;
    }

    /**
     * Has the setter of loc been invoked?
     * 
     * @return Determination.
     */
    public boolean isSetterInvokedLoc() {
        return _isSetterInvokedLoc;
    }

    /**
     * Has the setter of versionno been invoked?
     * 
     * @return Determination.
     */
    public boolean isSetterInvokedVersionno() {
        return _isSetterInvokedVersionno;
    }

    // =====================================================================================
    //                                                                       Classify Method
    //                                                                       ===============
          
    // =====================================================================================
    //                                                          Classification Determination
    //                                                          ============================
          
    // =====================================================================================
    //                                                                 Classification Getter
    //                                                                 =====================
          
    // =====================================================================================
    //                                                                         Foreign Table
    //                                                                         =============

    // =====================================================================================
    //                                                                        Refferer Table
    //                                                                        ==============

  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ReffererTable    = [employee]
    //   ReffererProperty = [employeeList]
    // * * * * * * * * */
  
    /** The list of refferer table. */
    protected java.util.List<org.seasar.s2click.example.ldb.exentity.Employee> _childrenEmployeeList;

    /**
     * Get the list of refferer table without lazyload.
     * If it's not loaded yet, returns null.
     * 
     * @return The list of refferer table. (Nullable)
     */
    public java.util.List<org.seasar.s2click.example.ldb.exentity.Employee> getEmployeeList() {
        return _childrenEmployeeList;
    }

    /**
     * Set the list of refferer table.
     * 
     * @param value The list of refferer table. (Nullable)
     */
    public void setEmployeeList(java.util.List<org.seasar.s2click.example.ldb.exentity.Employee> value) {
        _childrenEmployeeList = value;
    }
  
    // =====================================================================================
    //                                                                                Accept
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMap Primary key map. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMap(java.util.Map<String, ? extends Object> primaryKeyMap) {
        if (primaryKeyMap == null) {
            String msg = "The argument[primaryKeyMap] should not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (primaryKeyMap.isEmpty()) {
            String msg = "The argument[primaryKeyMap] should not be empty.";
            throw new IllegalArgumentException(msg);
        }
  
        if (!primaryKeyMap.containsKey("id")) {
            String msg = "The primaryKeyMap must have the value of id";
            throw new IllegalStateException(msg + ": primaryKeyMap --> " + primaryKeyMap);
        }
        {
            final Object obj = primaryKeyMap.get("id");
            if (obj == null) {
                _id = null;
                _isSetterInvokedId = false;
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setId((java.math.BigDecimal)obj);
                } else {
                    try {
                        setId(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMapString Primary-key map-string. (NotNull and NotEmpty)
     */
    public void acceptPrimaryKeyMapString(String primaryKeyMapString) {
        MapStringUtil.acceptPrimaryKeyMapString(primaryKeyMapString, this);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param columnValueMap Column-value map. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMap(java.util.Map<String, ? extends Object> columnValueMap) {
        if (columnValueMap == null) {
            String msg = "The argument[columnValueMap] should not be null.";
            throw new IllegalArgumentException(msg);
        }
        if (columnValueMap.isEmpty()) {
            String msg = "The argument[columnValueMap] should not be empty.";
            throw new IllegalArgumentException(msg);
        }
  
        {
            final Object obj = columnValueMap.get("id");
            if (obj == null) {
                _id = null; _isSetterInvokedId = false;
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setId((java.math.BigDecimal)obj);
                } else {
                    try {
                        setId(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setId(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("deptno");
            if (obj == null) {
                _deptno = null; _isSetterInvokedDeptno = false;
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setDeptno((java.math.BigDecimal)obj);
                } else {
                    try {
                        setDeptno(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setDeptno(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
        {
            final Object obj = columnValueMap.get("deptname");
            if (obj == null) {
                _deptname = null; _isSetterInvokedDeptname = false;
            } else {
    
                checkTypeString(obj, "deptname", "String");
                setDeptname((String)obj);
            }
        }
      
        {
            final Object obj = columnValueMap.get("loc");
            if (obj == null) {
                _loc = null; _isSetterInvokedLoc = false;
            } else {
    
                checkTypeString(obj, "loc", "String");
                setLoc((String)obj);
            }
        }
      
        {
            final Object obj = columnValueMap.get("versionno");
            if (obj == null) {
                _versionno = null; _isSetterInvokedVersionno = false;
            } else {
                  
                if (obj instanceof java.math.BigDecimal) {
                    setVersionno((java.math.BigDecimal)obj);
                } else {
                    try {
                        setVersionno(new java.math.BigDecimal((String)obj));
                    } catch (RuntimeException e) {
                        String msg = "setVersionno(new java.math.BigDecimal((String)obj))";
                        throw new RuntimeException(msg + " threw the exception: value=[" + obj + "]", e);
                    }
                }
            }
        }
                    
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param columnValueMapString Column-value map-string. (NotNull and NotEmpty)
     */
    public void acceptColumnValueMapString(String columnValueMapString) {
        MapStringUtil.acceptColumnValueMapString(columnValueMapString, this);
    }

    protected void checkTypeString(Object value, String propertyName, String typeName) {
        MapStringUtil.checkTypeString(value, propertyName, typeName);
    }

    protected java.util.Date parseDateString(Object value, String propertyName, String typeName) {
        return MapStringUtil.parseDateString(value, propertyName, typeName);
    }

    // =====================================================================================
    //                                                                               Extract
    //                                                                               =======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString() {
        return MapStringUtil.extractPrimaryKeyMapString(this);
    }

    /**
     * Extract primary-key map-string.
     * 
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Primary-key map-string. (NotNull)
     */
    public String extractPrimaryKeyMapString(String startBrace, String endBrace, String delimiter, String equal) {

        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();

      
        sb.append(delimiter).append("id").append(equal);
        sb.append((_id != null ? _id.toString() : ""));
      
        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();

    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString() {
        return MapStringUtil.extractColumnValueMapString(this);
    }

    /**
     * Extract column-value map-string.
     * 
     * @param startBrace Start-brace. (NotNull)
     * @param endBrace End-brace. (NotNull)
     * @param delimiter Delimiter. (NotNull)
     * @param equal Equal. (NotNull)
     * @return Column-value map-string. (NotNull)
     */
    public String extractColumnValueMapString(String startBrace, String endBrace, String delimiter, String equal) {
        final String mapMarkAndStartBrace = MAP_STRING_MAP_MARK + startBrace;
        final StringBuffer sb = new StringBuffer();

    
        sb.append(delimiter).append("id").append(equal);
        sb.append((_id != null ? _id.toString() : ""));
        
        sb.append(delimiter).append("deptno").append(equal);
        sb.append((_deptno != null ? _deptno.toString() : ""));
        
        sb.append(delimiter).append("deptname").append(equal);
        sb.append((_deptname != null ? _deptname.toString() : ""));
        
        sb.append(delimiter).append("loc").append(equal);
        sb.append((_loc != null ? _loc.toString() : ""));
        
        sb.append(delimiter).append("versionno").append(equal);
        sb.append((_versionno != null ? _versionno.toString() : ""));
    
        sb.delete(0, delimiter.length()).insert(0, mapMarkAndStartBrace).append(endBrace);
        return sb.toString();
    }


    // =====================================================================================
    //                                                                         Determination
    //                                                                         =============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Determination.
     */
    public boolean hasPrimaryKeyValue() {
  
        if (_id == null) {
            return false;
        }
  
        return true;
    }

    // =====================================================================================
    //                                                                        Basic Override
    //                                                                        ==============

    /**
     * This method overrides the method that is declared at super.
     * If the primary-key of the other is same as this one, returns true.
     * 
     * @param other Other entity.
     * @return Comparing result.
     */
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (!(other instanceof BsDept)) {
            return false;
        }
        final BsDept otherEntity = (BsDept)other;
  
        if (getId() == null || !getId().equals(otherEntity.getId())) {
            return false;
        }
  
        return true;
    }

    /**
     * This method overrides the method that is declared at super.
     * Calculates hash-code from primary-key.
     * 
     * @return Hash-code from primary-keys.
     */
    public int hashCode() {
        int result = 0;
  
        if (this.getId() != null) {
            result = result + getId().hashCode();
        }
  
        return result;
    }

    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Column-value map-string. (NotNull)
     */
    public String toString() {
        final String delimiter = ",";
        final StringBuffer sb = new StringBuffer();

        sb.append(delimiter).append(getId());

        sb.append(delimiter).append(getDeptno());

        sb.append(delimiter).append(getDeptname());

        sb.append(delimiter).append(getLoc());

        sb.append(delimiter).append(getVersionno());

        sb.delete(0, delimiter.length());
        sb.insert(0, "{").append("}");
        return sb.toString();
    }
}
