package org.seasar.s2click.example.ldb.bsentity.dbmeta;


import org.seasar.s2click.example.ldb.allcommon.Entity;
import org.seasar.s2click.example.ldb.allcommon.dbmeta.DBMeta;
import org.seasar.s2click.example.ldb.allcommon.dbmeta.AbstractDBMeta;
import org.seasar.s2click.example.ldb.exentity.Employee;

/**
 * The dbmeta of employee. (Singleton)
 * 
 * <pre>
 * [primary-key]
 *     id
 * 
 * [column-property]
 *     id, empno, empname, job, manager, hiredate, salary, deptid, versionno
 * 
 * [foreign-property]
 *     dept, employeeSelf
 * 
 * [refferer-property]
 *     employeeSelfList
 * 
 * [sequence]
 *     
 * 
 * [identity]
 *     id
 * 
 * [update-date]
 *     
 * 
 * [version-no]
 *     Versionno
 * 
 * </pre>
 * 
 * @author DBFlute(AutoGenerator)
 */
public class EmployeeDbm extends AbstractDBMeta {

    /** The type of entity. */
    protected static final Class ENTITY_TYPE = Employee.class;

    /** Singleton instance. */
    private static final EmployeeDbm _instance = new EmployeeDbm();

    /**
     * Constructor
     */
    private EmployeeDbm() {
    }

    /**
     * Get instance.
     * 
     * @return Singleton instance. (NotNull)
     */
    public static EmployeeDbm getInstance() {
        return _instance;
    }

    // =====================================================================================
    //                                                                       Name Definition
    //                                                                       ===============
    /** Table db name. */
    public static final String TABLE_DB_NAME = "employee";

    /** Table cap-prop name. */
    public static final String TABLE_CAP_PROP_NAME = "Employee";

    /** Table uncap-prop name. */
    public static final String TABLE_UNCAP_PROP_NAME = "employee";


    /** Db-name of Id. */
    public static final String COLUMN_DB_NAME_OF_Id = "id";

    /** Db-name of Empno. */
    public static final String COLUMN_DB_NAME_OF_Empno = "empno";

    /** Db-name of Empname. */
    public static final String COLUMN_DB_NAME_OF_Empname = "empname";

    /** Db-name of Job. */
    public static final String COLUMN_DB_NAME_OF_Job = "job";

    /** Db-name of Manager. */
    public static final String COLUMN_DB_NAME_OF_Manager = "manager";

    /** Db-name of Hiredate. */
    public static final String COLUMN_DB_NAME_OF_Hiredate = "hiredate";

    /** Db-name of Salary. */
    public static final String COLUMN_DB_NAME_OF_Salary = "salary";

    /** Db-name of Deptid. */
    public static final String COLUMN_DB_NAME_OF_Deptid = "deptid";

    /** Db-name of Versionno. */
    public static final String COLUMN_DB_NAME_OF_Versionno = "versionno";


    /** Cap-prop-name of Id. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Id = "Id";

    /** Cap-prop-name of Empno. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Empno = "Empno";

    /** Cap-prop-name of Empname. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Empname = "Empname";

    /** Cap-prop-name of Job. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Job = "Job";

    /** Cap-prop-name of Manager. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Manager = "Manager";

    /** Cap-prop-name of Hiredate. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Hiredate = "Hiredate";

    /** Cap-prop-name of Salary. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Salary = "Salary";

    /** Cap-prop-name of Deptid. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Deptid = "Deptid";

    /** Cap-prop-name of Versionno. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Versionno = "Versionno";

    /** Cap-prop-name of dept. */
    public static final String COLUMN_CAP_PROP_NAME_OF_Dept = "Dept";

    /** Cap-prop-name of employeeSelf. */
    public static final String COLUMN_CAP_PROP_NAME_OF_EmployeeSelf = "EmployeeSelf";

    /** Cap-prop-name of EmployeeSelfList. */
    public static final String COLUMN_CAP_PROP_NAME_OF_EmployeeSelfList = "EmployeeSelfList";


    /** Uncap-prop-name of Id. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Id = "id";

    /** Uncap-prop-name of Empno. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Empno = "empno";

    /** Uncap-prop-name of Empname. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Empname = "empname";

    /** Uncap-prop-name of Job. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Job = "job";

    /** Uncap-prop-name of Manager. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Manager = "manager";

    /** Uncap-prop-name of Hiredate. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Hiredate = "hiredate";

    /** Uncap-prop-name of Salary. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Salary = "salary";

    /** Uncap-prop-name of Deptid. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Deptid = "deptid";

    /** Uncap-prop-name of Versionno. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Versionno = "versionno";

    /** Uncap-prop-name of dept. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_Dept = "dept";

    /** Uncap-prop-name of employeeSelf. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_EmployeeSelf = "employeeSelf";

    /** Uncap-prop-name of employeeSelfList. */
    public static final String COLUMN_UNCAP_PROP_NAME_OF_EmployeeSelfList = "employeeSelfList";

    /** {db-name : cap-prop-name} map. */
    protected static final java.util.Map<String, String> _dbNameCapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_DB_NAME, TABLE_CAP_PROP_NAME);

        map.put(COLUMN_DB_NAME_OF_Id, COLUMN_CAP_PROP_NAME_OF_Id);

        map.put(COLUMN_DB_NAME_OF_Empno, COLUMN_CAP_PROP_NAME_OF_Empno);

        map.put(COLUMN_DB_NAME_OF_Empname, COLUMN_CAP_PROP_NAME_OF_Empname);

        map.put(COLUMN_DB_NAME_OF_Job, COLUMN_CAP_PROP_NAME_OF_Job);

        map.put(COLUMN_DB_NAME_OF_Manager, COLUMN_CAP_PROP_NAME_OF_Manager);

        map.put(COLUMN_DB_NAME_OF_Hiredate, COLUMN_CAP_PROP_NAME_OF_Hiredate);

        map.put(COLUMN_DB_NAME_OF_Salary, COLUMN_CAP_PROP_NAME_OF_Salary);

        map.put(COLUMN_DB_NAME_OF_Deptid, COLUMN_CAP_PROP_NAME_OF_Deptid);

        map.put(COLUMN_DB_NAME_OF_Versionno, COLUMN_CAP_PROP_NAME_OF_Versionno);

        _dbNameCapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {db-name : uncap-prop-name} map. */
    protected static final java.util.Map<String, String> _dbNameUncapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_DB_NAME, TABLE_UNCAP_PROP_NAME);

        map.put(COLUMN_DB_NAME_OF_Id, COLUMN_UNCAP_PROP_NAME_OF_Id);

        map.put(COLUMN_DB_NAME_OF_Empno, COLUMN_UNCAP_PROP_NAME_OF_Empno);

        map.put(COLUMN_DB_NAME_OF_Empname, COLUMN_UNCAP_PROP_NAME_OF_Empname);

        map.put(COLUMN_DB_NAME_OF_Job, COLUMN_UNCAP_PROP_NAME_OF_Job);

        map.put(COLUMN_DB_NAME_OF_Manager, COLUMN_UNCAP_PROP_NAME_OF_Manager);

        map.put(COLUMN_DB_NAME_OF_Hiredate, COLUMN_UNCAP_PROP_NAME_OF_Hiredate);

        map.put(COLUMN_DB_NAME_OF_Salary, COLUMN_UNCAP_PROP_NAME_OF_Salary);

        map.put(COLUMN_DB_NAME_OF_Deptid, COLUMN_UNCAP_PROP_NAME_OF_Deptid);

        map.put(COLUMN_DB_NAME_OF_Versionno, COLUMN_UNCAP_PROP_NAME_OF_Versionno);

        _dbNameUncapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {cap-prop-name : db-name} map. */
    protected static final java.util.Map<String, String> _capPropNameDbNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_CAP_PROP_NAME, TABLE_DB_NAME);

        map.put(COLUMN_CAP_PROP_NAME_OF_Id, COLUMN_DB_NAME_OF_Id);

        map.put(COLUMN_CAP_PROP_NAME_OF_Empno, COLUMN_DB_NAME_OF_Empno);

        map.put(COLUMN_CAP_PROP_NAME_OF_Empname, COLUMN_DB_NAME_OF_Empname);

        map.put(COLUMN_CAP_PROP_NAME_OF_Job, COLUMN_DB_NAME_OF_Job);

        map.put(COLUMN_CAP_PROP_NAME_OF_Manager, COLUMN_DB_NAME_OF_Manager);

        map.put(COLUMN_CAP_PROP_NAME_OF_Hiredate, COLUMN_DB_NAME_OF_Hiredate);

        map.put(COLUMN_CAP_PROP_NAME_OF_Salary, COLUMN_DB_NAME_OF_Salary);

        map.put(COLUMN_CAP_PROP_NAME_OF_Deptid, COLUMN_DB_NAME_OF_Deptid);

        map.put(COLUMN_CAP_PROP_NAME_OF_Versionno, COLUMN_DB_NAME_OF_Versionno);

        _capPropNameDbNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {cap-prop-name : uncap-prop-name} map. */
    protected static final java.util.Map<String, String> _capPropNameUncapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_CAP_PROP_NAME, TABLE_UNCAP_PROP_NAME);

        map.put(COLUMN_CAP_PROP_NAME_OF_Id, COLUMN_UNCAP_PROP_NAME_OF_Id);

        map.put(COLUMN_CAP_PROP_NAME_OF_Empno, COLUMN_UNCAP_PROP_NAME_OF_Empno);

        map.put(COLUMN_CAP_PROP_NAME_OF_Empname, COLUMN_UNCAP_PROP_NAME_OF_Empname);

        map.put(COLUMN_CAP_PROP_NAME_OF_Job, COLUMN_UNCAP_PROP_NAME_OF_Job);

        map.put(COLUMN_CAP_PROP_NAME_OF_Manager, COLUMN_UNCAP_PROP_NAME_OF_Manager);

        map.put(COLUMN_CAP_PROP_NAME_OF_Hiredate, COLUMN_UNCAP_PROP_NAME_OF_Hiredate);

        map.put(COLUMN_CAP_PROP_NAME_OF_Salary, COLUMN_UNCAP_PROP_NAME_OF_Salary);

        map.put(COLUMN_CAP_PROP_NAME_OF_Deptid, COLUMN_UNCAP_PROP_NAME_OF_Deptid);

        map.put(COLUMN_CAP_PROP_NAME_OF_Versionno, COLUMN_UNCAP_PROP_NAME_OF_Versionno);

        _capPropNameUncapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {uncap-prop-name : db-name} map. */
    protected static final java.util.Map<String, String> _uncapPropNameDbNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_UNCAP_PROP_NAME, TABLE_DB_NAME);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Id, COLUMN_DB_NAME_OF_Id);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Empno, COLUMN_DB_NAME_OF_Empno);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Empname, COLUMN_DB_NAME_OF_Empname);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Job, COLUMN_DB_NAME_OF_Job);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Manager, COLUMN_DB_NAME_OF_Manager);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Hiredate, COLUMN_DB_NAME_OF_Hiredate);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Salary, COLUMN_DB_NAME_OF_Salary);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Deptid, COLUMN_DB_NAME_OF_Deptid);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Versionno, COLUMN_DB_NAME_OF_Versionno);

        _uncapPropNameDbNameMap = java.util.Collections.unmodifiableMap(map);
    }

    /** {uncap-prop-name : cap-prop-name} map. */
    protected static final java.util.Map<String, String> _uncapPropNameCapPropNameMap;
    static {
        final java.util.Map<String, String> map = new java.util.LinkedHashMap<String, String>();
        map.put(TABLE_UNCAP_PROP_NAME, TABLE_CAP_PROP_NAME);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Id, COLUMN_CAP_PROP_NAME_OF_Id);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Empno, COLUMN_CAP_PROP_NAME_OF_Empno);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Empname, COLUMN_CAP_PROP_NAME_OF_Empname);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Job, COLUMN_CAP_PROP_NAME_OF_Job);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Manager, COLUMN_CAP_PROP_NAME_OF_Manager);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Hiredate, COLUMN_CAP_PROP_NAME_OF_Hiredate);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Salary, COLUMN_CAP_PROP_NAME_OF_Salary);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Deptid, COLUMN_CAP_PROP_NAME_OF_Deptid);

        map.put(COLUMN_UNCAP_PROP_NAME_OF_Versionno, COLUMN_CAP_PROP_NAME_OF_Versionno);

        _uncapPropNameCapPropNameMap = java.util.Collections.unmodifiableMap(map);
    }

    // =====================================================================================
    //                                                                            Table Name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return TABLE_DB_NAME;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table cap-prop-name. (NotNull)
     */
    public String getTableCapPropName() {
        return TABLE_CAP_PROP_NAME;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table property-name. (NotNull)
     */
    public String getTableUncapPropName() {
        return TABLE_UNCAP_PROP_NAME;
    }

    // =====================================================================================
    //                                                                    DB-Name-Map Getter
    //                                                                    ==================
    /**
     * This method implements the method that is declared at super.
     * 
     * @return {db-name : cap-prop-name} map.
     */
    public java.util.Map<String, String> getDbNameCapPropNameMap() {
        return _dbNameCapPropNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {db-name : uncap-prop-name} map.
     */
    public java.util.Map<String, String> getDbNameUncapPropNameMap() {
        return _dbNameUncapPropNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {cap-prop-name : db-name} map.
     */
    public java.util.Map<String, String> getCapPropNameDbNameMap() {
        return _capPropNameDbNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {cap-prop-name : uncap-prop-name} map.
     */
    public java.util.Map<String, String> getCapPropNameUncapPropNameMap() {
        return _capPropNameUncapPropNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {uncap-prop-name : db-name} map.
     */
    public java.util.Map<String, String> getUncapPropNameDbNameMap() {
        return _uncapPropNameDbNameMap;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return {uncap-prop-name : cap-prop-name} map.
     */
    public java.util.Map<String, String> getUncapPropNameCapPropNameMap() {
        return _uncapPropNameCapPropNameMap;
    }

    // =====================================================================================
    //                                                                      Type Name Getter
    //                                                                      ================
    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type-name of entity. (NotNull)
     */ 
    public String getEntityTypeName() {
        return "org.seasar.s2click.example.ldb.exentity.Employee";
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type-name of condition-bean. (NotNull)
     */ 
    public String getConditionBeanTypeName() {
        return "EmployeeCB.EmployeeCB";
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type-name of dao. (NotNull)
     */ 
    public String getDaoTypeName() {
        return "org.seasar.s2click.example.ldb.exdao.EmployeeDao";
    }

    // =====================================================================================
    //                                                                           Type Getter
    //                                                                           ===========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type of entity. (NotNull)
     */ 
    public Class getEntityType() {
        return ENTITY_TYPE;
    }

    // =====================================================================================
    //                                                                       Instance Getter
    //                                                                       ===============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return The type of entity. (NotNull)
     */ 
    public Entity newEntity() {
        return newMyEntity();
    }

    /**
     * New the instance of my entity.
     * 
     * @return The instance of my entity. (NotNull)
     */ 
    public Employee newMyEntity() {
        return new Employee();
    }

    // =====================================================================================
    //                                                                         Entity Method
    //                                                                         =============

    /** The getter method of id. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Id = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Id);

    /** <summary>The setter method of id. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Id = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Id, java.math.BigDecimal.class);

    /** The getter method of empno. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Empno = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Empno);

    /** <summary>The setter method of empno. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Empno = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Empno, java.math.BigDecimal.class);

    /** The getter method of empname. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Empname = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Empname);

    /** <summary>The setter method of empname. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Empname = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Empname, String.class);

    /** The getter method of job. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Job = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Job);

    /** <summary>The setter method of job. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Job = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Job, String.class);

    /** The getter method of manager. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Manager = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Manager);

    /** <summary>The setter method of manager. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Manager = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Manager, java.math.BigDecimal.class);

    /** The getter method of hiredate. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Hiredate = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Hiredate);

    /** <summary>The setter method of hiredate. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Hiredate = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Hiredate, java.util.Date.class);

    /** The getter method of salary. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Salary = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Salary);

    /** <summary>The setter method of salary. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Salary = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Salary, java.math.BigDecimal.class);

    /** The getter method of deptid. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Deptid = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Deptid);

    /** <summary>The setter method of deptid. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Deptid = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Deptid, java.math.BigDecimal.class);

    /** The getter method of versionno. */
    protected static final java.lang.reflect.Method ENTITY_GETTER_METHOD_Versionno = getGetterMethod("get" + COLUMN_CAP_PROP_NAME_OF_Versionno);

    /** <summary>The setter method of versionno. */
    protected static final java.lang.reflect.Method ENTITY_SETTER_METHOD_Versionno = getSetterMethod("set" + COLUMN_CAP_PROP_NAME_OF_Versionno, java.math.BigDecimal.class);

    /**
     * Get getter method.
     * 
     * @param methodName The method name. (NotNull)
     * @return The getter method. (NotNull)
     */
    protected static java.lang.reflect.Method getGetterMethod(String methodName) {
        try {
            return ENTITY_TYPE.getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The method doen not exist: methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
    }

    /**
     * Get setter method.
     * 
     * @param methodName The method name. (NotNull)
     * @param type Argument type. (NotNull)
     * @return The getter method. (NotNull)
     */
    protected static java.lang.reflect.Method getSetterMethod(String methodName, Class type) {
        try {
            return ENTITY_TYPE.getMethod(methodName, new Class[]{type});
        } catch (NoSuchMethodException e) {
            String msg = "The method doen not exist: methodName=" + methodName + " argsType=" + type;
            throw new RuntimeException(msg, e);
        }
    }


    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of id. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Id() {
        return ENTITY_GETTER_METHOD_Id;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of id. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Id() {
        return ENTITY_SETTER_METHOD_Id;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of empno. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Empno() {
        return ENTITY_GETTER_METHOD_Empno;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of empno. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Empno() {
        return ENTITY_SETTER_METHOD_Empno;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of empname. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Empname() {
        return ENTITY_GETTER_METHOD_Empname;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of empname. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Empname() {
        return ENTITY_SETTER_METHOD_Empname;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of job. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Job() {
        return ENTITY_GETTER_METHOD_Job;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of job. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Job() {
        return ENTITY_SETTER_METHOD_Job;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of manager. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Manager() {
        return ENTITY_GETTER_METHOD_Manager;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of manager. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Manager() {
        return ENTITY_SETTER_METHOD_Manager;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of hiredate. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Hiredate() {
        return ENTITY_GETTER_METHOD_Hiredate;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of hiredate. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Hiredate() {
        return ENTITY_SETTER_METHOD_Hiredate;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of salary. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Salary() {
        return ENTITY_GETTER_METHOD_Salary;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of salary. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Salary() {
        return ENTITY_SETTER_METHOD_Salary;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of deptid. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Deptid() {
        return ENTITY_GETTER_METHOD_Deptid;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of deptid. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Deptid() {
        return ENTITY_SETTER_METHOD_Deptid;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The getter method of versionno. (NotNull)
     */
    public java.lang.reflect.Method getEntityGetterMethod_Versionno() {
        return ENTITY_GETTER_METHOD_Versionno;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return The setter method of versionno. (NotNull)
     */
    public java.lang.reflect.Method getEntitySetterMethod_Versionno() {
        return ENTITY_SETTER_METHOD_Versionno;
    }

    /**
     * Get entity getter method by multi-name.
     * 
     * @param multiName Multi-name. (NotNull)
     * @return Entity getter method of entity. (NotNull)
     */ 
    public java.lang.reflect.Method getEntityGetterMethodByMultiName(String multiName) {
        assertStringNotNullAndNotTrimmedEmpty("multiName", multiName);
        final String capPropName = getCapPropNameByMultiName(multiName);
        final String methodName = "getEntityGetterMethod_" + capPropName;

        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The multiName is not found: multiName=" + multiName;
            msg = msg + " tableName=" + TABLE_DB_NAME + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            return (java.lang.reflect.Method)method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    /**
     * Get entity setter method by multi-name.
     * 
     * @param multiName Multi-name. (NotNull)
     * @return Entity setter method of entity. (NotNull)
     */ 
    public java.lang.reflect.Method getEntitySetterMethodByMultiName(String multiName) {
        assertStringNotNullAndNotTrimmedEmpty("multiName", multiName);
        final String capPropName = getCapPropNameByMultiName(multiName);
        final String methodName = "getEntitySetterMethod_" + capPropName;

        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The multiName is not found: multiName=" + multiName;
            msg = msg + " tableName=" + TABLE_DB_NAME + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            return (java.lang.reflect.Method)method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    // =====================================================================================
    //                                                                        Foreign DBMeta
    //                                                                        ==============
    /**
     * This method implements the method that is declared at super.
     * 
     * @param foreignPropertyName Foreign-property-name(Both OK - InitCap or not). (NotNull)
     * @return Foreign DBMeta. (NotNull)
     */ 
    public DBMeta getForeignDBMeta(String foreignPropertyName) {
        assertStringNotNullAndNotTrimmedEmpty("foreignPropertyName", foreignPropertyName);
        final String methodName = "getForeignDBMeta_" + foreignPropertyName.substring(0, 1) + foreignPropertyName.substring(1);

        java.lang.reflect.Method method = null;
        try {
            method = this.getClass().getMethod(methodName, new Class[]{});
        } catch (NoSuchMethodException e) {
            String msg = "The foreignPropertyName is not found: foreignPropertyName=" + foreignPropertyName;
            msg = msg + " tableName=" + TABLE_DB_NAME + " methodName=" + methodName;
            throw new RuntimeException(msg, e);
        }
        try {
            return (DBMeta)method.invoke(this, new Object[]{});
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }


    /**
     * Get foreign dbmeta of Dept.
     * 
     * @return Foreign DBMeta. (NotNull)
     */
    public DeptDbm getForeignDBMeta_Dept() {
        return DeptDbm.getInstance();
    }

    /**
     * Get foreign dbmeta of EmployeeSelf.
     * 
     * @return Foreign DBMeta. (NotNull)
     */
    public EmployeeDbm getForeignDBMeta_EmployeeSelf() {
        return EmployeeDbm.getInstance();
    }


    // =====================================================================================
    //                                                                         Determination
    //                                                                         =============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Determination.
     */
    public boolean hasTwoOrMorePrimaryKeys() {
        return false;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Determination.
     */
    public boolean hasCommonColumn() {
        return false;
    }
}
