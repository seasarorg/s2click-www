
package org.seasar.s2click.example.ldb.allcommon.bhv;

import org.seasar.s2click.example.ldb.allcommon.DaoSelector;
import org.seasar.s2click.example.ldb.allcommon.Entity;
import org.seasar.s2click.example.ldb.allcommon.cbean.ConditionBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.ListResultBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.PagingBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.PagingResultBean;


/**
 * The abstract class of behavior-readable.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class AbstractBehaviorReadable implements BehaviorReadable {

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    /** Dao-selector instance. */
    protected DaoSelector _daoSelector;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public AbstractBehaviorReadable() {
    }

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Dao-selector.
     */
    public DaoSelector getDaoSelector() {
        return _daoSelector;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param value Dao-selector.
     */
    public void setDaoSelector(DaoSelector value) {
        _daoSelector = value;
    }

    // =====================================================================================
    //                                                                       Delegate Method
    //                                                                       ===============
    /**
     * This method implements the method that is declared at super.
     * 
     * @return All count.
     */
    public int delegateReadCountAll() {
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "getCountAll", new Class[]{});
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{});
        return ((Integer)result).intValue();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return All list. (NotNull)
     */
    public java.util.List<Entity> delegateReadListAll() {
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "getListAll", new Class[]{});
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{});
        return (java.util.List<Entity>)result;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean that the type is condition-bean-interface. (NotNull)
     * @return Read count. (NotNull)
     */
    public int delegateReadCountIgnoreFetchScope(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final Class[] types = new Class[]{cb.getClass()};
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "selectCountIgnoreFetchScope", types);
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{cb});
        return ((Integer)result).intValue();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean that the type is condition-bean-interface. (NotNull)
     * @return Read entity. If the select result is zero, it returns null. (Nullable)
     */
    public Entity delegateReadEntity(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final Class[] types = new Class[]{cb.getClass()};
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "selectEntity", types);
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{cb});
        return (Entity)result;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean that the type is condition-bean-interface. (NotNull)
     * @return Read list. If the select result is zero, it returns empty list. (NotNull)
     */
    public java.util.List<Entity> delegateReadList(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        final Class[] types = new Class[]{cb.getClass()};
        final java.lang.reflect.Method mtd = getMethod(getDaoReadable().getClass(), "selectList", types);
        final Object result = invoke(mtd, getDaoReadable(), new Object[]{cb});
        return (java.util.List<Entity>)result;
    }

    private java.lang.reflect.Method getMethod(Class clazz, String methodName, Class[] argTypes) {
        try {
            return clazz.getMethod(methodName, argTypes);
        } catch (NoSuchMethodException ex) {
            String msg = "class=" + clazz + " method=" + methodName + "-" + java.util.Arrays.asList(argTypes);
            throw new RuntimeException(msg, ex);
        }
    }

    private Object invoke(java.lang.reflect.Method method, Object target, Object[] args) {
        try {
            return method.invoke(target, args);
        } catch (java.lang.reflect.InvocationTargetException ex) {
            Throwable t = ex.getCause();
            if (t instanceof RuntimeException) {
                throw (RuntimeException) t;
            }
            if (t instanceof Error) {
                throw (Error) t;
            }
            String msg = "target=" + target + " method=" + method + "-" + java.util.Arrays.asList(args);
            throw new RuntimeException(msg, ex);
        } catch (IllegalAccessException ex) {
            String msg = "target=" + target + " method=" + method + "-" + java.util.Arrays.asList(args);
            throw new RuntimeException(msg, ex);
        }
    }

    // =====================================================================================
    //                                                                          Basic Select
    //                                                                          ============
    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean.
     * @return List-result-bean. If the select result is zero, it returns empty list. (NotNull)
     */
    public ListResultBean<Entity> readList(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        return new ResultBeanBuilder<Entity>(this).buildListResultBean(cb, delegateReadList(cb));
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        return readPage(cb, new SelectPageSimpleInvoker<Entity>(this));
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Read page. (NotNull)
     */
    public PagingResultBean<Entity> readPage(final ConditionBean cb, SelectPageInvoker<Entity> invoker) {
        assertConditionBeanNotNull(cb);
        final SelectPageCallback<Entity> pageCallback = new SelectPageCallback<Entity>() {
            public PagingBean getPagingBean() { return cb; }
            public int selectCountIgnoreFetchScope() {
                return delegateReadCountIgnoreFetchScope(cb);
            }
            public java.util.List<Entity> selectList() {
                return delegateReadList(cb);
            }
        };
        return invoker.invokeSelectPage(pageCallback);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Entity that is read from database. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Entity readEntityWithDeletedCheck(ConditionBean cb) {
        assertConditionBeanNotNull(cb);
        Entity currentEntity = delegateReadEntity(cb);
        assertRecordHasNotBeenDeleted(currentEntity, cb.toString());
        return currentEntity;
    }

    /**
     * Assert that record has not been deleted.
     * 
     * @param entity Selected entity.
     * @param searchKey4log Search-key for Logging.
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    protected void assertRecordHasNotBeenDeleted(org.seasar.s2click.example.ldb.allcommon.Entity entity, Object searchKey4log) {
        if (entity == null) {
            String msg = "The record has already been deleted by other thread: searchKey=" + searchKey4log;
            throw new org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException(msg);
        }
    }

    /**
     * Assert that record has not been deleted.
     * 
     * @param ls Selected list.
     * @param searchKey4log Search-key for Logging.
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    protected void assertRecordHasNotBeenDeleted(java.util.List ls, Object searchKey4log) {
        if (ls == null || ls.isEmpty()) {
            String msg = "The record has already been deleted by other thread: searchKey=" + searchKey4log;
            throw new org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException(msg);
        }
    }

    /**
     * Assert that record has been selected as one.
     * 
     * @param ls Selected list.
     * @param searchKey4log Search-key for Logging.
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasOverlappedException
     */
    protected void assertRecordHasBeenSelectedAsOne(java.util.List ls, Object searchKey4log) {
        if (ls == null || ls.isEmpty()) {
            String msg = "The record has already been deleted by other thread: searchKey=" + searchKey4log;
            throw new org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException(msg);
        }
        if (ls.size() != 1) {
            String msg = "This selected contents should be only one: searchKey=" + searchKey4log;
            msg = msg + " resultCount=" + ls.size();
            throw new org.seasar.s2click.example.ldb.allcommon.exception.RecordHasOverlappedException(msg);
        }
    }

    // =====================================================================================
    //                                                                        Various Select
    //                                                                        ==============

    /**
     * This method implements the method that is declared at super.
     * 
     * @param cb Condition-bean.
     * @param maxCount Max count.
     * @return List-result-bean. If the select result is zero, it returns empty list. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.SelectedCountExceedMaxCountException
     */
    public ListResultBean<Entity> readListAfterCheckingCountIgnoreFetchScope(ConditionBean cb, int maxCount) {
        assertConditionBeanNotNull(cb);
        final int selectedCount = delegateReadCountIgnoreFetchScope(cb);
        assertSelectedCountHasNotExceededMaxCount(selectedCount, maxCount, cb.toString());
        return new ResultBeanBuilder<Entity>(this).buildListResultBean(cb, delegateReadList(cb));
    }

    /**
     * Assert that selected count has not exceeded max count.
     * 
     * @param selectedCount Selected count.
     * @param maxCount Max count.
     * @param clauseString Clause string for exception message.
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.SelectedCountExceedMaxCountException
     */
    protected void assertSelectedCountHasNotExceededMaxCount(int selectedCount, int maxCount, String clauseString) {
        if (selectedCount > maxCount) {
            String msg = "Selected count[" + selectedCount + "] has exceeded max count[" + maxCount + "]: clauseString=" + clauseString;
            throw new org.seasar.s2click.example.ldb.allcommon.exception.SelectedCountExceedMaxCountException(msg, selectedCount, maxCount);
        }
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMapString Primary-Key map-string. (NotNull)
     * @return Entity that is read from database by select-for-read-only. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Entity readForReadOnlyByPKMapStringWithDeletedCheck(String primaryKeyMapString) {
        assertObjectNotNull("primaryKeyMapString", primaryKeyMapString);
        final ConditionBean cb = newConditionBean();
        cb.acceptPrimaryKeyMapString(primaryKeyMapString);
        final Entity currentEntity = delegateReadEntity(cb);
        assertRecordHasNotBeenDeleted(currentEntity, primaryKeyMapString);
        return currentEntity;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param primaryKeyMapString Primary-Key map-string. (NotNull)
     * @return Entity that is read from database by select-for-update. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Entity readForUpdateByPKMapStringWithDeletedCheck(String primaryKeyMapString) {
        assertObjectNotNull("primaryKeyMapString", primaryKeyMapString);
        final ConditionBean cb = newConditionBean();
        cb.acceptPrimaryKeyMapString(primaryKeyMapString);
        cb.lockForUpdate();
        final Entity currentEntity = delegateReadEntity(cb);
        assertRecordHasNotBeenDeleted(currentEntity, primaryKeyMapString);
        return currentEntity;
    }

    // =====================================================================================
    //                                                                         Helper Method
    //                                                                         =============
    // ----------------------------------------------------------------
    //                                                    Assert Object
    //                                                    -------------
    /**
     * Assert that the object is not null.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     * @exception IllegalArgumentException
     */
    protected void assertObjectNotNull(String variableName, Object value) {
        if (variableName == null) {
            String msg = "The value should not be null: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
        if (value == null) {
            String msg = "The value should not be null: variableName=" + variableName;
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the entity is not null.
     * 
     * @param entity Entity. (NotNull)
     */
    protected void assertEntityNotNull(Entity entity) {
        assertObjectNotNull("entity", entity);
    }

    /**
     * Assert that the condition-bean is not null.
     * 
     * @param cb Condition-bean. (NotNull)
     */
    protected void assertConditionBeanNotNull(org.seasar.s2click.example.ldb.allcommon.cbean.ConditionBean cb) {
        assertObjectNotNull("cb", cb);
    }

    /**
     * Assert that the entity has primary-key value.
     * 
     * @param entity Entity. (NotNull)
     */
    protected void assertEntityNotNullAndHasPrimaryKeyValue(Entity entity) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            String msg = "The entity must should primary-key: entity=" + entity;
            throw new IllegalArgumentException(msg + entity);
        }
    }

    // ----------------------------------------------------------------
    //                                                    Assert String
    //                                                    -------------
    /**
     * Assert that the entity is not null and not trimmed empty.
     * 
     * @param variableName Variable name. (NotNull)
     * @param value Value. (NotNull)
     */
    protected void assertStringNotNullAndNotTrimmedEmpty(String variableName, String value) {
        assertObjectNotNull("variableName", variableName);
        assertObjectNotNull("value", value);
        if (value.trim().length() ==0) {
            String msg = "The value should not be empty: variableName=" + variableName + " value=" + value;
            throw new IllegalArgumentException(msg);
        }
    }

    // ----------------------------------------------------------------
    //                                                      Assert List
    //                                                      -----------
    /**
     * Assert that the list is empty.
     * 
     * @param ls List. (NotNull)
     */
    protected void assertListNotNullAndEmpty(java.util.List ls) {
        assertObjectNotNull("ls", ls);
        if (!ls.isEmpty()) {
            String msg = "The list should be empty: ls=" + ls.toString();
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the list is not empty.
     * 
     * @param ls List. (NotNull)
     */
    protected void assertListNotNullAndNotEmpty(java.util.List ls) {
        assertObjectNotNull("ls", ls);
        if (ls.isEmpty()) {
            String msg = "The list should not be empty: ls=" + ls.toString();
            throw new IllegalArgumentException(msg);
        }
    }

    /**
     * Assert that the list having only one.
     * 
     * @param ls List. (NotNull)
     */
    protected void assertListNotNullAndHasOnlyOne(java.util.List ls) {
        assertObjectNotNull("ls", ls);
        if (ls.size() != 1) {
            String msg = "The list should contain only one object: ls=" + ls.toString();
            throw new IllegalArgumentException(msg);
        }
    }
}
