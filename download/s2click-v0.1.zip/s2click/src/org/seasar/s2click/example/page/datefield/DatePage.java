package org.seasar.s2click.example.page.datefield;

import java.text.DateFormat;

import org.apache.log4j.Logger;
import org.seasar.s2click.control.DateFieldYYMMDD;
import org.seasar.s2click.control.DateFieldYYYYMMDD;
import org.seasar.s2click.example.page.BorderPage;

import net.sf.click.Context;
import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.extras.control.DateField;
import net.sf.click.extras.control.PageSubmit;

public class DatePage extends BorderPage{
	public Logger log = Logger.getLogger(this.getClass());
	public Form form = new Form();
	public String date1 = "";
	public String date2 = "";
	public DateFieldYYYYMMDD df1 = 
		new DateFieldYYYYMMDD("df1","YYYY/MM/DD",true);
	public DateFieldYYMMDD df2 = 
		new DateFieldYYMMDD("df2","YY/MM/DD",true);
	public  DatePage(){
		form.add(new DateField("stddate","標準 DateField"));
		form.add(df1);
		form.add(df2);
		form.add(new Submit("ok","下に表示",this,"onOkClicked"));
		form.add(new Submit("go","新画面に表示",this,"onGoClicked"));
		
	}
	private boolean processSubmit(){
		if (form.isValid()){
			DateFormat df = DateFormat.getDateInstance(DateFormat.LONG);
			if (df1.getValue().length() > 0){
				date1=df.format(df1.getDate());
				log.debug(df1.getDate().toString());
			}
			if (df2.getValue().length() > 0){
				date2=df.format(df2.getDate());
				log.debug(df2.getDate().toString());
			}
			return true;
		}
		return false;		
	}
	public boolean onOkClicked(){
		return processSubmit();
	}
	public boolean onGoClicked(){
		if (processSubmit()){
			getContext().setRequestAttribute("date1xx", date1);
			getContext().setRequestAttribute("date2xx", date2);
			setForward("/datefield/dateDisplay.htm");
		}
		return false;
	}
}
