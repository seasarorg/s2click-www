package org.seasar.s2click.example.dto;

import java.math.BigDecimal;
import java.util.Date;

public class EmployeeSearchDto {
	private String empno;
	private String empname;
	private String job;
	private String managerName;
	private BigDecimal managerId;
	private Date hiredateFrom;
	private Date hiredateTo;
	private BigDecimal salaryFrom;
	private BigDecimal salaryTo;
	private BigDecimal deptid;
	public BigDecimal getDeptid() {
		return deptid;
	}
	public void setDeptid(BigDecimal deptid) {
		this.deptid = deptid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmpno() {
		return empno;
	}
	public void setEmpno(String empno) {
		this.empno = empno;
	}
	public Date getHiredateFrom() {
		return hiredateFrom;
	}
	public void setHiredateFrom(Date hiredateFrom) {
		this.hiredateFrom = hiredateFrom;
	}
	public Date getHiredateTo() {
		return hiredateTo;
	}
	public void setHiredateTo(Date hiredateTo) {
		this.hiredateTo = hiredateTo;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public BigDecimal getSalaryFrom() {
		return salaryFrom;
	}
	public void setSalaryFrom(BigDecimal salaryFrom) {
		this.salaryFrom = salaryFrom;
	}
	public BigDecimal getSalaryTo() {
		return salaryTo;
	}
	public void setSalaryTo(BigDecimal salaryTo) {
		this.salaryTo = salaryTo;
	}
	public BigDecimal getManagerId() {
		return managerId;
	}
	public void setManagerId(BigDecimal managerId) {
		this.managerId = managerId;
	}

}
