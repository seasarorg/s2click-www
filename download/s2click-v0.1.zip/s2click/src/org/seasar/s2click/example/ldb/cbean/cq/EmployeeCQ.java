package org.seasar.s2click.example.ldb.cbean.cq;


import org.seasar.s2click.example.ldb.allcommon.cbean.*;
import org.seasar.s2click.example.ldb.allcommon.cbean.ckey.*;
import org.seasar.s2click.example.ldb.allcommon.cbean.cvalue.ConditionValue;
import org.seasar.s2click.example.ldb.allcommon.cbean.sqlclause.SqlClause;


/**
 * The condition-query of {table.Name}.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class EmployeeCQ extends AbstractConditionQuery {

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     * 
     * @param childQuery Child query as abstract class. (Nullable: If null, this is base instance.)
     * @param sqlClause SQL clause instance. (NotNull)
     * @param aliasName My alias name. (NotNull)
     * @param nestLevel Nest level.
     */
    public EmployeeCQ(ConditionQuery childQuery, SqlClause sqlClause, String aliasName, int nestLevel) {
        super(childQuery, sqlClause, aliasName, nestLevel);
    }

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    final public String getTableDbName() {
        return "employee";
    }

    // =====================================================================================
    //                                                                         IncludeAsMine
    //                                                                         =============
  
    /**
     * Include select-column of id as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Id() {
        return registerIncludedSelectColumn("Id", getRealColumnName("id"));
    }

    /**
     * Include select-column of id as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Id(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("id"));
    }
  
    /**
     * Include select-column of empno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Empno() {
        return registerIncludedSelectColumn("Empno", getRealColumnName("empno"));
    }

    /**
     * Include select-column of empno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Empno(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("empno"));
    }
  
    /**
     * Include select-column of empname as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Empname() {
        return registerIncludedSelectColumn("Empname", getRealColumnName("empname"));
    }

    /**
     * Include select-column of empname as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Empname(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("empname"));
    }
  
    /**
     * Include select-column of job as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Job() {
        return registerIncludedSelectColumn("Job", getRealColumnName("job"));
    }

    /**
     * Include select-column of job as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Job(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("job"));
    }
  
    /**
     * Include select-column of manager as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Manager() {
        return registerIncludedSelectColumn("Manager", getRealColumnName("manager"));
    }

    /**
     * Include select-column of manager as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Manager(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("manager"));
    }
  
    /**
     * Include select-column of hiredate as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Hiredate() {
        return registerIncludedSelectColumn("Hiredate", getRealColumnName("hiredate"));
    }

    /**
     * Include select-column of hiredate as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Hiredate(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("hiredate"));
    }
  
    /**
     * Include select-column of salary as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Salary() {
        return registerIncludedSelectColumn("Salary", getRealColumnName("salary"));
    }

    /**
     * Include select-column of salary as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Salary(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("salary"));
    }
  
    /**
     * Include select-column of deptid as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Deptid() {
        return registerIncludedSelectColumn("Deptid", getRealColumnName("deptid"));
    }

    /**
     * Include select-column of deptid as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Deptid(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("deptid"));
    }
  
    /**
     * Include select-column of versionno as mine.
     * Alias name is java-name of this column.
     * Be careful to whether your table have the same column.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Versionno() {
        return registerIncludedSelectColumn("Versionno", getRealColumnName("versionno"));
    }

    /**
     * Include select-column of versionno as mine.
     * 
     * @param aliasName Alias name. {select columnName as aliasName from ...} This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ includeAsMine_Versionno(String aliasName) {
        return registerIncludedSelectColumn(aliasName, getRealColumnName("versionno"));
    }
  
    /**
     * Register included-select-column.
     * 
     * @param aliasName Alias name. This should not contain comma. (NotNull)
     * @param realColumnName Real column name. This should not contain comma. (NotNull)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerIncludedSelectColumn(String aliasName, String realColumnName) {
        assertAliasName(aliasName);
        assertColumnName(realColumnName);
        getSqlClause().registerIncludedSelectColumn(aliasName, realColumnName);
        return this;
    }

    // =====================================================================================
    //                                                                                 Query
    //                                                                                 =====
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   MyTable = [employee]
    // * * * * * * * * */

      
    /** Column db name of id. */
    protected static final String COL_id = "id";

    /** Column java name of id. */
    protected static final String J_Id = "Id";

    /** Column uncapitalised java name of id. */
    protected static final String UJ_id = "id";

    /** The attribute of id. */
    protected ConditionValue _id;

    /**
     * Get the value of id.
     * 
     * @return The value of id.
     */
    public ConditionValue getId() {
        if (_id == null) {
            _id = new ConditionValue();
        }
        return _id;
    }
            
    /**
     * Set the value of id using equal. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_Equal(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of id using equal. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_Equal(long value) {
        return registerId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using equal as inline. { = }
     * 
     * @param value The value of id as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_Equal_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_NotEqual(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of id using notEqual. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_NotEqual(long value) {
        return registerId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using notEqual as inline. { != }
     * 
     * @param value The value of id as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_NotEqual_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterThan(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of id using greaterThan. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterThan(long value) {
        return registerId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterThan as inline. { &gt; }
     * 
     * @param value The value of id as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterThan_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessThan(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of id using lessThan. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessThan(long value) {
        return registerId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessThan as inline. { &lt; }
     * 
     * @param value The value of id as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessThan_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterEqual(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of id using greaterEqual. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterEqual(long value) {
        return registerId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of id as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_GreaterEqual_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessEqual(java.math.BigDecimal value) {
        return registerId(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineId(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of id using lessEqual. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessEqual(long value) {
        return registerId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of id as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_LessEqual_AsInline(long value) {
        return registerInlineId(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of id using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of id as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerId(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of id using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of id as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerId(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
              
    /** The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeSelfList;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery. (Nullable)
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeSelfList() {
        return _id_InScopeSubQuery_EmployeeSelfList;
    }

    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery.
     * { in (select xxx.manager from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query save the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_InScopeSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_InScopeSubQuery_EmployeeSelfList = subQuery;// for saving query-value.
        registerInScopeSubQuery(subQuery, COL_id, "manager", "id_InScopeSubQuery_EmployeeSelfList");
        return this;
    }

    /** The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline. */
    protected EmployeeCQ _id_InScopeSubQuery_EmployeeSelfList_AsInline;

    /**
     * Get the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline.
     * 
     * @return The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline. (Nullable)
     */
    public EmployeeCQ getId_InScopeSubQuery_EmployeeSelfList_AsInline() {
        return _id_InScopeSubQuery_EmployeeSelfList_AsInline;
    }

    /**
     * Set the sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline.
     * { in (select xxx.manager from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query save the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_InScopeSubQuery_EmployeeSelfList using inScopeSubQuery as inline. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_InScopeSubQuery_EmployeeSelfList_AsInline(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_InScopeSubQuery_EmployeeSelfList_AsInline = subQuery;// for saving query-value.
        registerInlineInScopeSubQuery(subQuery, COL_id, "manager", "id_InScopeSubQuery_EmployeeSelfList_AsInline");
        return this;
    }
                            
    /** The sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery. */
    protected EmployeeCQ _id_ExistsSubQuery_EmployeeSelfList;

    /**
     * Get the sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery.
     * 
     * @return The sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery. (Nullable)
     */
    public EmployeeCQ getId_ExistsSubQuery_EmployeeSelfList() {
        return _id_ExistsSubQuery_EmployeeSelfList;
    }

    /**
     * Set the sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery.
     * { exists (select xxx.manager from employee where ...) }
     * This method use from clause and where clause of the sub-query instance.
     * this query save the sub-query instance for query-value.
     * After you invoke this, If you set query in the argument[subQuery], the query is ignored.
     * 
     * @param subQuery The sub-query of Id_ExistsSubQuery_EmployeeSelfList using existsSubQuery. (NotNull)
     * @return this. (NotNull)
     */
    public EmployeeCQ setId_ExistsSubQuery_EmployeeSelfList(EmployeeCQ subQuery) {
        assertObjectNotNull("subQuery", subQuery);
        _id_ExistsSubQuery_EmployeeSelfList = subQuery;// for saving query-value.
        registerExistsSubQuery(subQuery, COL_id, "manager", "id_ExistsSubQuery_EmployeeSelfList");
        return this;
    }
                                      
    /**
     * Register condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerId(ConditionKey key, Object value) {
        if (key.isValidRegistration(getId(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Id")) {
            key.setupConditionValue(getId(), value, getLocation(UJ_id, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_id), key, getId());
        }
        return this;
    }

    /**
     * Register inline condition of id.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of id. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineId(ConditionKey key, Object value) {
        if (key.isValidRegistration(getId(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Id")) {
            key.setupConditionValue(getId(), value, getLocation(UJ_id, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_id, key, getId());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_id, key, getId());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of id as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Id_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, true);return this;
    }

    /**
     * Add order-by of id as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Id_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_id), null, false);return this;
    }
          
    /** Column db name of empno. */
    protected static final String COL_empno = "empno";

    /** Column java name of empno. */
    protected static final String J_Empno = "Empno";

    /** Column uncapitalised java name of empno. */
    protected static final String UJ_empno = "empno";

    /** The attribute of empno. */
    protected ConditionValue _empno;

    /**
     * Get the value of empno.
     * 
     * @return The value of empno.
     */
    public ConditionValue getEmpno() {
        if (_empno == null) {
            _empno = new ConditionValue();
        }
        return _empno;
    }
            
    /**
     * Set the value of empno using equal. { = }
     * 
     * @param value The value of empno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_Equal(java.math.BigDecimal value) {
        return registerEmpno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of empno using equal as inline. { = }
     * 
     * @param value The value of empno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineEmpno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of empno using equal. { = }
     * 
     * @param value The value of empno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_Equal(long value) {
        return registerEmpno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using equal as inline. { = }
     * 
     * @param value The value of empno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_Equal_AsInline(long value) {
        return registerInlineEmpno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of empno using notEqual. { != }
     * 
     * @param value The value of empno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_NotEqual(java.math.BigDecimal value) {
        return registerEmpno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of empno using notEqual as inline. { != }
     * 
     * @param value The value of empno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineEmpno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of empno using notEqual. { != }
     * 
     * @param value The value of empno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_NotEqual(long value) {
        return registerEmpno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using notEqual as inline. { != }
     * 
     * @param value The value of empno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_NotEqual_AsInline(long value) {
        return registerInlineEmpno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using greaterThan. { &gt; }
     * 
     * @param value The value of empno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterThan(java.math.BigDecimal value) {
        return registerEmpno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of empno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of empno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineEmpno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of empno using greaterThan. { &gt; }
     * 
     * @param value The value of empno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterThan(long value) {
        return registerEmpno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of empno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterThan_AsInline(long value) {
        return registerInlineEmpno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using lessThan. { &lt; }
     * 
     * @param value The value of empno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessThan(java.math.BigDecimal value) {
        return registerEmpno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of empno using lessThan as inline. { &lt; }
     * 
     * @param value The value of empno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineEmpno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of empno using lessThan. { &lt; }
     * 
     * @param value The value of empno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessThan(long value) {
        return registerEmpno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using lessThan as inline. { &lt; }
     * 
     * @param value The value of empno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessThan_AsInline(long value) {
        return registerInlineEmpno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using greaterEqual. { &gt;= }
     * 
     * @param value The value of empno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterEqual(java.math.BigDecimal value) {
        return registerEmpno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of empno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of empno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineEmpno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of empno using greaterEqual. { &gt;= }
     * 
     * @param value The value of empno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterEqual(long value) {
        return registerEmpno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of empno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_GreaterEqual_AsInline(long value) {
        return registerInlineEmpno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using lessEqual. { &lt;= }
     * 
     * @param value The value of empno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessEqual(java.math.BigDecimal value) {
        return registerEmpno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of empno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of empno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineEmpno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of empno using lessEqual. { &lt;= }
     * 
     * @param value The value of empno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessEqual(long value) {
        return registerEmpno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of empno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_LessEqual_AsInline(long value) {
        return registerInlineEmpno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of empno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empno as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerEmpno(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of empno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empno as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpno_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerEmpno(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
                                    
    /**
     * Register condition of empno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empno. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerEmpno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getEmpno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Empno")) {
            key.setupConditionValue(getEmpno(), value, getLocation(UJ_empno, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_empno), key, getEmpno());
        }
        return this;
    }

    /**
     * Register inline condition of empno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empno. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineEmpno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getEmpno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Empno")) {
            key.setupConditionValue(getEmpno(), value, getLocation(UJ_empno, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_empno, key, getEmpno());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_empno, key, getEmpno());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of empno as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Empno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empno), null, true);return this;
    }

    /**
     * Add order-by of empno as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Empno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empno), null, false);return this;
    }
          
    /** Column db name of empname. */
    protected static final String COL_empname = "empname";

    /** Column java name of empname. */
    protected static final String J_Empname = "Empname";

    /** Column uncapitalised java name of empname. */
    protected static final String UJ_empname = "empname";

    /** The attribute of empname. */
    protected ConditionValue _empname;

    /**
     * Get the value of empname.
     * 
     * @return The value of empname.
     */
    public ConditionValue getEmpname() {
        if (_empname == null) {
            _empname = new ConditionValue();
        }
        return _empname;
    }
    
    /**
     * Set the value of empname using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_Equal(String value) {
        return registerEmpname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_Equal_AsInline(String value) {
        return registerInlineEmpname(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the empty-string of empname as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_Equal_EmptyString() {
        return registerEmpname(ConditionKey.CK_EQUAL, "");
    }
      
    /**
     * Set the value of empname using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_NotEqual(String value) {
        return registerEmpname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_NotEqual_AsInline(String value) {
        return registerInlineEmpname(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_GreaterThan(String value) {
        return registerEmpname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_GreaterThan_AsInline(String value) {
        return registerInlineEmpname(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_LessThan(String value) {
        return registerEmpname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_LessThan_AsInline(String value) {
        return registerInlineEmpname(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_GreaterEqual(String value) {
        return registerEmpname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_GreaterEqual_AsInline(String value) {
        return registerInlineEmpname(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_LessEqual(String value) {
        return registerEmpname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_LessEqual_AsInline(String value) {
        return registerInlineEmpname(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as prefixSearch.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_PrefixSearch(String value) {
        return registerEmpname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of empname as prefixSearch.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_PrefixSearch_AsInline(String value) {
        return registerInlineEmpname(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of empname using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empname as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_InScope(java.util.List<String> valueList) {
        return registerEmpname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of empname using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empname as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_InScope_AsInline(java.util.List<String> valueList) {
        return registerInlineEmpname(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of empname using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empname as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_NotInScope(java.util.List<String> valueList) {
        return registerEmpname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of empname using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of empname as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setEmpname_NotInScope_AsInline(java.util.List<String> valueList) {
        return registerInlineEmpname(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                        
    /**
     * Register condition of empname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empname. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerEmpname(ConditionKey key, Object value) {
        if (key.isValidRegistration(getEmpname(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Empname")) {
            key.setupConditionValue(getEmpname(), value, getLocation(UJ_empname, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_empname), key, getEmpname());
        }
        return this;
    }

    /**
     * Register inline condition of empname.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of empname. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineEmpname(ConditionKey key, Object value) {
        if (key.isValidRegistration(getEmpname(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Empname")) {
            key.setupConditionValue(getEmpname(), value, getLocation(UJ_empname, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_empname, key, getEmpname());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_empname, key, getEmpname());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of empname as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Empname_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empname), null, true);return this;
    }

    /**
     * Add order-by of empname as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Empname_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_empname), null, false);return this;
    }
          
    /** Column db name of job. */
    protected static final String COL_job = "job";

    /** Column java name of job. */
    protected static final String J_Job = "Job";

    /** Column uncapitalised java name of job. */
    protected static final String UJ_job = "job";

    /** The attribute of job. */
    protected ConditionValue _job;

    /**
     * Get the value of job.
     * 
     * @return The value of job.
     */
    public ConditionValue getJob() {
        if (_job == null) {
            _job = new ConditionValue();
        }
        return _job;
    }
    
    /**
     * Set the value of job using equal. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_Equal(String value) {
        return registerJob(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using equal as inline. { = }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_Equal_AsInline(String value) {
        return registerInlineJob(ConditionKey.CK_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the empty-string of job as equal. { = }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_Equal_EmptyString() {
        return registerJob(ConditionKey.CK_EQUAL, "");
    }
      
    /**
     * Set the value of job using notEqual. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_NotEqual(String value) {
        return registerJob(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using notEqual as inline. { != }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_NotEqual_AsInline(String value) {
        return registerInlineJob(ConditionKey.CK_NOT_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using greaterThan. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_GreaterThan(String value) {
        return registerJob(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using greaterThan as inline. { &gt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_GreaterThan_AsInline(String value) {
        return registerInlineJob(ConditionKey.CK_GREATER_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using lessThan. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_LessThan(String value) {
        return registerJob(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using lessThan as inline. { &lt; }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_LessThan_AsInline(String value) {
        return registerInlineJob(ConditionKey.CK_LESS_THAN, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using greaterEqual. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_GreaterEqual(String value) {
        return registerJob(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using greaterEqual as inline. { &gt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_GreaterEqual_AsInline(String value) {
        return registerInlineJob(ConditionKey.CK_GREATER_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using lessEqual. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_LessEqual(String value) {
        return registerJob(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using lessEqual as inline. { &lt;= }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_LessEqual_AsInline(String value) {
        return registerInlineJob(ConditionKey.CK_LESS_EQUAL, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using prefixSearch. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as prefixSearch.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_PrefixSearch(String value) {
        return registerJob(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using prefixSearch as inline. { like 'xxx%' }
     * If the value is null or empty-string, this condition is ignored.
     * 
     * @param value The value of job as prefixSearch.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_PrefixSearch_AsInline(String value) {
        return registerInlineJob(ConditionKey.CK_PREFIX_SEARCH, filterRemoveEmptyString(value));
    }

    /**
     * Set the value of job using inScope. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of job as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_InScope(java.util.List<String> valueList) {
        return registerJob(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of job using inScope as inline. { in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of job as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_InScope_AsInline(java.util.List<String> valueList) {
        return registerInlineJob(ConditionKey.CK_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of job using notInScope. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of job as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_NotInScope(java.util.List<String> valueList) {
        return registerJob(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }

    /**
     * Set the value of job using notInScope as inline. { not in ('a', 'b') }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of job as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setJob_NotInScope_AsInline(java.util.List<String> valueList) {
        return registerInlineJob(ConditionKey.CK_NOT_IN_SCOPE, filterRemoveEmptyStringFromList(valueList));
    }
                                        
    /**
     * Register condition of job.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of job. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerJob(ConditionKey key, Object value) {
        if (key.isValidRegistration(getJob(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Job")) {
            key.setupConditionValue(getJob(), value, getLocation(UJ_job, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_job), key, getJob());
        }
        return this;
    }

    /**
     * Register inline condition of job.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of job. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineJob(ConditionKey key, Object value) {
        if (key.isValidRegistration(getJob(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Job")) {
            key.setupConditionValue(getJob(), value, getLocation(UJ_job, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_job, key, getJob());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_job, key, getJob());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of job as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Job_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_job), null, true);return this;
    }

    /**
     * Add order-by of job as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Job_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_job), null, false);return this;
    }
          
    /** Column db name of manager. */
    protected static final String COL_manager = "manager";

    /** Column java name of manager. */
    protected static final String J_Manager = "Manager";

    /** Column uncapitalised java name of manager. */
    protected static final String UJ_manager = "manager";

    /** The attribute of manager. */
    protected ConditionValue _manager;

    /**
     * Get the value of manager.
     * 
     * @return The value of manager.
     */
    public ConditionValue getManager() {
        if (_manager == null) {
            _manager = new ConditionValue();
        }
        return _manager;
    }
            
    /**
     * Set the value of manager using equal. { = }
     * 
     * @param value The value of manager as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_Equal(java.math.BigDecimal value) {
        return registerManager(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of manager using equal as inline. { = }
     * 
     * @param value The value of manager as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineManager(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of manager using equal. { = }
     * 
     * @param value The value of manager as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_Equal(long value) {
        return registerManager(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using equal as inline. { = }
     * 
     * @param value The value of manager as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_Equal_AsInline(long value) {
        return registerInlineManager(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of manager using notEqual. { != }
     * 
     * @param value The value of manager as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_NotEqual(java.math.BigDecimal value) {
        return registerManager(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of manager using notEqual as inline. { != }
     * 
     * @param value The value of manager as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineManager(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of manager using notEqual. { != }
     * 
     * @param value The value of manager as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_NotEqual(long value) {
        return registerManager(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using notEqual as inline. { != }
     * 
     * @param value The value of manager as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_NotEqual_AsInline(long value) {
        return registerInlineManager(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using greaterThan. { &gt; }
     * 
     * @param value The value of manager as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterThan(java.math.BigDecimal value) {
        return registerManager(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of manager using greaterThan as inline. { &gt; }
     * 
     * @param value The value of manager as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineManager(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of manager using greaterThan. { &gt; }
     * 
     * @param value The value of manager as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterThan(long value) {
        return registerManager(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using greaterThan as inline. { &gt; }
     * 
     * @param value The value of manager as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterThan_AsInline(long value) {
        return registerInlineManager(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using lessThan. { &lt; }
     * 
     * @param value The value of manager as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessThan(java.math.BigDecimal value) {
        return registerManager(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of manager using lessThan as inline. { &lt; }
     * 
     * @param value The value of manager as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineManager(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of manager using lessThan. { &lt; }
     * 
     * @param value The value of manager as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessThan(long value) {
        return registerManager(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using lessThan as inline. { &lt; }
     * 
     * @param value The value of manager as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessThan_AsInline(long value) {
        return registerInlineManager(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using greaterEqual. { &gt;= }
     * 
     * @param value The value of manager as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterEqual(java.math.BigDecimal value) {
        return registerManager(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of manager using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of manager as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineManager(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of manager using greaterEqual. { &gt;= }
     * 
     * @param value The value of manager as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterEqual(long value) {
        return registerManager(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of manager as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_GreaterEqual_AsInline(long value) {
        return registerInlineManager(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using lessEqual. { &lt;= }
     * 
     * @param value The value of manager as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessEqual(java.math.BigDecimal value) {
        return registerManager(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of manager using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of manager as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineManager(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of manager using lessEqual. { &lt;= }
     * 
     * @param value The value of manager as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessEqual(long value) {
        return registerManager(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of manager as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_LessEqual_AsInline(long value) {
        return registerInlineManager(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of manager using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of manager as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerManager(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of manager using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of manager as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerManager(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
                                
    /**
     * Set the value of manager using isNull. { is null }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_IsNull() {
        return registerManager(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of manager using isNotNull. { is not null }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setManager_IsNotNull() {
        return registerManager(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of manager.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of manager. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerManager(ConditionKey key, Object value) {
        if (key.isValidRegistration(getManager(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Manager")) {
            key.setupConditionValue(getManager(), value, getLocation(UJ_manager, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_manager), key, getManager());
        }
        return this;
    }

    /**
     * Register inline condition of manager.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of manager. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineManager(ConditionKey key, Object value) {
        if (key.isValidRegistration(getManager(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Manager")) {
            key.setupConditionValue(getManager(), value, getLocation(UJ_manager, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_manager, key, getManager());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_manager, key, getManager());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of manager as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Manager_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_manager), null, true);return this;
    }

    /**
     * Add order-by of manager as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Manager_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_manager), null, false);return this;
    }
          
    /** Column db name of hiredate. */
    protected static final String COL_hiredate = "hiredate";

    /** Column java name of hiredate. */
    protected static final String J_Hiredate = "Hiredate";

    /** Column uncapitalised java name of hiredate. */
    protected static final String UJ_hiredate = "hiredate";

    /** The attribute of hiredate. */
    protected ConditionValue _hiredate;

    /**
     * Get the value of hiredate.
     * 
     * @return The value of hiredate.
     */
    public ConditionValue getHiredate() {
        if (_hiredate == null) {
            _hiredate = new ConditionValue();
        }
        return _hiredate;
    }
                
    /**
     * Set the value of hiredate using equal. { = }
     * 
     * @param value The value of hiredate as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_Equal(java.util.Date value) {
        return registerHiredate(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of hiredate using equal as inline. { = }
     * 
     * @param value The value of hiredate as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_Equal_AsInline(java.util.Date value) {
        return registerInlineHiredate(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of hiredate using notEqual. { != }
     * 
     * @param value The value of hiredate as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_NotEqual(java.util.Date value) {
        return registerHiredate(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of hiredate using notEqual as inline. { != }
     * 
     * @param value The value of hiredate as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_NotEqual_AsInline(java.util.Date value) {
        return registerInlineHiredate(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of hiredate using greaterThan. { &gt; }
     * 
     * @param value The value of hiredate as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_GreaterThan(java.util.Date value) {
        return registerHiredate(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of hiredate using greaterThan as inline. { &gt; }
     * 
     * @param value The value of hiredate as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_GreaterThan_AsInline(java.util.Date value) {
        return registerInlineHiredate(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of hiredate using lessThan. { &lt; }
     * 
     * @param value The value of hiredate as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_LessThan(java.util.Date value) {
        return registerHiredate(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of hiredate using lessThan as inline. { &lt; }
     * 
     * @param value The value of hiredate as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_LessThan_AsInline(java.util.Date value) {
        return registerInlineHiredate(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of hiredate using greaterEqual. { &gt;= }
     * 
     * @param value The value of hiredate as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_GreaterEqual(java.util.Date value) {
        return registerHiredate(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of hiredate using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of hiredate as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_GreaterEqual_AsInline(java.util.Date value) {
        return registerInlineHiredate(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of hiredate using lessEqual. { &lt;= }
     * 
     * @param value The value of hiredate as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_LessEqual(java.util.Date value) {
        return registerHiredate(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of hiredate using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of hiredate as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setHiredate_LessEqual_AsInline(java.util.Date value) {
        return registerInlineHiredate(ConditionKey.CK_LESS_EQUAL, value);
    }
                    
    /**
     * Register condition of hiredate.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of hiredate. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerHiredate(ConditionKey key, Object value) {
        if (key.isValidRegistration(getHiredate(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Hiredate")) {
            key.setupConditionValue(getHiredate(), value, getLocation(UJ_hiredate, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_hiredate), key, getHiredate());
        }
        return this;
    }

    /**
     * Register inline condition of hiredate.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of hiredate. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineHiredate(ConditionKey key, Object value) {
        if (key.isValidRegistration(getHiredate(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Hiredate")) {
            key.setupConditionValue(getHiredate(), value, getLocation(UJ_hiredate, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_hiredate, key, getHiredate());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_hiredate, key, getHiredate());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of hiredate as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Hiredate_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_hiredate), null, true);return this;
    }

    /**
     * Add order-by of hiredate as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Hiredate_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_hiredate), null, false);return this;
    }
          
    /** Column db name of salary. */
    protected static final String COL_salary = "salary";

    /** Column java name of salary. */
    protected static final String J_Salary = "Salary";

    /** Column uncapitalised java name of salary. */
    protected static final String UJ_salary = "salary";

    /** The attribute of salary. */
    protected ConditionValue _salary;

    /**
     * Get the value of salary.
     * 
     * @return The value of salary.
     */
    public ConditionValue getSalary() {
        if (_salary == null) {
            _salary = new ConditionValue();
        }
        return _salary;
    }
            
    /**
     * Set the value of salary using equal. { = }
     * 
     * @param value The value of salary as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_Equal(java.math.BigDecimal value) {
        return registerSalary(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of salary using equal as inline. { = }
     * 
     * @param value The value of salary as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineSalary(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of salary using equal. { = }
     * 
     * @param value The value of salary as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_Equal(long value) {
        return registerSalary(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using equal as inline. { = }
     * 
     * @param value The value of salary as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_Equal_AsInline(long value) {
        return registerInlineSalary(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of salary using notEqual. { != }
     * 
     * @param value The value of salary as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_NotEqual(java.math.BigDecimal value) {
        return registerSalary(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of salary using notEqual as inline. { != }
     * 
     * @param value The value of salary as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineSalary(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of salary using notEqual. { != }
     * 
     * @param value The value of salary as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_NotEqual(long value) {
        return registerSalary(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using notEqual as inline. { != }
     * 
     * @param value The value of salary as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_NotEqual_AsInline(long value) {
        return registerInlineSalary(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using greaterThan. { &gt; }
     * 
     * @param value The value of salary as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterThan(java.math.BigDecimal value) {
        return registerSalary(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of salary using greaterThan as inline. { &gt; }
     * 
     * @param value The value of salary as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineSalary(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of salary using greaterThan. { &gt; }
     * 
     * @param value The value of salary as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterThan(long value) {
        return registerSalary(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using greaterThan as inline. { &gt; }
     * 
     * @param value The value of salary as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterThan_AsInline(long value) {
        return registerInlineSalary(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using lessThan. { &lt; }
     * 
     * @param value The value of salary as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessThan(java.math.BigDecimal value) {
        return registerSalary(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of salary using lessThan as inline. { &lt; }
     * 
     * @param value The value of salary as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineSalary(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of salary using lessThan. { &lt; }
     * 
     * @param value The value of salary as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessThan(long value) {
        return registerSalary(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using lessThan as inline. { &lt; }
     * 
     * @param value The value of salary as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessThan_AsInline(long value) {
        return registerInlineSalary(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using greaterEqual. { &gt;= }
     * 
     * @param value The value of salary as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterEqual(java.math.BigDecimal value) {
        return registerSalary(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of salary using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of salary as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineSalary(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of salary using greaterEqual. { &gt;= }
     * 
     * @param value The value of salary as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterEqual(long value) {
        return registerSalary(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of salary as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_GreaterEqual_AsInline(long value) {
        return registerInlineSalary(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using lessEqual. { &lt;= }
     * 
     * @param value The value of salary as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessEqual(java.math.BigDecimal value) {
        return registerSalary(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of salary using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of salary as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineSalary(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of salary using lessEqual. { &lt;= }
     * 
     * @param value The value of salary as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessEqual(long value) {
        return registerSalary(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of salary as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_LessEqual_AsInline(long value) {
        return registerInlineSalary(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of salary using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of salary as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerSalary(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of salary using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of salary as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerSalary(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
                                
    /**
     * Set the value of salary using isNull. { is null }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_IsNull() {
        return registerSalary(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of salary using isNotNull. { is not null }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setSalary_IsNotNull() {
        return registerSalary(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of salary.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of salary. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerSalary(ConditionKey key, Object value) {
        if (key.isValidRegistration(getSalary(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Salary")) {
            key.setupConditionValue(getSalary(), value, getLocation(UJ_salary, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_salary), key, getSalary());
        }
        return this;
    }

    /**
     * Register inline condition of salary.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of salary. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineSalary(ConditionKey key, Object value) {
        if (key.isValidRegistration(getSalary(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Salary")) {
            key.setupConditionValue(getSalary(), value, getLocation(UJ_salary, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_salary, key, getSalary());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_salary, key, getSalary());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of salary as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Salary_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_salary), null, true);return this;
    }

    /**
     * Add order-by of salary as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Salary_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_salary), null, false);return this;
    }
          
    /** Column db name of deptid. */
    protected static final String COL_deptid = "deptid";

    /** Column java name of deptid. */
    protected static final String J_Deptid = "Deptid";

    /** Column uncapitalised java name of deptid. */
    protected static final String UJ_deptid = "deptid";

    /** The attribute of deptid. */
    protected ConditionValue _deptid;

    /**
     * Get the value of deptid.
     * 
     * @return The value of deptid.
     */
    public ConditionValue getDeptid() {
        if (_deptid == null) {
            _deptid = new ConditionValue();
        }
        return _deptid;
    }
            
    /**
     * Set the value of deptid using equal. { = }
     * 
     * @param value The value of deptid as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_Equal(java.math.BigDecimal value) {
        return registerDeptid(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of deptid using equal as inline. { = }
     * 
     * @param value The value of deptid as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptid(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of deptid using equal. { = }
     * 
     * @param value The value of deptid as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_Equal(long value) {
        return registerDeptid(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using equal as inline. { = }
     * 
     * @param value The value of deptid as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_Equal_AsInline(long value) {
        return registerInlineDeptid(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of deptid using notEqual. { != }
     * 
     * @param value The value of deptid as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_NotEqual(java.math.BigDecimal value) {
        return registerDeptid(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of deptid using notEqual as inline. { != }
     * 
     * @param value The value of deptid as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptid(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of deptid using notEqual. { != }
     * 
     * @param value The value of deptid as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_NotEqual(long value) {
        return registerDeptid(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using notEqual as inline. { != }
     * 
     * @param value The value of deptid as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_NotEqual_AsInline(long value) {
        return registerInlineDeptid(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using greaterThan. { &gt; }
     * 
     * @param value The value of deptid as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterThan(java.math.BigDecimal value) {
        return registerDeptid(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of deptid using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptid as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptid(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of deptid using greaterThan. { &gt; }
     * 
     * @param value The value of deptid as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterThan(long value) {
        return registerDeptid(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using greaterThan as inline. { &gt; }
     * 
     * @param value The value of deptid as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterThan_AsInline(long value) {
        return registerInlineDeptid(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using lessThan. { &lt; }
     * 
     * @param value The value of deptid as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessThan(java.math.BigDecimal value) {
        return registerDeptid(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of deptid using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptid as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptid(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of deptid using lessThan. { &lt; }
     * 
     * @param value The value of deptid as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessThan(long value) {
        return registerDeptid(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using lessThan as inline. { &lt; }
     * 
     * @param value The value of deptid as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessThan_AsInline(long value) {
        return registerInlineDeptid(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using greaterEqual. { &gt;= }
     * 
     * @param value The value of deptid as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterEqual(java.math.BigDecimal value) {
        return registerDeptid(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of deptid using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptid as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptid(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of deptid using greaterEqual. { &gt;= }
     * 
     * @param value The value of deptid as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterEqual(long value) {
        return registerDeptid(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of deptid as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_GreaterEqual_AsInline(long value) {
        return registerInlineDeptid(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using lessEqual. { &lt;= }
     * 
     * @param value The value of deptid as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessEqual(java.math.BigDecimal value) {
        return registerDeptid(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of deptid using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptid as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineDeptid(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of deptid using lessEqual. { &lt;= }
     * 
     * @param value The value of deptid as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessEqual(long value) {
        return registerDeptid(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of deptid as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_LessEqual_AsInline(long value) {
        return registerInlineDeptid(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of deptid using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptid as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerDeptid(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of deptid using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of deptid as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerDeptid(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
                                
    /**
     * Set the value of deptid using isNull. { is null }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_IsNull() {
        return registerDeptid(ConditionKey.CK_IS_NULL, DUMMY_OBJECT);
    }

    /**
     * Set the value of deptid using isNotNull. { is not null }
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ setDeptid_IsNotNull() {
        return registerDeptid(ConditionKey.CK_IS_NOT_NULL, DUMMY_OBJECT);
    }
        
    /**
     * Register condition of deptid.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptid. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerDeptid(ConditionKey key, Object value) {
        if (key.isValidRegistration(getDeptid(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Deptid")) {
            key.setupConditionValue(getDeptid(), value, getLocation(UJ_deptid, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_deptid), key, getDeptid());
        }
        return this;
    }

    /**
     * Register inline condition of deptid.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of deptid. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineDeptid(ConditionKey key, Object value) {
        if (key.isValidRegistration(getDeptid(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Deptid")) {
            key.setupConditionValue(getDeptid(), value, getLocation(UJ_deptid, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_deptid, key, getDeptid());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_deptid, key, getDeptid());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of deptid as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Deptid_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptid), null, true);return this;
    }

    /**
     * Add order-by of deptid as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Deptid_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_deptid), null, false);return this;
    }
          
    /** Column db name of versionno. */
    protected static final String COL_versionno = "versionno";

    /** Column java name of versionno. */
    protected static final String J_Versionno = "Versionno";

    /** Column uncapitalised java name of versionno. */
    protected static final String UJ_versionno = "versionno";

    /** The attribute of versionno. */
    protected ConditionValue _versionno;

    /**
     * Get the value of versionno.
     * 
     * @return The value of versionno.
     */
    public ConditionValue getVersionno() {
        if (_versionno == null) {
            _versionno = new ConditionValue();
        }
        return _versionno;
    }
            
    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_Equal(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_Equal_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_EQUAL, value);
    }

    /**
     * Set the value of versionno using equal. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_Equal(long value) {
        return registerVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using equal as inline. { = }
     * 
     * @param value The value of versionno as equal.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_Equal_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }
      
    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_NotEqual(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_NotEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, value);
    }

    /**
     * Set the value of versionno using notEqual. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_NotEqual(long value) {
        return registerVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using notEqual as inline. { != }
     * 
     * @param value The value of versionno as notEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_NotEqual_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_NOT_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterThan(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterThan_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_THAN, value);
    }

    /**
     * Set the value of versionno using greaterThan. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterThan(long value) {
        return registerVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterThan as inline. { &gt; }
     * 
     * @param value The value of versionno as greaterThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterThan_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessThan(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessThan_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_THAN, value);
    }

    /**
     * Set the value of versionno using lessThan. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessThan(long value) {
        return registerVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessThan as inline. { &lt; }
     * 
     * @param value The value of versionno as lessThan.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessThan_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_THAN, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterEqual(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, value);
    }

    /**
     * Set the value of versionno using greaterEqual. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterEqual(long value) {
        return registerVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using greaterEqual as inline. { &gt;= }
     * 
     * @param value The value of versionno as greaterEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_GreaterEqual_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_GREATER_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessEqual(java.math.BigDecimal value) {
        return registerVersionno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessEqual_AsInline(java.math.BigDecimal value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, value);
    }

    /**
     * Set the value of versionno using lessEqual. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessEqual(long value) {
        return registerVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using lessEqual as inline. { &lt;= }
     * 
     * @param value The value of versionno as lessEqual.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_LessEqual_AsInline(long value) {
        return registerInlineVersionno(ConditionKey.CK_LESS_EQUAL, new java.math.BigDecimal(String.valueOf(value)));
    }

    /**
     * Set the value of versionno using inScope. { in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of versionno as inScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_InScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerVersionno(ConditionKey.CK_IN_SCOPE, valueList);
    }

    /**
     * Set the value of versionno using notInScope. { not in (a, b) }
     * If the element in the list is null or empty-string, the condition-element is ignored.
     * 
     * @param valueList The value of versionno as notInScope.
     * @return this. (NotNull)
     */
    public EmployeeCQ setVersionno_NotInScope(java.util.List<java.math.BigDecimal> valueList) {
        return registerVersionno(ConditionKey.CK_NOT_IN_SCOPE, valueList);
    }
                                    
    /**
     * Register condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerVersionno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getVersionno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Versionno")) {
            key.setupConditionValue(getVersionno(), value, getLocation(UJ_versionno, key));// If Java, UncapProp!
            getSqlClause().registerWhereClause(getRealColumnName(COL_versionno), key, getVersionno());
        }
        return this;
    }

    /**
     * Register inline condition of versionno.
     * 
     * @param key Condition key. (NotNull)
     * @param value The value of versionno. (Nullable)
     * @return this. (NotNull)
     */
    protected EmployeeCQ registerInlineVersionno(ConditionKey key, Object value) {
        if (key.isValidRegistration(getVersionno(), value, key.getConditionKey() + " of " + getRealAliasName() + ".Versionno")) {
            key.setupConditionValue(getVersionno(), value, getLocation(UJ_versionno, key));// If Java, UncapProp!
            if (isBaseQuery(this)) {
                getSqlClause().registerBaseTableInlineWhereClause(COL_versionno, key, getVersionno());
            } else {
                getSqlClause().registerOuterJoinInlineWhereClause(getRealAliasName(), COL_versionno, key, getVersionno());
            }
        }
        return this;
    }
    
    /**
     * Add order-by of versionno as ASC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Versionno_Asc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, true);return this;
    }

    /**
     * Add order-by of versionno as DESC.
     * 
     * @return this. (NotNull)
     */
    public EmployeeCQ addOrderBy_Versionno_Desc() {
        getSqlClause().registerOrderBy(getRealColumnName(COL_versionno), null, false);return this;
    }
      
    // =====================================================================================
    //                                                               Query-SetupOuter-Method
    //                                                               =======================

      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [dept]
    //   ForeignProperty = [dept]
    // * * * * * * * * */

    /**
     * Query for dept.
     * 
     * @return Instance of DeptCQ as dept. (NotNull)
     */
    public DeptCQ queryDept() {
        return getConditionQueryDept();
    }

    /**
     * Setup outer join for ${foreignPropertyName}.
     */
    public void setupOuterJoin_Dept() {
        final java.util.Map<String, String> joinOnMap = new java.util.LinkedHashMap<String, String>();
        String key = null;
        String value = null;
    
        key = getRealColumnName("deptid");
        value = getConditionQueryDept().getRealColumnName("id");
        joinOnMap.put(key, value);
    
        final String joinTableName = "dept";
        final String aliasName = getConditionQueryDept().getRealAliasName();
        getSqlClause().registerOuterJoin(joinTableName, aliasName, joinOnMap);
    }

    /** Condition-query for dept. */
    protected DeptCQ _conditionQueryDept;

    /**
     * Get condition-query for dept.
     * 
     * @return Instance of DeptCQ as dept. (NotNull)
     */
    public DeptCQ getConditionQueryDept() {
        if (_conditionQueryDept == null) {
            _conditionQueryDept = newQueryDept();
            setupOuterJoin_Dept();
        }
        return _conditionQueryDept;
    }

    /**
     * New query for dept.
     * 
     * @return Query for dept. (NotNull)
     */
    protected DeptCQ newQueryDept() {
        return new DeptCQ(this, getSqlClause(), "Dept", getNextNestLevel());
    }
      
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ForeignTable    = [employee]
    //   ForeignProperty = [employeeSelf]
    // * * * * * * * * */

    /**
     * Query for employeeSelf.
     * 
     * @return Instance of EmployeeCQ as employeeSelf. (NotNull)
     */
    public EmployeeCQ queryEmployeeSelf() {
        return getConditionQueryEmployeeSelf();
    }

    /**
     * Setup outer join for ${foreignPropertyName}.
     */
    public void setupOuterJoin_EmployeeSelf() {
        final java.util.Map<String, String> joinOnMap = new java.util.LinkedHashMap<String, String>();
        String key = null;
        String value = null;
    
        key = getRealColumnName("manager");
        value = getConditionQueryEmployeeSelf().getRealColumnName("id");
        joinOnMap.put(key, value);
    
        final String joinTableName = "employee";
        final String aliasName = getConditionQueryEmployeeSelf().getRealAliasName();
        getSqlClause().registerOuterJoin(joinTableName, aliasName, joinOnMap);
    }

    /** Condition-query for employeeSelf. */
    protected EmployeeCQ _conditionQueryEmployeeSelf;

    /**
     * Get condition-query for employeeSelf.
     * 
     * @return Instance of EmployeeCQ as employeeSelf. (NotNull)
     */
    public EmployeeCQ getConditionQueryEmployeeSelf() {
        if (_conditionQueryEmployeeSelf == null) {
            _conditionQueryEmployeeSelf = newQueryEmployeeSelf();
            setupOuterJoin_EmployeeSelf();
        }
        return _conditionQueryEmployeeSelf;
    }

    /**
     * New query for employeeSelf.
     * 
     * @return Query for employeeSelf. (NotNull)
     */
    protected EmployeeCQ newQueryEmployeeSelf() {
        return new EmployeeCQ(this, getSqlClause(), "EmployeeSelf", getNextNestLevel());
    }
  
        
    // =====================================================================================
    //                                                                                Helper
    //                                                                                ======
    /**
     * Filter removing empty-string.
     * If the value is null or empty-string, returns null.
     * 
     * @param value Query-value-string. (Nullable)
     * @return Filtered value. (Nullable)
     */
    protected String filterRemoveEmptyString(String value) {
        return ((value != null && !"".equals(value)) ? value : null);
    }

    /**
     * Filter removing empty-string from the list.
     * If the list is null or empty-string, returns null.
     * 
     * @param ls List. (Nullable)
     * @return Filtered list. (Nullable)
     */
    protected java.util.List<String> filterRemoveEmptyStringFromList(java.util.List<String> ls) {
        if (ls == null) {
            return null;
        }
        java.util.List<String> newList = new java.util.ArrayList<String>();
        for (final java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final String str = (String)ite.next();
            if ("".equals(str)) {
                continue;
            }
            newList.add(str);
        }
        return newList;
    }

    // =====================================================================================
    //                                                                 Basic-Override Method
    //                                                                 =====================
    /**
     * This method overrides the method that is declared at super.
     * 
     * @return Clause string. (NotNull)
     */
    public String toString() {
        return getSqlClause().getClause();
    }
}
