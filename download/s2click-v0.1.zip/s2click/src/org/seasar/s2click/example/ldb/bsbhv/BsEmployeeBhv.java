
package org.seasar.s2click.example.ldb.bsbhv;

import org.seasar.s2click.example.ldb.allcommon.*;
import org.seasar.s2click.example.ldb.allcommon.cbean.ConditionBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.ListResultBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.PagingBean;
import org.seasar.s2click.example.ldb.allcommon.cbean.PagingResultBean;
import org.seasar.s2click.example.ldb.allcommon.dbmeta.DBMeta;
  
import org.seasar.s2click.example.ldb.exbhv.*;
  
import org.seasar.s2click.example.ldb.exdao.*;
import org.seasar.s2click.example.ldb.exentity.*;
import org.seasar.s2click.example.ldb.bsentity.dbmeta.*;
import org.seasar.s2click.example.ldb.cbean.*;



/**
 * The behavior of employee.
 * 
 * @author DBFlute(AutoGenerator)
 */
public abstract class BsEmployeeBhv extends org.seasar.s2click.example.ldb.allcommon.bhv.AbstractBehaviorWritable {

    // =====================================================================================
    //                                                                             Attribute
    //                                                                             =========
    /** Dao instance. */
    protected EmployeeDao _dao;

    // =====================================================================================
    //                                                                           Constructor
    //                                                                           ===========
    /**
     * Constructor.
     */
    public BsEmployeeBhv() {
    }

    // =====================================================================================
    //                                                                            Table name
    //                                                                            ==========
    /**
     * This method implements the method that is declared at super.
     * 
     * @return Table db-name. (NotNull)
     */
    public String getTableDbName() {
        return "employee";
    }

    // =====================================================================================
    //                                                                                DBMeta
    //                                                                                ======
    /**
     * This method implements the method that is declared at super.
     * 
     * @return DBMeta. (NotNull)
     */
    public DBMeta getDBMeta() {
        return EmployeeDbm.getInstance();
    }

    /**
     * Get my dbmeta.
     * 
     * @return DBMeta. (NotNull)
     */
    public EmployeeDbm getMyDBMeta() {
        return EmployeeDbm.getInstance();
    }

    // =====================================================================================
    //                                                                              Accessor
    //                                                                              ========
    /**
     * Get my dao.
     * 
     * @return My dao.
     */
    public EmployeeDao getMyDao() {
        return _dao;
    }

    /**
     * Set my dao.
     * 
     * @param dao My dao. (NotNull)
     */
    public void setMyDao(EmployeeDao dao) {
        assertObjectNotNull("dao", dao);
        _dao = dao;
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Dao-readable. (NotNull)
     */
    public DaoReadable getDaoReadable() {
        return getMyDao();
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @return Dao-writable. (NotNull)
     */
    public DaoWritable getDaoWritable() {
        return getMyDao();
    }

    // =====================================================================================
    //                                                                          New Instance
    //                                                                          ============
    /**
     * New condition-bean.
     * 
     * @return Condition-bean. (NotNull)
     */
    public ConditionBean newConditionBean() {
        return newMyConditionBean();
    }

    /**
     * New my condition-bean.
     * 
     * @return My condition-bean. (NotNull)
     */
    public EmployeeCB newMyConditionBean() {
        return new EmployeeCB();
    }

    // =====================================================================================
    //                                                                       Delegate Method
    //                                                                       ===============
    /**
     * Get count as all. (Delegate-Method)
     * 
     * @return All count. (NotNull)
     */
    public int delegateGetCountAll() {
        return getMyDao().getCountAll();
    }

    /**
     * Get list as all. (Delegate-Method)
     * 
     * @return All list. (NotNull)
     */
    public java.util.List<Employee> delegateGetListAll() {
        return getMyDao().getListAll();
    }

    //
    // Get entity. (Delegate-Method)
    // 
    // @param Primary-keys (NotNull)
    // @return Entity. (NotNull)
    //
    public Employee delegateGetEntity(java.math.BigDecimal id) {
        return getMyDao().getEntity(id);
    }

    /**
     * Select count by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected count. (NotNull)
     */
    public int delegateSelectCountIgnoreFetchScope(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectCountIgnoreFetchScope(cb);
    }

    /**
     * Select entity by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected entity. If the select result is zero, it returns null. (Nullable)
     */
    public Employee delegateSelectEntity(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectEntity(cb);
    }

    /**
     * Select list by condition-bean. (Delegate-Method)
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected list. If the select result is zero, it returns empty list. (NotNull)
     */
    public java.util.List<Employee> delegateSelectList(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return getMyDao().selectList(cb);
    }



    /**
     * Insert one entity. (Delegate-Method)
     * 
     * @param entity Entity. (NotNull)
     * @return Inserted count.
     */
    public int delegateInsert(Employee entity) {
        assertEntityNotNull(entity);// If this table use identity, the entity does not have primary-key.
        filterEntityOfInsert(entity);
        assertEntityOfInsert(entity);
        return getMyDao().insert(entity);
    }

    /**
     * Update one entity. (Delegate-Method)
     * 
     * @param entity Entity. (NotNull)
     * @return Updated count.
     */
    public int delegateUpdate(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        filterEntityOfUpdate(entity);
        assertEntityOfUpdate(entity);
        return getMyDao().update(entity);
    }

    /**
     * Delete one entity. (Delegate-Method)
     * 
     * @param entity Entity. (NotNull)
     * @return Deleted count.
     */
    public int delegateDelete(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        filterEntityOfDelete(entity);
        assertEntityOfDelete(entity);
        return getMyDao().delete(entity);
    }

    /**
     * Insert several entities. (Delegate-Method)
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Inserted count.
     */
    public int delegateInsertList(java.util.List<Employee> entityList) {
        assertListNotNullAndEmpty(entityList);
        return getMyDao().insertList(entityList);
    }

    /**
     * Update several entities. (Delegate-Method)
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Updated count.
     */
    public int delegateUpdateList(java.util.List<Employee> entityList) {
        assertListNotNullAndEmpty(entityList);
        return getMyDao().updateList(entityList);
    }

    /**
     * Delete several entities. (Delegate-Method)
     * 
     * @param entityList Entity-list. (NotNull & NotEmpty)
     * @return Deleted count.
     */
    public int delegateDeleteList(java.util.List<Employee> entityList) {
        assertListNotNullAndEmpty(entityList);
        return getMyDao().deleteList(entityList);
    }

    // =====================================================================================
    //                                                                          Basic Select
    //                                                                          ============
    /**
     * Select list.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return List-result-bean. (NotNull)
     */
    public ListResultBean<Employee> selectList(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return new ResultBeanBuilder<Employee>(this).buildListResultBean(cb, delegateSelectList(cb));
    }

    /**
     * Select page.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Selected page as first page. (NotNull)
     */
    public PagingResultBean<Employee> selectPage(final EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        return selectPage(cb, new SelectPageSimpleInvoker<Employee>(this));
    }

    /**
     * Select page.
     * 
     * @param cb Condition-bean. (NotNull)
     * @param invoker Select-page-invoker (NotNull)
     * @return Selected page as first page. (NotNull)
     */
    public PagingResultBean<Employee> selectPage(final EmployeeCB cb, SelectPageInvoker<Employee> invoker) {
        assertConditionBeanNotNull(cb);
        final SelectPageCallback<Employee> pageCallback = new SelectPageCallback<Employee>() {
            public PagingBean getPagingBean() { return cb; }
            public int selectCountIgnoreFetchScope() {
                return delegateSelectCountIgnoreFetchScope(cb);
            }
            public java.util.List<Employee> selectList() {
                return delegateSelectList(cb);
            }
        };
        return invoker.invokeSelectPage(pageCallback);
    }

    /**
     * Select entity by condition-bean with deleted check.
     * 
     * @param cb Condition-bean. (NotNull)
     * @return Entity that is selected from database by select-for-update. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Employee selectEntityWithDeletedCheck(EmployeeCB cb) {
        assertConditionBeanNotNull(cb);
        org.seasar.s2click.example.ldb.exentity.Employee currentEntity = delegateSelectEntity(cb);
        assertRecordHasNotBeenDeleted(currentEntity, cb.toString());
        return currentEntity;
    }

    // =====================================================================================
    //                                                                        Various Select
    //                                                                        ==============

    /**
     * Select list after checking count(ignore fetch scope).
     * 
     * @param cb Condition-bean. (NotNull)
     * @param maxCount Max count.
     * @return List-result-bean. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.SelectedCountExceedMaxCountException
     */
    public ListResultBean selectListAfterCheckingCountIgnoreFetchScope(EmployeeCB cb, int maxCount) {
        assertConditionBeanNotNull(cb);
        final int selectedCount = delegateSelectCountIgnoreFetchScope(cb);
        assertSelectedCountHasNotExceededMaxCount(selectedCount, maxCount, cb.toString());
        return new ResultBeanBuilder<Employee>(this).buildListResultBean(cb, delegateSelectList(cb));
    }


    public Employee selectForReadOnlyByPKValueWithDeletedCheck(java.math.BigDecimal id) {
        Employee entity = new Employee();
        entity.setId(id);
        return selectForReadOnlyByPKMapStringWithDeletedCheck(entity.extractPrimaryKeyMapString());
    }

    /**
     * Select for read only with deleted check.
     * 
     * @param primaryKeyMapString Primary-key map-string. (NotNull)
     * @return Entity that is selected from database by select-for-read-only. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Employee selectForReadOnlyByPKMapStringWithDeletedCheck(String primaryKeyMapString) {
        assertStringNotNullAndNotTrimmedEmpty("primaryKeyMapString", primaryKeyMapString);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(primaryKeyMapString);
        final org.seasar.s2click.example.ldb.exentity.Employee currentEntity = delegateSelectEntity(cb);
        assertRecordHasNotBeenDeleted(currentEntity, primaryKeyMapString);
        return currentEntity;
    }

    public Employee selectForUpdateByPKValueWithDeletedCheck(java.math.BigDecimal id) {
        Employee entity = new Employee();
        entity.setId(id);
        return selectForReadOnlyByPKMapStringWithDeletedCheck(entity.extractPrimaryKeyMapString());
    }

    /**
     * Select for update with deleted check.
     * 
     * @param primaryKeyMapString Primary-key map-string. (NotNull)
     * @return Entity that is selected from database by select-for-update. (NotNull)
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public Employee selectForUpdateByPKMapStringWithDeletedCheck(String primaryKeyMapString) {
        assertStringNotNullAndNotTrimmedEmpty("primaryKeyMapString", primaryKeyMapString);
        final EmployeeCB cb = newMyConditionBean();
        cb.acceptPrimaryKeyMapString(primaryKeyMapString);
        cb.lockForUpdate();
        final org.seasar.s2click.example.ldb.exentity.Employee currentEntity = delegateSelectEntity(cb);
        assertRecordHasNotBeenDeleted(currentEntity, primaryKeyMapString);
        return currentEntity;
    }


    // =====================================================================================
    //                                                                         Load Refferer
    //                                                                         =============
  
    // /* * * * * * * * * * * * * * * * * * * * * * *
    //   ReffererTable    = [employee]
    //   ReffererProperty = [employeeSelfList]
    // * * * * * * * * */

    /**
     * Load refferer of employeeSelfList.
     * 
     * Default refferer order-by is 'primary-key asc'.
     * <pre>
     *   ex) Refferer order-by is Manager.
     * 
     *     final BsEmployeeBhv bhv = (BsEmployeeBhv)getDaoSelector().getRBhv(BsEmployeeBhv.class);
     *     final EmployeeCB cb = bhv.newMyConditionBean();
     *     cb.query().setXxx_Equal("xxx");
     *     final List<Employee> ls = bhv.delegateSelectList(cb);
     *     bhv.loadEmployeeSelfList(ls);
     * 
     * </pre>
     * 
     * @param ls Entity list of main table. (NotNull)
     */
    public void loadEmployeeSelfList(java.util.List<Employee> ls) {
        final EmployeeBhv.CBSetupper cbSetupper = new EmployeeBhv.CBSetupper() {
            public void setup(EmployeeCB cb) {
                cb.addOrderBy_PK_Asc();// Default OrderBy for Refferer.
            }
        };
        loadEmployeeSelfList(ls, cbSetupper);
    }

    /**
     * Load refferer of employeeSelfList.
     * 
     * <pre>
     *   ex) Refferer order-by is Manager.
     * 
     *     final BsEmployeeBhv bhv = (BsEmployeeBhv)getDaoSelector().getRBhv(BsEmployeeBhv.class);
     *     final EmployeeCB cb = bhv.newMyConditionBean();
     *     cb.query().setXxx_Equal("xxx");
     *     final List<Employee> ls = bhv.delegateSelectList(cb);
     *     final EmployeeBhv.CBSetupper cbSetupper = new EmployeeBhv.CBSetupper() {
     *         public void setup(EmployeeCB cb) {
     *             cb.query().addOrderBy_Manager_Asc();
     *         }
     *     };
     *     bhv.loadEmployeeSelfList(ls, cbSetupper);
     * 
     * </pre>
     * 
     * @param ls Entity list of main table. (NotNull)
     * @param cbSetupper Refferer condition setupper instance for registering refferer condition. (NotNull)
     */
    public void loadEmployeeSelfList(java.util.List<Employee> ls, EmployeeBhv.CBSetupper cbSetupper) {
        assertObjectNotNull("ls", ls);
        assertObjectNotNull("cbSetupper", cbSetupper);
        if (ls.isEmpty()) {
            return;
        }

        final java.util.Map<java.math.BigDecimal, Employee> pkMyEntityMap = new java.util.LinkedHashMap<java.math.BigDecimal, Employee>();
        final java.util.List<java.math.BigDecimal> pkList = new java.util.ArrayList<java.math.BigDecimal>();
        for (final java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final Employee entity = (Employee)ite.next();
            pkList.add(entity.getId());
            pkMyEntityMap.put(entity.getId(), entity);
        }
        final EmployeeBhv reffererBhv = (EmployeeBhv)getDaoSelector().getRBhv(EmployeeBhv.class);
        final EmployeeCB cb = reffererBhv.newMyConditionBean();
        cb.query().setManager_InScope(pkList);
        cb.query().addOrderBy_Manager_Asc();
        cbSetupper.setup(cb);
        final java.util.List<Employee> reffererList = reffererBhv.delegateSelectList(cb);

        final java.util.Map<java.math.BigDecimal, java.util.List<Employee>> pkReffererListMap;
        pkReffererListMap = new java.util.LinkedHashMap<java.math.BigDecimal, java.util.List<Employee>>();
        for (final java.util.Iterator ite = reffererList.iterator(); ite.hasNext(); ) {
            final Employee reffererEntity = (Employee)ite.next();
            if (!pkReffererListMap.containsKey(reffererEntity.getManager())) {
                pkReffererListMap.put(reffererEntity.getManager(), new java.util.ArrayList<Employee>());
            }
            ((java.util.List<Employee>)pkReffererListMap.get(reffererEntity.getManager())).add(reffererEntity);

            // for Reverse Reference.
            final Employee myEntity = (Employee)pkMyEntityMap.get(reffererEntity.getManager());
            reffererEntity.setEmployeeSelf(myEntity);
        }

        for (final java.util.Iterator ite = ls.iterator(); ite.hasNext(); ) {
            final Employee entity = (Employee)ite.next();
            entity.setEmployeeSelfList((java.util.List<Employee>)pkReffererListMap.get(entity.getId()));
        }
    }

    /**
     * The interface of refferer condition for employeeSelfList.
     * 
     * @deprecated Not for public use in the future. Please use EmployeeBhv.CBSetupper.
     */
    public static interface ReffererConditionEmployeeSelfList extends EmployeeBhv.CBSetupper {
    }
  
    // =====================================================================================
    //                                                                          Basic Update
    //                                                                          ============


    /**
     * Insert or update after select-for-update.
     * 
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @return Updated count.
     */
    public int insertOrUpdateAfterSelectForUpdate(Employee entity) {
        assertEntityNotNull(entity);
        if (!entity.hasPrimaryKeyValue()) {
            return delegateInsert(entity);
        }
        final String mapString = entity.extractPrimaryKeyMapString();
        Employee currentEntity = null;
        try {
            currentEntity = selectForUpdateByPKMapStringWithDeletedCheck(mapString);
        } catch (org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException e) {
            return delegateInsert(entity);
        }
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        mergeEntity(entity, currentEntity);
        return delegateUpdate(currentEntity);
    }

    /**
     * Update after select-for-update.
     * 
     * @param entity Entity. This must contain primary-key value at least. (NotNull)
     * @return Updated count.
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public int updateAfterSelectForUpdate(Employee entity) {
        assertEntityNotNullAndHasPrimaryKeyValue(entity);
        final Employee currentEntity = selectForUpdateByPKMapStringWithDeletedCheck(entity.extractPrimaryKeyMapString());
        mergeEntity(entity, currentEntity);
        return delegateUpdate(currentEntity);
    }

    /**
     * This method implements the method that is declared at super.
     * 
     * @param sourceEntity Source entity. (NotNull)
     * @param destinationEntity Destination entity. (NotNull)
     */
    protected void mergeEntity(Entity sourceEntity, Entity destinationEntity) {
        assertEntityNotNull(sourceEntity);
        assertEntityNotNull(destinationEntity);
        final Employee sourceMyEntity = (Employee)sourceEntity;
        final Employee destinationMyEntity = (Employee)destinationEntity;
  
        if (sourceMyEntity.isSetterInvokedId()) {
            destinationMyEntity.setId(sourceMyEntity.getId());
        }
  
        if (sourceMyEntity.isSetterInvokedEmpno()) {
            destinationMyEntity.setEmpno(sourceMyEntity.getEmpno());
        }
  
        if (sourceMyEntity.isSetterInvokedEmpname()) {
            destinationMyEntity.setEmpname(sourceMyEntity.getEmpname());
        }
  
        if (sourceMyEntity.isSetterInvokedJob()) {
            destinationMyEntity.setJob(sourceMyEntity.getJob());
        }
  
        if (sourceMyEntity.isSetterInvokedManager()) {
            destinationMyEntity.setManager(sourceMyEntity.getManager());
        }
  
        if (sourceMyEntity.isSetterInvokedHiredate()) {
            destinationMyEntity.setHiredate(sourceMyEntity.getHiredate());
        }
  
        if (sourceMyEntity.isSetterInvokedSalary()) {
            destinationMyEntity.setSalary(sourceMyEntity.getSalary());
        }
  
        if (sourceMyEntity.isSetterInvokedDeptid()) {
            destinationMyEntity.setDeptid(sourceMyEntity.getDeptid());
        }
  
        if (sourceMyEntity.isSetterInvokedVersionno()) {
            destinationMyEntity.setVersionno(sourceMyEntity.getVersionno());
        }
  
    }

    // =====================================================================================
    //                                                                        Various Update
    //                                                                        ==============

  
  
      
    // 
    // Copy-insert after select-for-update.
    // 
    // @param primaryKey Primary-keys. (NotNull)
    // @return Inserted count.
    // @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
    // 
    public int copyInsertByPKValueAfterSelectForReadOnly(java.math.BigDecimal id) {
        Employee entity = new Employee();
        entity.setId(id);
        return copyInsertByPKMapStringAfterSelectForReadOnly(entity.extractPrimaryKeyMapString());
    }
    
    /**
     * Copy-insert after select for read only.
     * 
     * @param primaryKeyMapString Primary-key map-string. (NotNull)
     * @return Inserted count.
     * @exception org.seasar.s2click.example.ldb.allcommon.exception.RecordHasAlreadyBeenDeletedException
     */
    public int copyInsertByPKMapStringAfterSelectForReadOnly(String primaryKeyMapString) {
        assertStringNotNullAndNotTrimmedEmpty("primaryKeyMapString", primaryKeyMapString);
        final Employee currentEntity = selectForReadOnlyByPKMapStringWithDeletedCheck(primaryKeyMapString);
        filterCopyInsertEntity(currentEntity);
        return delegateInsert(currentEntity);
    }

    /**
     * Filter 'copy-insert' entity.
     * 
     * @param entity Entity. (NotNull)
     */
    protected void filterCopyInsertEntity(Employee entity) {
    }

  
    // =====================================================================================
    //                                                                            CBSetupper
    //                                                                            ==========
    /**
     * The interface of condition-bean setupper.
     */
    public static interface CBSetupper extends SimpleCBSetupper {
        /**
         * Set up condition.
         * 
         * @param cb Condition-bean. (NotNull)
         */
        public void setup(EmployeeCB cb);
    }
}
