package org.seasar.s2click.example.page;

import net.sf.click.control.TextField;

public class HomePage extends BorderPage {

}
