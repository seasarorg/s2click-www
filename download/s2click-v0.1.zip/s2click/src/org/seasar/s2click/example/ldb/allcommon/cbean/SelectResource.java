package org.seasar.s2click.example.ldb.allcommon.cbean;

/**
 * The select-resource as marker-interface.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface SelectResource {
}
