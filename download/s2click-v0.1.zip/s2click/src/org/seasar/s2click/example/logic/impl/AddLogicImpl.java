package org.seasar.s2click.example.logic.impl;

import org.seasar.s2click.example.logic.AddLogic;

public class AddLogicImpl implements AddLogic {
	/* (non-Javadoc)
	 * @see org.seasar.s2click.example.logic.impl.AddLogic#calculate(int, int)
	 */
	public Integer calculate(Integer para1, Integer para2){
		return para1 + para2;
	}
}
